const fs = require('fs-extra');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const ownerManager = require('./ownerManager');

class BuildManager {
    constructor() {
        this.activeBuilds = new Map();
        this.queue = [];
        this.maxConcurrent = 2;
        this.stats = {
            total: 0,
            success: 0,
            failed: 0,
            avgTime: 0
        };
        this.buildTimes = [];
        this.onBuildStart = null;
        this.BUILD_TIMEOUT = 10 * 60 * 1000;
    }

    isOwner(chatId) {
        return ownerManager.isOwner(chatId);
    }

    canStartBuild(chatId) {
        if (this.isOwner(chatId)) {
            return { allowed: true, reason: 'owner' };
        }

        if (this.activeBuilds.size >= this.maxConcurrent) {
            return { allowed: false, reason: 'slot_full' };
        }

        return { allowed: true, reason: 'available' };
    }

    generateBuildId() {
        return `build_${Date.now()}_${uuidv4().substring(0, 8)}`;
    }

    async startBuild(chatId, buildData, type, userName) {
        const buildId = this.generateBuildId();
        const buildDir = path.join(__dirname, '..', 'temp', buildId);
        
        await fs.ensureDir(buildDir);

        const buildInfo = {
            buildId,
            chatId,
            userName,
            projectName: buildData.appName || 'Project',
            type: type,
            startedAt: Date.now(),
            duration: 0,
            buildDir: buildDir,
            buildData: buildData,
            status: 'building',
            isOwner: this.isOwner(chatId)
        };

        this.activeBuilds.set(buildId, buildInfo);
        
        console.log(`🚀 Starting ${type} build #${buildId} for ${userName} (${chatId})`);
        console.log(`📊 Active builds: ${this.activeBuilds.size}`);
        console.log(`👑 Owner: ${buildInfo.isOwner ? 'YES' : 'NO'}`);

        setTimeout(() => {
            this.checkTimeout(buildId);
        }, this.BUILD_TIMEOUT);

        return buildInfo;
    }

    addToQueue(chatId, buildData, type, userName, priorityLevel = 0) {
        if (this.isOwner(chatId)) {
            return { queued: false, message: 'Owner langsung build tanpa antri' };
        }

        const existingIndex = this.queue.findIndex(item => item.chatId === chatId);
        if (existingIndex !== -1) {
            this.queue.splice(existingIndex, 1);
        }

        const isPriority = priorityLevel > 0;
        const queueItem = {
            chatId,
            buildData,
            type,
            userName,
            priorityLevel,
            priorityEmoji: priorityLevel === 2 ? '👑' : (priorityLevel === 1 ? '⭐' : ''),
            addedAt: Date.now(),
            position: this.queue.length + 1
        };

        if (isPriority) {
            const insertIndex = this.queue.findIndex(item => item.priorityLevel < priorityLevel);
            if (insertIndex === -1) {
                this.queue.push(queueItem);
            } else {
                this.queue.splice(insertIndex, 0, queueItem);
            }
        } else {
            this.queue.push(queueItem);
        }

        this.updatePositions();
        this.tryStartNext();

        const positionInQueue = this.queue.findIndex(item => item.chatId === chatId) + 1;
        const estimatedWait = this.getEstimatedWait(positionInQueue);

        return {
            queued: true,
            position: positionInQueue,
            estimatedWait: estimatedWait,
            isPriority: isPriority
        };
    }

    updatePositions() {
        this.queue.forEach((item, index) => {
            item.position = index + 1;
        });
    }

    tryStartNext() {
        while (this.activeBuilds.size < this.maxConcurrent && this.queue.length > 0) {
            const next = this.queue.shift();
            this.startBuildFromQueue(next);
        }
    }

    async startBuildFromQueue(queueItem) {
        const { chatId, buildData, type, userName, priorityLevel } = queueItem;

        const buildId = this.generateBuildId();
        const buildDir = path.join(__dirname, '..', 'temp', buildId);
        
        await fs.ensureDir(buildDir);

        const buildInfo = {
            buildId,
            chatId,
            userName,
            projectName: buildData.appName || 'Project',
            type: type,
            startedAt: Date.now(),
            duration: 0,
            buildDir: buildDir,
            buildData: buildData,
            status: 'building',
            isOwner: false,
            fromQueue: true
        };

        this.activeBuilds.set(buildId, buildInfo);

        console.log(`🚀 Starting queued ${type} build #${buildId} for ${userName} (${chatId})`);
        console.log(`📊 Active builds: ${this.activeBuilds.size}`);

        if (this.onBuildStart) {
            try {
                await this.onBuildStart(chatId, buildData, type, userName, buildId);
            } catch (error) {
                console.error('Error in onBuildStart callback:', error);
            }
        }

        setTimeout(() => {
            this.checkTimeout(buildId);
        }, this.BUILD_TIMEOUT);
    }

    release(buildId, success = true) {
        const build = this.activeBuilds.get(buildId);
        if (build) {
            build.duration = Math.round((Date.now() - build.startedAt) / 1000);
            build.status = success ? 'success' : 'failed';

            this.buildTimes.push(build.duration);
            if (this.buildTimes.length > 100) {
                this.buildTimes.shift();
            }

            this.stats.total++;
            if (success) {
                this.stats.success++;
            } else {
                this.stats.failed++;
            }

            this.activeBuilds.delete(buildId);
            
            console.log(`✅ Build ${success ? 'SUCCESS' : 'FAILED'} #${buildId} (${build.duration}s)`);
            console.log(`📊 Active builds: ${this.activeBuilds.size}`);
        }

        if (!build?.isOwner) {
            this.tryStartNext();
        }
    }

    async checkTimeout(buildId) {
        const build = this.activeBuilds.get(buildId);
        if (build) {
            const duration = Math.round((Date.now() - build.startedAt) / 1000);
            if (duration > 10 * 60) {
                console.log(`⚠️ Build timeout #${buildId}, forcing release`);
                await this.forceRelease(buildId);
            }
        }
    }

    async forceRelease(buildId) {
        const build = this.activeBuilds.get(buildId);
        if (build) {
            if (build.buildDir && await fs.pathExists(build.buildDir)) {
                await fs.remove(build.buildDir).catch(() => {});
            }
            this.release(buildId, false);
        }
    }

    updateActivity(buildId) {
        const build = this.activeBuilds.get(buildId);
        if (build) {
            build.startedAt = Date.now();
        }
    }

    isUserBuilding(chatId) {
        for (const [buildId, build] of this.activeBuilds) {
            if (build.chatId === chatId) {
                return build;
            }
        }
        return null;
    }

    getUserPosition(chatId) {
        const position = this.queue.findIndex(item => item.chatId === chatId);
        return position !== -1 ? position + 1 : 0;
    }

    getEstimatedWait(position) {
        const avgBuildTime = this.getAverageBuildTime();
        const activeCount = this.activeBuilds.size;
        const slotsAvailable = this.maxConcurrent - activeCount;
        
        if (position <= 1 && slotsAvailable > 0) {
            return 0;
        }

        const buildsAhead = position - slotsAvailable;
        return Math.ceil((buildsAhead * avgBuildTime) / 60);
    }

    getAverageBuildTime() {
        if (this.buildTimes.length === 0) return 120;
        const sum = this.buildTimes.reduce((a, b) => a + b, 0);
        return Math.ceil(sum / this.buildTimes.length);
    }

    getQueueInfo() {
        return {
            processing: this.activeBuilds.size,
            waiting: this.queue.length,
            maxConcurrent: this.maxConcurrent,
            ownerActive: Array.from(this.activeBuilds.values()).filter(b => b.isOwner).length,
            userActive: Array.from(this.activeBuilds.values()).filter(b => !b.isOwner).length
        };
    }

    getQueueList() {
        return this.queue.map((item, index) => ({
            position: index + 1,
            chatId: item.chatId,
            userName: item.userName,
            projectName: item.buildData.appName || 'Project',
            type: item.type,
            priorityLevel: item.priorityLevel,
            priorityEmoji: item.priorityEmoji,
            waitingTime: Math.round((Date.now() - item.addedAt) / 60000)
        }));
    }

    getActiveBuilds() {
        return Array.from(this.activeBuilds.values()).map(b => ({
            ...b,
            duration: Math.round((Date.now() - b.startedAt) / 1000)
        }));
    }

    getStats() {
        const avgTime = this.buildTimes.length > 0 
            ? Math.round(this.buildTimes.reduce((a, b) => a + b, 0) / this.buildTimes.length) 
            : 0;
        
        return {
            ...this.stats,
            avgTime: avgTime,
            active: this.activeBuilds.size,
            ownerActive: Array.from(this.activeBuilds.values()).filter(b => b.isOwner).length,
            userActive: Array.from(this.activeBuilds.values()).filter(b => !b.isOwner).length
        };
    }

    getBuildInfo(buildId) {
        return this.activeBuilds.get(buildId);
    }

    removeFromQueue(chatId) {
        const index = this.queue.findIndex(item => item.chatId === chatId);
        if (index !== -1) {
            this.queue.splice(index, 1);
            this.updatePositions();
            return true;
        }
        return false;
    }

    hasActiveBuild(chatId) {
        return this.isUserBuilding(chatId) !== null;
    }

    setMaxConcurrent(count) {
        if (count > 0 && count <= 10) {
            this.maxConcurrent = count;
            console.log(`⚙️ Max concurrent builds set to: ${count}`);
            this.tryStartNext();
        }
    }

    async cleanup() {
        const now = Date.now();
        let cleaned = 0;
        
        for (const [buildId, build] of this.activeBuilds) {
            const duration = Math.round((now - build.startedAt) / 1000);
            if (duration > 10 * 60) {
                if (build.buildDir && await fs.pathExists(build.buildDir)) {
                    await fs.remove(build.buildDir).catch(() => {});
                }
                this.activeBuilds.delete(buildId);
                cleaned++;
                console.log(`🧹 Cleaned up stale build #${buildId}`);
            }
        }
        
        return cleaned;
    }
}

const buildManager = new BuildManager();
module.exports = { buildManager };