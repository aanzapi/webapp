#!/bin/bash

# =================== COLOR CODES ===================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# =================== CONFIGURATION ===================
FLUTTER_VERSION="3.22.4"  # Stable terbaru
FLUTTER_CHANNEL="stable"
JAVA_VERSION="17"  # Java 17 untuk Android Gradle
GRADLE_VERSION="8.3"
ANDROID_SDK_VERSION="commandlinetools-linux-11076708_latest.zip"
ANDROID_API_LEVELS="34,33,31"
ANDROID_BUILD_TOOLS="34.0.0,33.0.2,31.0.0"

# Installation paths
INSTALL_DIR="$HOME/flutter-dev"
ANDROID_SDK_ROOT="$INSTALL_DIR/android-sdk"
FLUTTER_INSTALL_DIR="$INSTALL_DIR/flutter"
JAVA_HOME_DIR="$INSTALL_DIR/java"
GRADLE_HOME_DIR="$INSTALL_DIR/gradle"

# Log file
LOG_FILE="$HOME/flutter_install_$(date +%Y%m%d_%H%M%S).log"

# =================== FUNCTIONS ===================

print_header() {
    echo -e "${CYAN}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                                                              ║"
    echo "║        FLUTTER DEVELOPMENT ENVIRONMENT INSTALLER            ║"
    echo "║                    by Aanz Bot Support                       ║"
    echo "║                                                              ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_step() {
    echo -e "${GREEN}➜${NC} ${BLUE}$1${NC}"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] SUCCESS: $1" >> "$LOG_FILE"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" >> "$LOG_FILE"
}

print_warning() {
    echo -e "${YELLOW}⚠️ $1${NC}"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] WARNING: $1" >> "$LOG_FILE"
}

print_info() {
    echo -e "${PURPLE}ℹ️ $1${NC}"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] INFO: $1" >> "$LOG_FILE"
}

check_previous_install() {
    print_step "Checking for previous installations..."
    
    if [ -d "$INSTALL_DIR" ]; then
        print_warning "Previous installation detected at $INSTALL_DIR"
        read -p "Do you want to remove it and reinstall? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            print_info "Removing previous installation..."
            rm -rf "$INSTALL_DIR"
            print_success "Previous installation removed"
        else
            print_error "Installation cancelled by user"
            exit 1
        fi
    fi
}

install_system_dependencies() {
    print_step "Installing system dependencies..."
    
    # Update package list
    sudo apt-get update -qq >> "$LOG_FILE" 2>&1
    
    # Install essential packages
    sudo apt-get install -y \
        curl \
        wget \
        git \
        unzip \
        zip \
        xz-utils \
        libglu1-mesa \
        libstdc++6 \
        libpulse0 \
        libxcomposite1 \
        libxdamage1 \
        libxrandr2 \
        libgbm1 \
        libgtk-3-0 \
        libx11-6 \
        libxext6 \
        libxfixes3 \
        libxrender1 \
        libxslt1.1 \
        libxxf86vm1 \
        libxcb-shm0 \
        libxcb-shape0 \
        libxcb-xfixes0 \
        libxcb1 \
        libxcb-keysyms1 \
        libxcb-util1 \
        libxcb-randr0 \
        libxcb-render0 \
        libxcb-xkb1 \
        libxkbcommon-x11-0 \
        libxkbcommon0 \
        libsecret-1-0 \
        libnotify4 \
        libproxy1v5 \
        libwayland-client0 \
        libwayland-cursor0 \
        libwayland-egl1 \
        libwayland-server0 \
        libxcb-icccm4 \
        libxcb-image0 \
        libxcb-errors0 \
        libxcb-render-util0 \
        libxcb-xinerama0 \
        libxcb-xinput0 \
        libxcb-xrm0 \
        libx11-xcb1 \
        libsm6 \
        libice6 \
        libdbus-1-3 \
        libegl1 \
        libgles2 \
        libxss1 \
        fonts-liberation \
        libappindicator3-1 \
        libasound2 \
        libnspr4 \
        libnss3 \
        libvulkan1 \
        xdg-utils \
        clang \
        cmake \
        ninja-build \
        pkg-config \
        libgtk-3-dev \
        lzma \
        liblzma-dev \
        libbz2-dev \
        libsqlite3-dev \
        sqlite3 \
        libncurses5 \
        libncursesw5 \
        >> "$LOG_FILE" 2>&1
    
    if [ $? -eq 0 ]; then
        print_success "System dependencies installed"
    else
        print_error "Failed to install system dependencies"
        exit 1
    fi
}

install_java() {
    print_step "Installing Java ${JAVA_VERSION}..."
    
    # Check if Java is already installed
    if command -v java &> /dev/null; then
        CURRENT_JAVA=$(java -version 2>&1 | head -n 1 | awk -F '"' '{print $2}' | cut -d'.' -f1)
        if [ "$CURRENT_JAVA" = "$JAVA_VERSION" ]; then
            print_success "Java ${JAVA_VERSION} already installed"
            return
        fi
    fi
    
    # Download and install OpenJDK
    mkdir -p "$JAVA_HOME_DIR"
    cd "$INSTALL_DIR"
    
    JAVA_URL="https://github.com/adoptium/temurin${JAVA_VERSION}-binaries/releases/download/jdk-${JAVA_VERSION}.0.11%2B9/OpenJDK${JAVA_VERSION}U-jdk_x64_linux_hotspot_${JAVA_VERSION}.0.11_9.tar.gz"
    
    print_info "Downloading Java from: $JAVA_URL"
    wget -q --show-progress "$JAVA_URL" -O java.tar.gz >> "$LOG_FILE" 2>&1
    
    if [ $? -eq 0 ]; then
        tar -xzf java.tar.gz -C "$JAVA_HOME_DIR" --strip-components=1 >> "$LOG_FILE" 2>&1
        rm java.tar.gz
        print_success "Java ${JAVA_VERSION} installed"
        
        # Set JAVA_HOME in profile
        echo "export JAVA_HOME=$JAVA_HOME_DIR" >> "$HOME/.bashrc"
        echo "export PATH=\$JAVA_HOME/bin:\$PATH" >> "$HOME/.bashrc"
    else
        print_error "Failed to download Java"
        exit 1
    fi
}

install_gradle() {
    print_step "Installing Gradle ${GRADLE_VERSION}..."
    
    mkdir -p "$GRADLE_HOME_DIR"
    cd "$INSTALL_DIR"
    
    GRADLE_URL="https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"
    
    print_info "Downloading Gradle from: $GRADLE_URL"
    wget -q --show-progress "$GRADLE_URL" -O gradle.zip >> "$LOG_FILE" 2>&1
    
    if [ $? -eq 0 ]; then
        unzip -q gradle.zip -d "$GRADLE_HOME_DIR" >> "$LOG_FILE" 2>&1
        mv "$GRADLE_HOME_DIR/gradle-${GRADLE_VERSION}"/* "$GRADLE_HOME_DIR/"
        rmdir "$GRADLE_HOME_DIR/gradle-${GRADLE_VERSION}" 2>/dev/null
        rm gradle.zip
        print_success "Gradle ${GRADLE_VERSION} installed"
        
        # Set GRADLE_HOME in profile
        echo "export GRADLE_HOME=$GRADLE_HOME_DIR" >> "$HOME/.bashrc"
        echo "export PATH=\$GRADLE_HOME/bin:\$PATH" >> "$HOME/.bashrc"
    else
        print_error "Failed to download Gradle"
        exit 1
    fi
}

install_android_sdk() {
    print_step "Installing Android SDK..."
    
    mkdir -p "$ANDROID_SDK_ROOT"
    cd "$INSTALL_DIR"
    
    ANDROID_CMDLINE_URL="https://dl.google.com/android/repository/${ANDROID_SDK_VERSION}"
    
    print_info "Downloading Android SDK command line tools..."
    wget -q --show-progress "$ANDROID_CMDLINE_URL" -O cmdline-tools.zip >> "$LOG_FILE" 2>&1
    
    if [ $? -eq 0 ]; then
        mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools"
        unzip -q cmdline-tools.zip -d "$ANDROID_SDK_ROOT/cmdline-tools" >> "$LOG_FILE" 2>&1
        mv "$ANDROID_SDK_ROOT/cmdline-tools/cmdline-tools" "$ANDROID_SDK_ROOT/cmdline-tools/latest"
        rm cmdline-tools.zip
        print_success "Android SDK command line tools installed"
    else
        print_error "Failed to download Android SDK"
        exit 1
    fi
    
    # Set ANDROID_HOME in profile
    echo "export ANDROID_HOME=$ANDROID_SDK_ROOT" >> "$HOME/.bashrc"
    echo "export ANDROID_SDK_ROOT=$ANDROID_SDK_ROOT" >> "$HOME/.bashrc"
    echo "export PATH=\$ANDROID_HOME/cmdline-tools/latest/bin:\$PATH" >> "$HOME/.bashrc"
    echo "export PATH=\$ANDROID_HOME/platform-tools:\$PATH" >> "$HOME/.bashrc"
    echo "export PATH=\$ANDROID_HOME/emulator:\$PATH" >> "$HOME/.bashrc"
    echo "export PATH=\$ANDROID_HOME/tools:\$PATH" >> "$HOME/.bashrc"
    echo "export PATH=\$ANDROID_HOME/tools/bin:\$PATH" >> "$HOME/.bashrc"
    
    # Source environment
    export ANDROID_HOME=$ANDROID_SDK_ROOT
    export ANDROID_SDK_ROOT=$ANDROID_SDK_ROOT
    export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$PATH
    export PATH=$ANDROID_HOME/platform-tools:$PATH
    export PATH=$ANDROID_HOME/emulator:$PATH
    export PATH=$ANDROID_HOME/tools:$PATH
    export PATH=$ANDROID_HOME/tools/bin:$PATH
    
    # Accept licenses
    print_step "Accepting Android SDK licenses..."
    yes | sdkmanager --licenses >> "$LOG_FILE" 2>&1
    
    # Install SDK components
    print_step "Installing Android SDK components..."
    
    # Install platform tools
    print_info "Installing platform tools..."
    sdkmanager "platform-tools" >> "$LOG_FILE" 2>&1
    
    # Install build tools
    IFS=',' read -ra BUILD_TOOLS_ARRAY <<< "$ANDROID_BUILD_TOOLS"
    for tool in "${BUILD_TOOLS_ARRAY[@]}"; do
        print_info "Installing build-tools ${tool}..."
        sdkmanager "build-tools;${tool}" >> "$LOG_FILE" 2>&1
    done
    
    # Install platform APIs
    IFS=',' read -ra API_LEVELS <<< "$ANDROID_API_LEVELS"
    for api in "${API_LEVELS[@]}"; do
        print_info "Installing platform android-${api}..."
        sdkmanager "platforms;android-${api}" >> "$LOG_FILE" 2>&1
    done
    
    # Install emulator
    print_info "Installing emulator..."
    sdkmanager "emulator" >> "$LOG_FILE" 2>&1
    
    # Install system images (optional)
    print_info "Installing system images for API 34..."
    sdkmanager "system-images;android-34;google_apis_playstore;x86_64" >> "$LOG_FILE" 2>&1
    
    print_success "Android SDK components installed"
}

install_flutter() {
    print_step "Installing Flutter ${FLUTTER_VERSION} (${FLUTTER_CHANNEL})..."
    
    cd "$INSTALL_DIR"
    
    # Clone Flutter repository
    git clone https://github.com/flutter/flutter.git -b $FLUTTER_CHANNEL "$FLUTTER_INSTALL_DIR" >> "$LOG_FILE" 2>&1
    
    if [ $? -eq 0 ]; then
        cd "$FLUTTER_INSTALL_DIR"
        git checkout $FLUTTER_VERSION >> "$LOG_FILE" 2>&1
        
        # Set Flutter path in profile
        echo "export PATH=\$PATH:$FLUTTER_INSTALL_DIR/bin" >> "$HOME/.bashrc"
        
        # Export for current session
        export PATH="$PATH:$FLUTTER_INSTALL_DIR/bin"
        
        print_success "Flutter installed"
        
        # Run flutter doctor to setup
        print_step "Running flutter doctor for initial setup..."
        flutter doctor --android-licenses >> "$LOG_FILE" 2>&1
        flutter precache >> "$LOG_FILE" 2>&1
        
        print_success "Flutter initial setup complete"
    else
        print_error "Failed to clone Flutter repository"
        exit 1
    fi
}

configure_flutter() {
    print_step "Configuring Flutter settings..."
    
    # Create Flutter configuration directory
    mkdir -p "$HOME/.flutter"
    
    # Set Flutter settings
    flutter config --android-sdk "$ANDROID_SDK_ROOT" >> "$LOG_FILE" 2>&1
    flutter config --enable-linux-desktop >> "$LOG_FILE" 2>&1
    flutter config --enable-web >> "$LOG_FILE" 2>&1
    
    # Enable Android embedding v2
    flutter config --androidx >> "$LOG_FILE" 2>&1
    
    print_success "Flutter configured"
}

create_environment_file() {
    print_step "Creating environment setup script..."
    
    ENV_FILE="$HOME/flutter_env.sh"
    
    cat > "$ENV_FILE" << EOF
# Flutter Development Environment
# Generated on $(date)

export JAVA_HOME=$JAVA_HOME_DIR
export GRADLE_HOME=$GRADLE_HOME_DIR
export ANDROID_HOME=$ANDROID_SDK_ROOT
export ANDROID_SDK_ROOT=$ANDROID_SDK_ROOT
export FLUTTER_ROOT=$FLUTTER_INSTALL_DIR

export PATH=\$JAVA_HOME/bin:\$PATH
export PATH=\$GRADLE_HOME/bin:\$PATH
export PATH=\$ANDROID_HOME/cmdline-tools/latest/bin:\$PATH
export PATH=\$ANDROID_HOME/platform-tools:\$PATH
export PATH=\$ANDROID_HOME/emulator:\$PATH
export PATH=\$ANDROID_HOME/tools:\$PATH
export PATH=\$ANDROID_HOME/tools/bin:\$PATH
export PATH=\$FLUTTER_ROOT/bin:\$PATH

# Gradle optimization
export GRADLE_OPTS="-Xmx4096m -XX:MaxMetaspaceSize=1024m -XX:+UseG1GC"

# Flutter optimization
export FLUTTER_STORAGE_BASE_URL=https://storage.flutter-io.cn

echo "✅ Flutter development environment loaded!"
echo "📱 Java: \$JAVA_HOME"
echo "📱 Android SDK: \$ANDROID_HOME"
echo "📱 Flutter: \$FLUTTER_ROOT"
EOF
    
    chmod +x "$ENV_FILE"
    print_success "Environment file created at: $ENV_FILE"
}

run_doctor_check() {
    print_step "Running final verification..."
    
    echo ""
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}                     FLUTTER DOCTOR OUTPUT${NC}"
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
    
    flutter doctor -v
    
    if [ $? -eq 0 ]; then
        print_success "All components verified successfully!"
    else
        print_warning "Some issues detected. Please check the output above."
    fi
    
    echo -e "${CYAN}════════════════════════════════════════════════════════════════${NC}"
}

create_test_project() {
    print_step "Creating test Flutter project..."
    
    cd "$INSTALL_DIR"
    
    # Create test project
    flutter create --platforms=android,linux,web test_project >> "$LOG_FILE" 2>&1
    
    if [ $? -eq 0 ]; then
        print_success "Test project created at: $INSTALL_DIR/test_project"
        
        # Try to build APK to verify everything works
        print_step "Testing APK build (this may take a few minutes)..."
        
        cd test_project
        
        # Create keystore for signing
        keytool -genkey -v -keystore debug.keystore -alias debug -keyalg RSA -keysize 2048 -validity 10000 -storepass android -keypass android -dname "CN=Debug, OU=Debug, O=Debug, L=Debug, ST=Debug, C=US" >> "$LOG_FILE" 2>&1
        
        # Build APK
        flutter build apk --debug >> "$LOG_FILE" 2>&1
        
        if [ $? -eq 0 ] && [ -f "build/app/outputs/flutter-apk/app-debug.apk" ]; then
            print_success "Test APK built successfully!"
            print_info "APK location: $INSTALL_DIR/test_project/build/app/outputs/flutter-apk/app-debug.apk"
        else
            print_warning "Test APK build failed, but flutter environment is still functional"
        fi
        
        cd ..
    else
        print_warning "Test project creation failed"
    fi
}

show_summary() {
    echo ""
    echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                    INSTALLATION COMPLETE!                      ║${NC}"
    echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}📁 Installation Directory:${NC} $INSTALL_DIR"
    echo -e "${CYAN}📱 Flutter Location:${NC} $FLUTTER_INSTALL_DIR"
    echo -e "${CYAN}📱 Android SDK:${NC} $ANDROID_SDK_ROOT"
    echo -e "${CYAN}☕ Java Location:${NC} $JAVA_HOME_DIR"
    echo -e "${CYAN}📦 Gradle Location:${NC} $GRADLE_HOME_DIR"
    echo ""
    echo -e "${YELLOW}🔧 To use Flutter in any terminal, run:${NC}"
    echo -e "   ${GREEN}source $HOME/flutter_env.sh${NC}"
    echo ""
    echo -e "${YELLOW}📝 Or add to your ~/.bashrc:${NC}"
    echo -e "   ${GREEN}echo 'source ~/flutter_env.sh' >> ~/.bashrc${NC}"
    echo ""
    echo -e "${CYAN}🎯 Quick Start:${NC}"
    echo -e "   ${GREEN}source ~/flutter_env.sh${NC}"
    echo -e "   ${GREEN}cd $INSTALL_DIR/test_project${NC}"
    echo -e "   ${GREEN}flutter run${NC}"
    echo ""
    echo -e "${CYAN}📊 Flutter Version:${NC} $(flutter --version 2>/dev/null | head -n1)"
    echo ""
    echo -e "${YELLOW}⚠️  Note: Please restart your terminal or run 'source ~/.bashrc'${NC}"
    echo -e "${YELLOW}⚠️  Log file saved at: $LOG_FILE${NC}"
    echo ""
}

# =================== MAIN INSTALLATION ===================

main() {
    clear
    print_header
    
    # Check if running as root
    if [ "$EUID" -eq 0 ]; then 
        print_error "Please don't run this script as root (don't use sudo)"
        exit 1
    fi
    
    # Create installation directory
    print_step "Creating installation directory..."
    mkdir -p "$INSTALL_DIR"
    cd "$INSTALL_DIR"
    print_success "Installation directory created at: $INSTALL_DIR"
    
    # Check previous installation
    check_previous_install
    
    # Start installation
    install_system_dependencies
    install_java
    install_gradle
    install_android_sdk
    install_flutter
    configure_flutter
    create_environment_file
    run_doctor_check
    create_test_project
    show_summary
}

# Run main function
main