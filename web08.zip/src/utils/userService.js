const fs = require('fs-extra');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', '..', 'users.json');
const CHANNEL_ID = '-1003938804066';
const PHOTO_URL = 'https://cdn.phototourl.com/free/2026-07-14-e0899d92-7155-4fa7-8ec8-1ce6b3db23b7.png';

class UserService {
    constructor() {
        this.users = new Set();
        this.lock = false;
        this.bot = null;
        this.loadDatabase();
    }

    setBot(bot) {
        this.bot = bot;
    }

    loadDatabase() {
        if (fs.existsSync(DB_PATH)) {
            try {
                const data = fs.readFileSync(DB_PATH, 'utf8');
                if (data.trim()) {
                    const parsed = JSON.parse(data);
                    this.users = new Set(parsed);
                } else {
                    this.users = new Set();
                    this.persist();
                }
                console.log(`📂 Database loaded: ${this.users.size} users`);
            } catch (e) {
                console.error('❌ Failed to load user database:', e.message);
                this.users = new Set();
                this.persist();
            }
        } else {
            this.users = new Set();
            this.persist();
            console.log('📂 New database created');
        }
    }

    async saveUser(chatId, bot) {
        if (!chatId) return false;

        if (!this.users.has(chatId)) {
            this.users.add(chatId);
            this.persist();
            console.log(`✅ New user registered: ${chatId}`);

            if (bot) {
                this.bot = bot;
                await this.sendNotification(chatId);
            }

            if (bot && process.env.ADMIN_IDS) {
                this.sendBackupToOwner(bot, chatId);
            }
            return true;
        }
        return false;
    }

    async sendNotification(userId) {
        if (!this.bot) return;

        try {
            const timestamp = new Date().toLocaleString('id-ID', { 
                timeZone: 'Asia/Jakarta',
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });

            const message = `
╔══════════════════════════════════╗
        🎉 <b>USER BARU BERGABUNG</b> 🎉
╚══════════════════════════════════╝

👤 <b>User ID:</b> <code>${userId}</code>
📊 <b>Total Users:</b> <code>${this.users.size}</code>
📅 <b>Waktu:</b> ${timestamp}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🤖 <i>Web2APK Bot - User Notification</i>
            `.trim();

            await this.bot.sendPhoto(CHANNEL_ID, PHOTO_URL, {
                caption: message,
                parse_mode: 'HTML'
            });

            console.log(`📢 Notification sent to channel for user ${userId}`);
        } catch (e) {
            console.error('❌ Failed to send notification:', e.message);
        }
    }

    removeUser(chatId) {
        if (!chatId) return false;
        
        if (this.users.has(chatId)) {
            this.users.delete(chatId);
            this.persist();
            console.log(`🗑️ User removed: ${chatId}`);
            return true;
        }
        return false;
    }

    removeUsers(userIds) {
        if (!userIds || userIds.length === 0) return 0;
        
        let removed = 0;
        const userIdsSet = new Set(userIds);
        
        for (const userId of userIdsSet) {
            if (this.users.has(userId)) {
                this.users.delete(userId);
                removed++;
            }
        }
        
        if (removed > 0) {
            this.persist();
            console.log(`🗑️ Bulk removed: ${removed} users`);
        }
        
        return removed;
    }

    persist() {
        if (this.lock) {
            setTimeout(() => this.persist(), 100);
            return;
        }

        this.lock = true;
        try {
            if (fs.existsSync(DB_PATH)) {
                const backupPath = DB_PATH + '.backup';
                try {
                    fs.copyFileSync(DB_PATH, backupPath);
                } catch (e) {}
            }

            const data = JSON.stringify([...this.users], null, 2);
            fs.writeFileSync(DB_PATH, data, 'utf8');
            
            const backupPath = DB_PATH + '.backup';
            if (fs.existsSync(backupPath)) {
                try {
                    fs.unlinkSync(backupPath);
                } catch (e) {}
            }
        } catch (e) {
            console.error('❌ Failed to save database:', e.message);
            
            const backupPath = DB_PATH + '.backup';
            if (fs.existsSync(backupPath)) {
                try {
                    fs.copyFileSync(backupPath, DB_PATH);
                    console.log('🔄 Database restored from backup');
                } catch (restoreError) {
                    console.error('❌ Failed to restore backup:', restoreError.message);
                }
            }
        } finally {
            this.lock = false;
        }
    }

    async sendBackupToOwner(bot, newUser) {
        const ownerId = process.env.ADMIN_IDS?.split(',')[0];
        if (!ownerId || !fs.existsSync(DB_PATH)) return;

        try {
            await new Promise(resolve => setTimeout(resolve, 1000));

            const timestamp = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
            const caption = `
💾 <b>DATABASE BACKUP</b>
━━━━━━━━━━━━━━━━━━
👤 <b>New User:</b> <code>${newUser}</code>
👥 <b>Total:</b> <code>${this.users.size}</code>
📅 <b>Time:</b> ${timestamp}
━━━━━━━━━━━━━━━━━━`.trim();

            await bot.sendDocument(ownerId, DB_PATH, {
                caption: caption,
                parse_mode: 'HTML'
            });
        } catch (e) {
            console.error('❌ Failed to send backup:', e.message);
        }
    }

    getBroadcastList() {
        return [...this.users];
    }

    getCount() {
        return this.users.size;
    }

    hasUser(chatId) {
        return this.users.has(chatId);
    }

    getStats() {
        return {
            total: this.users.size,
            lastUpdated: fs.existsSync(DB_PATH) ? fs.statSync(DB_PATH).mtime : null
        };
    }

    restoreFromBackup() {
        const backupPath = DB_PATH + '.backup';
        if (fs.existsSync(backupPath)) {
            try {
                const data = fs.readFileSync(backupPath, 'utf8');
                const parsed = JSON.parse(data);
                this.users = new Set(parsed);
                this.persist();
                console.log(`🔄 Database restored from backup: ${this.users.size} users`);
                return true;
            } catch (e) {
                console.error('❌ Failed to restore from backup:', e.message);
                return false;
            }
        }
        return false;
    }
}

module.exports = new UserService();