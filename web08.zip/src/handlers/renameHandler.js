const fs = require('fs-extra');
const path = require('path');
const archiver = require('archiver');
const { v4: uuidv4 } = require('uuid');
const { downloadTelegramFile } = require('../utils/fileDownloader');
const { escapeHtml } = require('../utils/progressUI');
const ownerManager = require('../utils/ownerManager');
const resellerService = require('../utils/resellerService');
const licenseKeyService = require('../utils/licenseKeyService');

const RENAME_SESSIONS = new Map();

async function handleRenameCommand(bot, msg, match) {
    const chatId = msg.chat.id;
    const isOwner = ownerManager.isOwner(chatId);
    const isReseller = resellerService.isReseller(chatId);
    const hasLicense = licenseKeyService.isUserAuthorized(chatId);

    if (!isOwner && !isReseller && !hasLicense) {
        return bot.sendMessage(chatId, `
🔒 <b>Fitur Khusus Member</b>
━━━━━━━━━━━━━━━━━━

Fitur /rename hanya untuk:
👑 Owner
⭐ Reseller
🎫 Member (Berlisensi)

💡 Beli akses di menu 🛒 Beli Akses
        `.trim(), { parse_mode: 'HTML' });
    }

    const isReply = msg.reply_to_message;
    const input = match[1];

    if (!isReply) {
        return bot.sendMessage(chatId, `
📝 <b>RENAME / REPLACE FILE .DART</b>
━━━━━━━━━━━━━━━━━━

<b>Cara Penggunaan:</b>

1️⃣ <b>Untuk 1 File:</b>
Reply file <code>.dart</code>
<code>/rename teks_lama|teks_baru</code>

2️⃣ <b>Untuk Banyak File (ZIP):</b>
Reply file <code>.zip</code> (berisi folder lib)
<code>/rename teks_lama|teks_baru</code>

<b>Contoh:</b>
<code>/rename http://xii.aanzload.my.id:2002|http://xii.aanzload.my.id:2001</code>
<code>/rename Aan|Oon</code>

<b>Support:</b>
• 1 file .dart
• 1 file ZIP (akan diproses semua .dart di dalam folder lib)

━━━━━━━━━━━━━━━━━━
💡 <i>Bot akan mengganti semua teks yang cocok!</i>
        `.trim(), { parse_mode: 'HTML' });
    }

    if (!input || !input.includes('|')) {
        return bot.sendMessage(chatId, `
❌ <b>Format Salah!</b>
━━━━━━━━━━━━━━━━━━

Gunakan format:
<code>/rename teks_lama|teks_baru</code>

<b>Contoh:</b>
<code>/rename Aan|Oon</code>
<code>/rename http://xii.aanzload.my.id:2002|http://xii.aanzload.my.id:2001</code>
        `.trim(), { parse_mode: 'HTML' });
    }

    const [oldText, newText] = input.split('|').map(s => s.trim());

    if (!oldText || !newText) {
        return bot.sendMessage(chatId, '❌ Teks lama dan baru tidak boleh kosong!', { parse_mode: 'HTML' });
    }

    if (oldText === newText) {
        return bot.sendMessage(chatId, '⚠️ Teks lama dan baru sama! Tidak ada yang perlu diubah.', { parse_mode: 'HTML' });
    }

    const repliedMsg = msg.reply_to_message;
    const document = repliedMsg.document;

    if (!document) {
        return bot.sendMessage(chatId, '❌ Reply harus berupa file!', { parse_mode: 'HTML' });
    }

    const fileName = document.file_name || '';
    const isDartFile = fileName.endsWith('.dart');
    const isZipFile = fileName.endsWith('.zip');

    if (!isDartFile && !isZipFile) {
        return bot.sendMessage(chatId, `
❌ <b>Format File Tidak Didukung!</b>
━━━━━━━━━━━━━━━━━━

Hanya support:
• <code>.dart</code> - Untuk 1 file
• <code>.zip</code> - Untuk banyak file (folder lib)

File Anda: <code>${escapeHtml(fileName)}</code>
        `.trim(), { parse_mode: 'HTML' });
    }

    await bot.sendMessage(chatId, `
⏳ <b>Memproses...</b>
━━━━━━━━━━━━━━━━━━

📁 File: <code>${escapeHtml(fileName)}</code>
🔄 Mengganti: <code>${escapeHtml(oldText)}</code> → <code>${escapeHtml(newText)}</code>

<i>Mohon tunggu...</i>
    `.trim(), { parse_mode: 'HTML' });

    try {
        const tempDir = path.join(__dirname, '..', 'temp', `rename_${uuidv4()}`);
        await fs.ensureDir(tempDir);

        const downloadPath = path.join(tempDir, fileName);
        const result = await downloadTelegramFile(
            bot,
            document.file_id,
            tempDir,
            fileName
        );

        if (!result.success) {
            await fs.remove(tempDir).catch(() => {});
            return bot.sendMessage(chatId, `❌ Gagal mengunduh file: ${result.error}`, { parse_mode: 'HTML' });
        }

        if (isDartFile) {
            await processSingleDartFile(bot, chatId, downloadPath, oldText, newText, tempDir);
        } else if (isZipFile) {
            await processZipFile(bot, chatId, downloadPath, oldText, newText, tempDir);
        }

    } catch (error) {
        console.error('Rename error:', error);
        bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`, { parse_mode: 'HTML' });
    }
}

async function processSingleDartFile(bot, chatId, filePath, oldText, newText, tempDir) {
    try {
        let content = await fs.readFile(filePath, 'utf8');
        const totalReplaced = (content.match(new RegExp(oldText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length;

        if (totalReplaced === 0) {
            await fs.remove(tempDir).catch(() => {});
            return bot.sendMessage(chatId, `
⚠️ <b>Tidak Ada Yang Diubah!</b>
━━━━━━━━━━━━━━━━━━

Teks <code>${escapeHtml(oldText)}</code> tidak ditemukan di file.

📁 File: <code>${escapeHtml(path.basename(filePath))}</code>
        `.trim(), { parse_mode: 'HTML' });
        }

        content = content.replace(new RegExp(oldText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), newText);

        const outputFileName = path.basename(filePath).replace('.dart', '_renamed.dart');
        const outputPath = path.join(tempDir, outputFileName);
        await fs.writeFile(outputPath, content, 'utf8');

        await bot.sendDocument(chatId, outputPath, {
            caption: `
✅ <b>Rename Berhasil!</b>
━━━━━━━━━━━━━━━━━━

📁 File: <code>${escapeHtml(path.basename(filePath))}</code>
🔄 <code>${escapeHtml(oldText)}</code> → <code>${escapeHtml(newText)}</code>
📊 Total: <code>${totalReplaced}</code> perubahan
            `.trim(),
            parse_mode: 'HTML'
        });

        await fs.remove(tempDir).catch(() => {});

    } catch (error) {
        await fs.remove(tempDir).catch(() => {});
        throw error;
    }
}

async function processZipFile(bot, chatId, zipPath, oldText, newText, tempDir) {
    const extractDir = path.join(tempDir, 'extracted');
    const outputDir = path.join(tempDir, 'output');
    await fs.ensureDir(extractDir);
    await fs.ensureDir(outputDir);

    const AdmZip = require('adm-zip');
    const zip = new AdmZip(zipPath);
    zip.extractAllTo(extractDir, true);

    let totalFiles = 0;
    let totalReplaced = 0;
    let modifiedFiles = [];

    const libDir = path.join(extractDir, 'lib');

    if (!await fs.pathExists(libDir)) {
        await fs.remove(tempDir).catch(() => {});
        return bot.sendMessage(chatId, `
❌ <b>Folder 'lib' Tidak Ditemukan!</b>
━━━━━━━━━━━━━━━━━━

File ZIP harus berisi folder <code>lib</code> dengan file <code>.dart</code> di dalamnya.

📁 Struktur yang diharapkan:
<code>your_project.zip
└── lib/
    ├── main.dart
    ├── app.dart
    └── ...</code>
        `.trim(), { parse_mode: 'HTML' });
    }

    async function walkDir(dir) {
        const files = await fs.readdir(dir);
        for (const file of files) {
            const filePath = path.join(dir, file);
            const stat = await fs.stat(filePath);
            if (stat.isDirectory()) {
                await walkDir(filePath);
            } else if (file.endsWith('.dart')) {
                totalFiles++;
                let content = await fs.readFile(filePath, 'utf8');
                const replaced = (content.match(new RegExp(oldText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length;

                if (replaced > 0) {
                    content = content.replace(new RegExp(oldText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), newText);
                    const relativePath = path.relative(libDir, filePath);
                    const outputFilePath = path.join(outputDir, relativePath);
                    await fs.ensureDir(path.dirname(outputFilePath));
                    await fs.writeFile(outputFilePath, content, 'utf8');
                    modifiedFiles.push({
                        path: relativePath,
                        replaced: replaced
                    });
                    totalReplaced += replaced;
                }
            }
        }
    }

    await walkDir(libDir);

    if (totalReplaced === 0) {
        await fs.remove(tempDir).catch(() => {});
        return bot.sendMessage(chatId, `
⚠️ <b>Tidak Ada Yang Diubah!</b>
━━━━━━━━━━━━━━━━━━

Teks <code>${escapeHtml(oldText)}</code> tidak ditemukan di semua file <code>.dart</code>.

📁 Total file: <code>${totalFiles}</code> file .dart
        `.trim(), { parse_mode: 'HTML' });
    }

    const outputZipPath = path.join(tempDir, 'renamed_files.zip');
    const output = fs.createWriteStream(outputZipPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    await new Promise((resolve, reject) => {
        output.on('close', resolve);
        archive.on('error', reject);
        archive.pipe(output);
        archive.directory(outputDir, false);
        archive.finalize();
    });

    let modifiedList = modifiedFiles.slice(0, 10).map(f => `• ${f.path} (${f.replaced} perubahan)`).join('\n');
    if (modifiedFiles.length > 10) {
        modifiedList += `\n• ...dan ${modifiedFiles.length - 10} file lainnya`;
    }

    await bot.sendDocument(chatId, outputZipPath, {
        caption: `
✅ <b>Rename Berhasil!</b>
━━━━━━━━━━━━━━━━━━

📁 Total file diproses: <code>${totalFiles}</code> file .dart
🔄 <code>${escapeHtml(oldText)}</code> → <code>${escapeHtml(newText)}</code>
📊 Total perubahan: <code>${totalReplaced}</code>

<b>File yang diubah:</b>
${modifiedList}
        `.trim(),
        parse_mode: 'HTML'
    });

    await fs.remove(tempDir).catch(() => {});
}

module.exports = { handleRenameCommand, RENAME_SESSIONS };