const fs = require('fs-extra');
const path = require('path');

const PROGRESS_CHARS = {
    filled: '█',
    empty: '░',
};

const NOTIFICATION_PHOTO = 'https://cdn.phototourl.com/free/2026-07-14-e0899d92-7155-4fa7-8ec8-1ce6b3db23b7.png';

function escapeHtml(text) {
    if (!text) return '';
    return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function progressBar(percent, length = 15) {
    const filled = Math.round((percent / 100) * length);
    const empty = length - filled;
    return PROGRESS_CHARS.filled.repeat(filled) + PROGRESS_CHARS.empty.repeat(empty);
}

function formatBuildProgress(percent, status, appName = '') {
    const bar = progressBar(percent);
    const safeStatus = escapeHtml(status);
    const header = appName ? `🔨 <b>Building: ${appName}</b>` : '🔨 <b>Building APK</b>';

    return `
${header}
━━━━━━━━━━━━━━━━━━

${bar} <b>${percent}%</b>

<code>${safeStatus}</code>

⏳ <i>Mohon tunggu...</i>
    `.trim();
}

function formatZipBuildProgress(percent, status, projectType, buildType) {
    const bar = progressBar(percent);
    const typeIcon = projectType === 'flutter' ? '💙' : '🤖';
    const buildIcon = buildType === 'release' ? '🚀' : '🐛';
    const safeStatus = escapeHtml(status);

    return `
🔨 <b>Building Project</b>
━━━━━━━━━━━━━━━━━━

${bar} <b>${percent}%</b>

${typeIcon} <b>Type:</b> ${projectType === 'flutter' ? 'Flutter' : 'Android'}
${buildIcon} <b>Build:</b> ${buildType === 'release' ? 'Release' : 'Debug'}

📍 <code>${safeStatus}</code>

⏳ <i>Harap tunggu, proses ini membutuhkan waktu...</i>
    `.trim();
}

async function saveErrorLog(error, context = 'build', extraInfo = {}) {
    try {
        const logDir = path.join(__dirname, '..', 'logs', 'errors');
        await fs.ensureDir(logDir);
        
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const logFileName = `error_${context}_${timestamp}.txt`;
        const logFilePath = path.join(logDir, logFileName);
        
        let logContent = `=== ERROR LOG ===
Date: ${new Date().toLocaleString('id-ID')}
Context: ${context}
Timestamp: ${new Date().toISOString()}
================================

Error Message:
${error}

================================
Stack Trace:
${error.stack || 'No stack trace available'}
================================
System Info:
Node Version: ${process.version}
Platform: ${process.platform}
Memory Usage: ${JSON.stringify(process.memoryUsage(), null, 2)}
================================
`;
        
        if (extraInfo && Object.keys(extraInfo).length > 0) {
            logContent += `\nExtra Info:\n${JSON.stringify(extraInfo, null, 2)}\n`;
            logContent += '================================\n';
        }
        
        await fs.writeFile(logFilePath, logContent, 'utf8');
        console.log(`📝 Error log saved: ${logFilePath}`);
        return logFilePath;
    } catch (err) {
        console.error('Failed to save error log:', err);
        return null;
    }
}

async function sendErrorLog(bot, chatId, error, context = 'build', extraInfo = {}) {
    const logFilePath = await saveErrorLog(error, context, extraInfo);
    
    if (logFilePath && await fs.pathExists(logFilePath)) {
        try {
            const logFileName = path.basename(logFilePath);
            const message = `
❌ <b>Build Gagal!</b>
━━━━━━━━━━━━━━━━━━

📄 <b>Error Log:</b> <code>${logFileName}</code>

💡 <i>File log detail telah dikirim di bawah.</i>
<i>Periksa project Anda dan coba lagi.</i>
            `.trim();
            
            await bot.sendMessage(chatId, message, { parse_mode: 'HTML' });
            
            await bot.sendDocument(chatId, logFilePath, {
                caption: `📋 <b>Error Log Detail</b>\n\n🔍 <b>Context:</b> ${context}\n⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}\n\n💡 <i>File ini berisi detail lengkap error untuk debugging.</i>`,
                parse_mode: 'HTML'
            });
            
            await fs.remove(logFilePath).catch(() => {});
            return true;
        } catch (err) {
            console.error('Failed to send error log:', err);
            return false;
        }
    }
    return false;
}

function formatSuccessMessage(appName, url = '') {
    const safeUrl = escapeHtml(url);
    const urlLine = safeUrl ? `\n🌐 <code>${safeUrl}</code>` : '';
    return `
✅ <b>Build Berhasil!</b>
━━━━━━━━━━━━━━━━━━

📱 <b>${appName}</b>${urlLine}

🎉 <i>File APK sedang dikirim...</i>
    `.trim();
}

function formatErrorMessage(error) {
    const truncatedError = error.length > 500 ? error.substring(0, 500) + '...' : error;
    const safeError = escapeHtml(truncatedError);

    return `
❌ <b>Build Gagal</b>
━━━━━━━━━━━━━━━━━━

<b>Error:</b>
<code>${safeError}</code>

💡 <i>Periksa project Anda dan coba lagi.</i>
`.trim();
}

function getSpinner(step) {
    const spinners = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
    return spinners[step % spinners.length];
}

function formatBuildStartMessage(appName, url) {
    const safeUrl = escapeHtml(url);
    return `
🚀 <b>Memulai Build</b>
━━━━━━━━━━━━━━━━━━

📱 <b>Aplikasi:</b> ${appName}
🌐 <b>URL:</b> <code>${safeUrl}</code>

${progressBar(0)} <b>0%</b>

⏳ <i>Mempersiapkan environment...</i>
    `.trim();
}

async function sendBuildNotification(bot, type, data) {
    const CHANNEL_ID = '@aanmarket';
    const timestamp = new Date().toLocaleString('id-ID', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });

    let message = '';
    let statusIcon = '';

    if (type === 'start') {
        statusIcon = '🚀';
        message = `
╔═══════════════════════════════════╗
     ${statusIcon}  <b>BUILD DIMULAI</b>  ${statusIcon}
╚═══════════════════════════════════╝

📱 <b>Project:</b> ${escapeHtml(data.appName || 'Unknown')}
👤 <b>User:</b> ${escapeHtml(data.userName || 'Unknown')}
🆔 <b>User ID:</b> <code>${data.userId || 'N/A'}</code>
📅 <b>Waktu:</b> ${timestamp}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚡ <i>Proses build sedang berjalan...</i>
        `;
    } else if (type === 'success') {
        statusIcon = '✅';
        message = `
╔═══════════════════════════════════╗
     ${statusIcon}  <b>BUILD BERHASIL</b>  ${statusIcon}
╚═══════════════════════════════════╝

📱 <b>Project:</b> ${escapeHtml(data.appName || 'Unknown')}
👤 <b>User:</b> ${escapeHtml(data.userName || 'Unknown')}
🆔 <b>User ID:</b> <code>${data.userId || 'N/A'}</code>
📦 <b>Size:</b> ${data.size || 'N/A'}
⏱️ <b>Durasi:</b> ${data.duration || 'N/A'}
📅 <b>Waktu:</b> ${timestamp}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎉 <i>APK berhasil dibuat!</i>
        `;
    } else if (type === 'failed') {
        statusIcon = '❌';
        const errorMsg = data.error ? data.error.substring(0, 200) : 'Unknown error';
        message = `
╔═══════════════════════════════════╗
     ${statusIcon}  <b>BUILD GAGAL</b>  ${statusIcon}
╚═══════════════════════════════════╝

📱 <b>Project:</b> ${escapeHtml(data.appName || 'Unknown')}
👤 <b>User:</b> ${escapeHtml(data.userName || 'Unknown')}
🆔 <b>User ID:</b> <code>${data.userId || 'N/A'}</code>
⏱️ <b>Durasi:</b> ${data.duration || 'N/A'}
📅 <b>Waktu:</b> ${timestamp}

<b>Error:</b>
<code>${escapeHtml(errorMsg)}${errorMsg.length > 200 ? '...' : ''}</code>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️ <i>Periksa log untuk detail error.</i>
        `;
    }

    if (message) {
        try {
            await bot.sendPhoto(CHANNEL_ID, NOTIFICATION_PHOTO, {
                caption: message.trim(),
                parse_mode: 'HTML'
            });
            console.log(`📢 Notification sent to channel: ${type}`);
        } catch (error) {
            console.error(`Failed to send notification to channel:`, error.message);
            
            try {
                await bot.sendMessage(CHANNEL_ID, message.trim(), {
                    parse_mode: 'HTML',
                    disable_web_page_preview: true
                });
                console.log(`📢 Text notification sent to channel: ${type}`);
            } catch (err) {
                console.error(`Failed to send text notification:`, err.message);
            }
        }
    }
}

module.exports = {
    progressBar,
    formatBuildProgress,
    formatZipBuildProgress,
    formatSuccessMessage,
    formatErrorMessage,
    formatBuildStartMessage,
    getSpinner,
    saveErrorLog,
    sendErrorLog,
    sendBuildNotification,
    escapeHtml
};