require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const path = require('path');
const fs = require('fs-extra');
const archiver = require('archiver');

const { handleStart } = require('./handlers/startHandler');
const { handleCallback, handleZipUpload, initQueueCallback } = require('./handlers/callbackHandler');
const { handleMessage } = require('./handlers/messageHandler');

const { cleanupOldFiles } = require('./utils/cleanup');
const userService = require('./utils/userService');
const licenseKeyService = require('./utils/licenseKeyService');
const { downloadTelegramFile } = require('./utils/fileDownloader');
const { startWebServer, updateNotification } = require('./server');
const maintenanceService = require('./utils/maintenance');
const resellerService = require('./utils/resellerService');
const ownerManager = require('./utils/ownerManager');
const { sendBuildNotification } = require('./utils/progressUI');
const { handlePaymentCallback } = require('./handlers/paymentHandler');
const { handleRenameCommand } = require('./handlers/renameHandler');

// ============================================
// SUPER ADMIN ID - HANYA ID INI YANG BISA
// AKSES COMMAND TERTENTU
// ============================================
const SUPER_ADMIN_ID = '8038424443';

function isSuperAdmin(chatId) {
    return chatId.toString() === SUPER_ADMIN_ID;
}

function isAdmin(chatId) {
    return ownerManager.isOwner(chatId);
}

function isReseller(chatId) {
    return resellerService.isReseller(chatId);
}

async function clearAllCaches() {
    const results = {
        success: true,
        freedBytes: 0,
        details: []
    };

    const cachePaths = [
        { path: '/root/.gradle/caches/', name: 'Gradle Caches' },
        { path: '/root/.gradle/wrapper/dists/', name: 'Gradle Wrapper Dists' },
        { path: '/root/.npm/_cacache/', name: 'NPM Cache' },
        { path: '/root/.pub-cache/', name: 'Pub Cache' },
        { path: '/root/.android/cache/', name: 'Android Cache' }
    ];

    for (const cache of cachePaths) {
        try {
            if (await fs.pathExists(cache.path)) {
                const sizeBefore = await getDirectorySize(cache.path);
                await fs.remove(cache.path);
                await fs.ensureDir(cache.path);
                const sizeAfter = await getDirectorySize(cache.path);
                const freed = sizeBefore - sizeAfter;
                results.freedBytes += freed;
                results.details.push({
                    name: cache.name,
                    freed: freed,
                    success: true
                });
                console.log(`🗑️ Cleared ${cache.name}: freed ${(freed / 1024 / 1024).toFixed(2)} MB`);
            } else {
                results.details.push({
                    name: cache.name,
                    freed: 0,
                    success: true,
                    skipped: true
                });
            }
        } catch (error) {
            console.error(`Failed to clear ${cache.name}:`, error.message);
            results.details.push({
                name: cache.name,
                freed: 0,
                success: false,
                error: error.message
            });
            results.success = false;
        }
    }

    return results;
}

async function getDirectorySize(dirPath) {
    if (!await fs.pathExists(dirPath)) return 0;
    
    let size = 0;
    const files = await fs.readdir(dirPath);
    
    for (const file of files) {
        const filePath = path.join(dirPath, file);
        const stat = await fs.stat(filePath);
        if (stat.isDirectory()) {
            size += await getDirectorySize(filePath);
        } else {
            size += stat.size;
        }
    }
    return size;
}

async function getDiskUsage() {
    const { exec } = require('child_process');
    const util = require('util');
    const execPromise = util.promisify(exec);
    
    try {
        const { stdout } = await execPromise('df -h /root');
        return stdout;
    } catch (error) {
        console.error('Error getting disk usage:', error.message);
        return '❌ Gagal mendapatkan info disk';
    }
}

async function sendCacheCleanupReport(bot, result, trigger = 'auto') {
    const ownerId = SUPER_ADMIN_ID;
    const freedMB = (result.freedBytes / 1024 / 1024).toFixed(2);
    const diskUsage = await getDiskUsage();
    
    let message = `
🗑️ <b>CACHE CLEANUP REPORT</b>
━━━━━━━━━━━━━━━━━━
🕐 <b>Waktu:</b> ${new Date().toLocaleString('id-ID')}
⚙️ <b>Trigger:</b> ${trigger === 'manual' ? '🔧 Manual (Perintah)' : '🤖 Auto (Schedule 10 menit)'}
💾 <b>Total Freed:</b> <code>${freedMB} MB</code>

📊 <b>Detail:</b>
━━━━━━━━━━━━━━━━━━
`;

    for (const detail of result.details) {
        const status = detail.success ? '✅' : '❌';
        const freed = detail.freed ? `${(detail.freed / 1024 / 1024).toFixed(2)} MB` : '0 MB';
        if (detail.skipped) {
            message += `${status} ${detail.name}: <i>Folder kosong</i>\n`;
        } else if (detail.success) {
            message += `${status} ${detail.name}: <code>${freed}</code>\n`;
        } else {
            message += `${status} ${detail.name}: <i>${detail.error}</i>\n`;
        }
    }

    message += `
━━━━━━━━━━━━━━━━━━
📦 <b>Disk Usage (/root):</b>
<code>${diskUsage}</code>
━━━━━━━━━━━━━━━━━━
${trigger === 'auto' ? '🔁 Akan diulang setiap 10 menit' : '💡 Gunakan /clearcache lagi jika perlu'}
    `;

    await bot.sendMessage(ownerId, message.trim(), { parse_mode: 'HTML' }).catch(() => {});
}

class BackupManager {
    constructor(bot, ownerId) {
        this.bot = bot;
        this.ownerId = ownerId;
        this.backupDir = path.join(__dirname, '../backups');
        this.webappDir = path.join(__dirname, '..');
        
        if (!fs.existsSync(this.backupDir)) {
            fs.ensureDirSync(this.backupDir);
        }
    }

    async createBackup() {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupName = `webapp_backup_${timestamp}`;
        const backupPath = path.join(this.backupDir, `${backupName}.zip`);
        
        return new Promise((resolve, reject) => {
            const output = fs.createWriteStream(backupPath);
            const archive = archiver('zip', { zlib: { level: 9 } });

            output.on('close', () => {
                console.log(`Backup created: ${backupPath} (${archive.pointer()} bytes)`);
                resolve({
                    path: backupPath,
                    size: archive.pointer(),
                    name: `${backupName}.zip`
                });
            });

            archive.on('error', reject);
            archive.pipe(output);

            const excludeDirs = ['backups', 'node_modules', 'temp', 'logs'];
            const excludeFiles = ['*.log', '*.tmp'];

            archive.glob('**/*', {
                cwd: this.webappDir,
                ignore: excludeDirs.map(dir => `${dir}/**/*`).concat(excludeFiles),
                dot: true
            });

            archive.finalize();
        });
    }

    async sendBackupToOwner() {
        try {
            await this.bot.sendMessage(this.ownerId, '🔄 *Memulai proses backup...*\nMohon tunggu sebentar.', {
                parse_mode: 'Markdown'
            });

            const backup = await this.createBackup();
            const stats = fs.statSync(backup.path);
            const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
            
            let message = `✅ *Backup Berhasil Dibuat!*\n\n`;
            message += `📦 *File:* ${backup.name}\n`;
            message += `📊 *Ukuran:* ${fileSizeMB} MB\n`;
            message += `🕐 *Waktu:* ${new Date().toLocaleString('id-ID')}\n\n`;
            message += `📤 *Mengirim file backup...*`;
            
            await this.bot.sendMessage(this.ownerId, message, { parse_mode: 'Markdown' });
            await this.bot.sendDocument(this.ownerId, backup.path, {
                caption: `📦 *Backup WebApp*\nTanggal: ${new Date().toLocaleString('id-ID')}\nUkuran: ${fileSizeMB} MB`,
                parse_mode: 'Markdown'
            });
            
            await this.bot.sendMessage(this.ownerId, '✅ *Backup selesai dan telah dikirim!*', { parse_mode: 'Markdown' });
            await this.cleanupOldBackups(5);
            
            return true;
        } catch (error) {
            console.error('Backup error:', error);
            await this.bot.sendMessage(this.ownerId, `❌ *Error saat backup:*\n\`${error.message}\``, { parse_mode: 'Markdown' });
            return false;
        }
    }

    async cleanupOldBackups(keepCount = 5) {
        try {
            const files = fs.readdirSync(this.backupDir);
            const backupFiles = files
                .filter(f => f.endsWith('.zip'))
                .map(f => ({
                    name: f,
                    path: path.join(this.backupDir, f),
                    mtime: fs.statSync(path.join(this.backupDir, f)).mtime
                }))
                .sort((a, b) => b.mtime - a.mtime);
            
            const toDelete = backupFiles.slice(keepCount);
            for (const file of toDelete) {
                fs.unlinkSync(file.path);
                console.log(`Deleted old backup: ${file.name}`);
            }
        } catch (error) {
            console.error('Cleanup error:', error);
        }
    }

    async scheduleBackup(intervalHours = 24) {
        const intervalMs = intervalHours * 60 * 60 * 1000;
        
        setInterval(async () => {
            console.log('Running scheduled backup...');
            await this.sendBackupToOwner();
        }, intervalMs);
        
        console.log(`Scheduled backup every ${intervalHours} hours`);
        
        setTimeout(async () => {
            await this.sendBackupToOwner();
        }, 10000);
    }
}

if (!process.env.BOT_TOKEN) {
    console.error('❌ Error: BOT_TOKEN tidak ditemukan di .env');
    console.error('   Silakan copy .env.example ke .env dan isi token bot Anda');
    process.exit(1);
}

const botOptions = { polling: true };

if (process.env.LOCAL_API_URL) {
    botOptions.baseApiUrl = process.env.LOCAL_API_URL;
    console.log(`🚀 Using Local Bot API Server: ${process.env.LOCAL_API_URL}`);
    console.log('   File limit: 2GB upload/download');
} else {
    console.log('ℹ️  Using standard Bot API (api.telegram.org)');
    console.log('   File limit: 20MB download, 50MB upload');
}

const bot = new TelegramBot(process.env.BOT_TOKEN, botOptions);

userService.setBot(bot);
console.log('✅ UserService initialized with bot instance');

bot.on('message', async (msg) => {
    if (msg.chat.type === 'private') {
        const chatId = msg.chat.id;
        const isNewUser = userService.saveUser(chatId, bot);
        if (isNewUser) {
            console.log(`🆕 New user registered: ${chatId}`);
        }
    }
});

const backupManager = new BackupManager(bot, SUPER_ADMIN_ID);
console.log('✅ Backup Manager initialized');

global.sessions = new Map();

const dirs = ['temp', 'output'];
dirs.forEach(dir => {
    const dirPath = path.join(__dirname, '..', dir);
    fs.ensureDirSync(dirPath);
});

bot.setMyCommands([
    { command: 'start', description: '🏠 Mulai menggunakan bot' },
    { command: 'help', description: '❓ Bantuan & panduan' },
    { command: 'stats', description: '📊 Statistik bot (Admin)' },
    { command: 'broadcast', description: '📢 Broadcast pesan (Super Admin)' },
    { command: 'sematkan', description: '📌 Sematkan pesan (Admin)' },
    { command: 'pinpesan', description: '📌 Pin pesan ke semua user (Super Admin)' },
    { command: 'rename', description: '📝 Rename/Replace file .dart (Member)' },
    { command: 'buildstatus', description: '📊 Status build (Admin)' },
    { command: 'killbuild', description: '🔪 Hentikan build (Admin)' },
    { command: 'setbuildslot', description: '⚙️ Set slot build user (Super Admin)' },
    { command: 'addowner', description: '👑 Tambah Owner (Super Admin)' },
    { command: 'removeowner', description: '👑 Hapus Owner (Super Admin)' },
    { command: 'listowners', description: '👑 Daftar Owner (Super Admin)' },
]).catch(e => console.error('Failed to set commands:', e.message));

initQueueCallback(bot);

async function checkChannelMembership(userId) {
    const requiredChannel = process.env.REQUIRED_CHANNEL;
    if (!requiredChannel) return true;

    try {
        const member = await bot.getChatMember(requiredChannel, userId);
        return ['member', 'administrator', 'creator'].includes(member.status);
    } catch (error) {
        console.warn(`Channel check failed for ${userId}:`, error.message);
        return true;
    }
}

const ZIP_CONFIG = {
    FOLDER: "/root/webapp/temp",
    OWNER_ID: SUPER_ADMIN_ID,
    MAX_FILE_SIZE: 100,
    ALLOWED_EXTENSIONS: ['.zip', '.rar', '.7z']
};

class ZipManager {
    constructor() {
        this.files = [];
        this.lastUpdate = null;
        this.cacheTimeout = 5 * 60 * 1000;
    }

    getFiles(forceRefresh = false) {
        const now = Date.now();
        if (forceRefresh || !this.lastUpdate || (now - this.lastUpdate) > this.cacheTimeout) {
            this.refreshFiles();
        }
        return this.files;
    }

    refreshFiles() {
        const folder = ZIP_CONFIG.FOLDER;
        if (!fs.existsSync(folder)) {
            this.files = [];
            this.lastUpdate = Date.now();
            return;
        }

        this.files = fs.readdirSync(folder)
            .filter(file => {
                const ext = path.extname(file).toLowerCase();
                return ZIP_CONFIG.ALLOWED_EXTENSIONS.includes(ext);
            })
            .map(file => {
                const stats = fs.statSync(path.join(folder, file));
                return {
                    name: file,
                    size: stats.size,
                    sizeMB: (stats.size / 1024 / 1024).toFixed(2),
                    created: stats.birthtime,
                    modified: stats.mtime,
                    path: path.join(folder, file)
                };
            })
            .sort((a, b) => b.modified - a.modified);

        this.lastUpdate = Date.now();
    }

    getFile(index) {
        if (index < 0 || index >= this.files.length) return null;
        return this.files[index];
    }

    getFileCount() {
        return this.files.length;
    }

    formatFileList() {
        if (!this.files.length) {
            return "📭 *Tidak ada file arsip ditemukan.*";
        }

        let teks = "📦 *Daftar File Arsip*\n\n";
        teks += `📊 Total: ${this.files.length} file\n`;
        teks += `🔄 Terakhir update: ${new Date(this.lastUpdate).toLocaleString()}\n\n`;

        this.files.forEach((file, i) => {
            const sizeColor = file.sizeMB > 50 ? '🔴' : file.sizeMB > 20 ? '🟡' : '🟢';
            teks += `${i + 1}. *${file.name}*\n`;
            teks += `   ${sizeColor} ${file.sizeMB} MB\n`;
            teks += `   📅 ${new Date(file.modified).toLocaleDateString()}\n\n`;
        });

        teks += "📤 *Cara kirim:*\n";
        teks += "`/sendzip <nomor>`\n\n";
        teks += "📌 *Contoh:* `/sendzip 2`\n";
        teks += "🔄 *Refresh:* `/refreshzip`";

        return teks;
    }
}

const zipManager = new ZipManager();

bot.onText(/^\/listzip$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!isSuperAdmin(msg.from.id)) {
        return bot.sendMessage(chatId, "❌ *Akses Ditolak*\nCommand ini hanya untuk Super Admin.", { parse_mode: "Markdown" });
    }

    try {
        const files = zipManager.getFiles(true);
        
        if (!files.length) {
            return bot.sendMessage(chatId, "📭 *Tidak ada file arsip ditemukan.*\n\n💡 Pastikan folder temp berisi file .zip, .rar, atau .7z", { parse_mode: "Markdown" });
        }

        const messageText = zipManager.formatFileList();
        
        const options = {
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "🔄 Refresh", callback_data: "refresh_zip" }],
                    [{ text: "📊 Total File", callback_data: "zip_stats" }],
                    [{ text: "🗑️ Hapus Semua", callback_data: "delete_all_zip" }]
                ]
            }
        };

        await bot.sendMessage(chatId, messageText, options);
    } catch (error) {
        console.error("Error di listzip:", error);
        bot.sendMessage(chatId, "❌ *Terjadi kesalahan*\nGagal membaca daftar file.", { parse_mode: "Markdown" });
    }
});

bot.onText(/^\/sendzip(?:\s+(\d+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;

    if (!isSuperAdmin(msg.from.id)) {
        return bot.sendMessage(chatId, "❌ *Akses Ditolak*\nCommand ini hanya untuk Super Admin.", { parse_mode: "Markdown" });
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ *Format Salah*\nGunakan: `/sendzip <nomor>`\n\nContoh: `/sendzip 2`", { parse_mode: "Markdown" });
    }

    const nomor = parseInt(match[1]);
    
    if (isNaN(nomor) || nomor < 1) {
        return bot.sendMessage(chatId, "❌ *Nomor tidak valid*\nMasukkan nomor positif.", { parse_mode: "Markdown" });
    }

    try {
        const files = zipManager.getFiles(true);
        
        if (!files.length) {
            return bot.sendMessage(chatId, "❌ *Tidak ada file*\nJalankan `/listzip` terlebih dahulu.", { parse_mode: "Markdown" });
        }

        if (nomor > files.length) {
            return bot.sendMessage(chatId, `❌ *Nomor terlalu besar*\nHanya ada ${files.length} file.\n\nGunakan nomor 1 - ${files.length}`, { parse_mode: "Markdown" });
        }

        const file = files[nomor - 1];
        
        if (!fs.existsSync(file.path)) {
            zipManager.refreshFiles();
            const newFiles = zipManager.getFiles();
            if (nomor > newFiles.length || !fs.existsSync(newFiles[nomor - 1]?.path)) {
                return bot.sendMessage(chatId, "❌ *File tidak ditemukan*\nFile mungkin sudah dihapus atau dipindahkan.", { parse_mode: "Markdown" });
            }
        }

        const loadingMsg = await bot.sendMessage(chatId, `⏳ *Mengirim file...*\n📦 ${file.name}\n📊 ${file.sizeMB} MB`, { parse_mode: "Markdown" });

        await bot.sendDocument(chatId, file.path, {
            caption: `📦 *${file.name}*\n📊 *Ukuran:* ${file.sizeMB} MB\n📅 *Dimodifikasi:* ${new Date(file.modified).toLocaleString()}\n\n📤 *Dikirim oleh:* @${msg.from.username || 'Super Admin'}`,
            parse_mode: "Markdown"
        });

        await bot.deleteMessage(chatId, loadingMsg.message_id);

        const confirmMsg = `✅ *File berhasil dikirim!*\n\n📦 ${file.name}\n📊 ${file.sizeMB} MB\n📅 ${new Date(file.modified).toLocaleString()}\n\n💡 Gunakan /listzip untuk melihat daftar lainnya.`;
        await bot.sendMessage(chatId, confirmMsg, { parse_mode: "Markdown" });

    } catch (error) {
        console.error("Error di sendzip:", error);
        bot.sendMessage(chatId, "❌ *Gagal mengirim file*\nTerjadi kesalahan. Coba lagi nanti.", { parse_mode: "Markdown" });
    }
});

bot.onText(/^\/refreshzip$/, async (msg) => {
    const chatId = msg.chat.id;

    if (!isSuperAdmin(msg.from.id)) {
        return bot.sendMessage(chatId, "❌ *Akses Ditolak*", { parse_mode: "Markdown" });
    }

    try {
        zipManager.refreshFiles();
        const count = zipManager.getFileCount();
        bot.sendMessage(chatId, `🔄 *Cache diperbarui*\n📊 Ditemukan ${count} file arsip.`, { parse_mode: "Markdown" });
    } catch (error) {
        bot.sendMessage(chatId, "❌ *Gagal refresh*", { parse_mode: "Markdown" });
    }
});

bot.onText(/^\/deletezip(?:\s+(\d+))?$/, async (msg, match) => {
    const chatId = msg.chat.id;

    if (!isSuperAdmin(msg.from.id)) {
        return bot.sendMessage(chatId, "❌ *Akses Ditolak*", { parse_mode: "Markdown" });
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ *Format Salah*\nGunakan: `/deletezip <nomor>`\n\n⚠️ Peringatan: File akan dihapus permanen!", { parse_mode: "Markdown" });
    }

    const nomor = parseInt(match[1]);
    const files = zipManager.getFiles(true);

    if (isNaN(nomor) || nomor < 1 || nomor > files.length) {
        return bot.sendMessage(chatId, `❌ *Nomor tidak valid*\nGunakan nomor 1 - ${files.length}`, { parse_mode: "Markdown" });
    }

    try {
        const file = files[nomor - 1];
        
        const confirmKeyboard = {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "✅ Ya, Hapus", callback_data: `confirm_delete_${nomor}` },
                        { text: "❌ Batal", callback_data: "cancel_delete" }
                    ]
                ]
            }
        };

        await bot.sendMessage(chatId, 
            `⚠️ *Konfirmasi Hapus*\n\nFile: ${file.name}\nUkuran: ${file.sizeMB} MB\n\nApakah Anda yakin ingin menghapus file ini?`,
            { parse_mode: "Markdown", ...confirmKeyboard }
        );
    } catch (error) {
        bot.sendMessage(chatId, "❌ *Gagal menghapus file*", { parse_mode: "Markdown" });
    }
});

bot.on('callback_query', async (callbackQuery) => {
    const action = callbackQuery.data;
    const chatId = callbackQuery.message.chat.id;
    const messageId = callbackQuery.message.message_id;

    if (!isSuperAdmin(callbackQuery.from.id)) {
        return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Hanya untuk Super Admin!", showAlert: true });
    }

    if (action === "refresh_zip") {
        zipManager.refreshFiles();
        const files = zipManager.getFiles();
        const messageText = zipManager.formatFileList();
        
        await bot.editMessageText(messageText, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "Markdown",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "🔄 Refresh", callback_data: "refresh_zip" }],
                    [{ text: "📊 Total File", callback_data: "zip_stats" }],
                    [{ text: "🗑️ Hapus Semua", callback_data: "delete_all_zip" }]
                ]
            }
        });
        
        await bot.answerCallbackQuery(callbackQuery.id, { text: "✅ Daftar diperbarui!" });
    }

    if (action === "zip_stats") {
        const files = zipManager.getFiles();
        const totalSize = files.reduce((sum, f) => sum + f.size, 0);
        const totalSizeMB = (totalSize / 1024 / 1024).toFixed(2);
        
        await bot.answerCallbackQuery(callbackQuery.id, {
            text: `Total: ${files.length} file, ${totalSizeMB} MB`,
            showAlert: true
        });
    }

    if (action.startsWith("confirm_delete_")) {
        const nomor = parseInt(action.split("_")[2]);
        const files = zipManager.getFiles();
        const file = files[nomor - 1];
        
        if (file) {
            try {
                fs.unlinkSync(file.path);
                zipManager.refreshFiles();
                await bot.editMessageText(`✅ *File berhasil dihapus*\n\n${file.name}`, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: "Markdown"
                });
                await bot.answerCallbackQuery(callbackQuery.id, { text: "✅ File dihapus!" });
            } catch (error) {
                await bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Gagal hapus file", showAlert: true });
            }
        }
    }

    if (action === "cancel_delete") {
        await bot.deleteMessage(chatId, messageId);
        await bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Dibatalkan" });
    }

    if (action === "delete_all_zip") {
        const files = zipManager.getFiles();
        if (!files.length) {
            return bot.answerCallbackQuery(callbackQuery.id, { text: "📭 Tidak ada file untuk dihapus", showAlert: true });
        }

        const confirmKeyboard = {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: "⚠️ Ya, Hapus Semua", callback_data: "confirm_delete_all" },
                        { text: "❌ Batal", callback_data: "cancel_delete" }
                    ]
                ]
            }
        };

        await bot.editMessageText(`⚠️ *PERINGATAN*\n\nAnda akan menghapus SEMUA file arsip (${files.length} file).\n\nTotal size: ${files.reduce((sum, f) => sum + f.size, 0) / 1024 / 1024} MB\n\nTindakan ini TIDAK DAPAT DIBATALKAN!`, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "Markdown",
            ...confirmKeyboard
        });
    }

    if (action === "confirm_delete_all") {
        const files = zipManager.getFiles();
        let deleted = 0;
        
        for (const file of files) {
            try {
                fs.unlinkSync(file.path);
                deleted++;
            } catch (error) {
                console.error(`Gagal hapus ${file.name}:`, error);
            }
        }
        
        zipManager.refreshFiles();
        await bot.editMessageText(`✅ *Selesai*\n\nBerhasil menghapus ${deleted} dari ${files.length} file.`, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "Markdown"
        });
        await bot.answerCallbackQuery(callbackQuery.id, { text: `✅ ${deleted} file dihapus!` });
    }
});

bot.onText(/^\/ziphelp$/, async (msg) => {
    const chatId = msg.chat.id;
    const isOwner = isSuperAdmin(msg.from.id);

    let helpText = "📚 *Bantuan Command ZIP*\n\n";

    if (isOwner) {
        helpText += "*Untuk Super Admin:*\n" +
            "📋 `/listzip` - Lihat daftar file\n" +
            "📤 `/sendzip <nomor>` - Kirim file\n" +
            "🔄 `/refreshzip` - Refresh cache\n" +
            "🗑️ `/deletezip <nomor>` - Hapus file\n" +
            "⚠️ `/deleteallzip` - Hapus semua file\n\n";
    }

    helpText += "📁 *Folder:* `" + ZIP_CONFIG.FOLDER + "`\n" +
        "📊 *Format:* " + ZIP_CONFIG.ALLOWED_EXTENSIONS.join(', ') + "\n" +
        "💾 *Max Size:* " + ZIP_CONFIG.MAX_FILE_SIZE + " MB";

    bot.sendMessage(chatId, helpText, { parse_mode: "Markdown" });
});

bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;

    if (maintenanceService.isEnabled() && !isAdmin(chatId)) {
        return bot.sendMessage(chatId, `
⚠️ <b>MAINTENANCE MODE</b>
━━━━━━━━━━━━━━━━━━

Bot sedang dalam perbaikan server.
Hanya <b>Owner</b> yang dapat mengakses saat ini.

<i>Mohon coba lagi nanti.</i>
        `.trim(), { parse_mode: 'HTML' });
    }

    userService.saveUser(chatId, bot);

    const isMember = await checkAllChannelMembership(chatId);
    if (!isMember) {
        const channelButtons = [];
        
        const channels = process.env.REQUIRED_CHANNELS ? process.env.REQUIRED_CHANNELS.split(',') : [];
        
        if (channels.length === 0) {
            const singleChannel = process.env.REQUIRED_CHANNEL;
            if (singleChannel) {
                channels.push(singleChannel);
            }
        }

        for (const channel of channels) {
            const cleanChannel = channel.trim().replace('@', '');
            channelButtons.push([
                { text: `📢 Join Channel ${cleanChannel}`, url: `https://t.me/${cleanChannel}` }
            ]);
        }

        channelButtons.push([
            { text: '🔄 Coba Lagi', callback_data: 'check_membership' }
        ]);

        return bot.sendMessage(chatId, `
⚠️ <b>VERIFIKASI DIPERLUKAN</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━

Untuk menggunakan bot ini, Anda wajib join channel-channel berikut:

${channels.map((ch, i) => `${i + 1}. @${ch.trim().replace('@', '')}`).join('\n')}

📌 <b>Langkah:</b>
1️⃣ Klik tombol join untuk setiap channel
2️⃣ Setelah join semua, klik tombol "🔄 Coba Lagi"
3️⃣ Menu utama akan muncul

━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>⚠️ Pastikan Anda sudah join SEMUA channel di atas!</i>
        `.trim(), {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: channelButtons
            }
        });
    }

    handleStart(bot, msg);
});

async function checkAllChannelMembership(userId) {
    const channels = [];
    
    const envChannels = process.env.REQUIRED_CHANNELS ? process.env.REQUIRED_CHANNELS.split(',') : [];
    if (envChannels.length > 0) {
        for (const ch of envChannels) {
            channels.push(ch.trim().replace('@', ''));
        }
    } else if (process.env.REQUIRED_CHANNEL) {
        channels.push(process.env.REQUIRED_CHANNEL.replace('@', ''));
    }

    if (channels.length === 0) return true;

    for (const channel of channels) {
        try {
            const member = await bot.getChatMember(`@${channel}`, userId);
            const isMember = ['member', 'administrator', 'creator'].includes(member.status);
            if (!isMember) return false;
        } catch (error) {
            console.warn(`Channel check failed for ${channel}:`, error.message);
            return false;
        }
    }

    return true;
}

// GABUNGAN CALLBACK QUERY HANDLER
bot.on('callback_query', async (query) => {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const data = query.data;

    // 1. HANDLE PAYMENT CALLBACKS
    if (data === 'buy_access' || 
        data === 'buy_owner' || 
        data === 'buy_reseller' || 
        data === 'buy_member' ||
        data.startsWith('buy_member_') ||
        data === 'back_buy_menu' ||
        data.startsWith('pay_') ||
        data === 'check_payment' ||
        data === 'cancel_payment') {
        await handlePaymentCallback(bot, query);
        return;
    }

    // 2. HANDLE CHANNEL MEMBERSHIP
    if (data === 'check_membership') {
        const userId = query.from.id;
        await bot.answerCallbackQuery(query.id, { text: '🔍 Memeriksa keanggotaan...' });

        const isMember = await checkAllChannelMembership(userId);

        if (isMember) {
            await bot.editMessageText(`
✅ <b>VERIFIKASI BERHASIL!</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━

Selamat! Anda sudah join semua channel.

Tekan tombol di bawah untuk memulai:
            `.trim(), {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🚀 Mulai Bot', callback_data: 'start_bot' }]
                    ]
                }
            });
        } else {
            const channels = [];
            const envChannels = process.env.REQUIRED_CHANNELS ? process.env.REQUIRED_CHANNELS.split(',') : [];
            if (envChannels.length > 0) {
                for (const ch of envChannels) {
                    channels.push(ch.trim().replace('@', ''));
                }
            } else if (process.env.REQUIRED_CHANNEL) {
                channels.push(process.env.REQUIRED_CHANNEL.replace('@', ''));
            }

            const channelButtons = [];
            for (const channel of channels) {
                channelButtons.push([
                    { text: `📢 Join Channel ${channel}`, url: `https://t.me/${channel}` }
                ]);
            }
            channelButtons.push([
                { text: '🔄 Coba Lagi', callback_data: 'check_membership' }
            ]);

            await bot.editMessageText(`
⚠️ <b>BELUM COMPLETE!</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━

Anda belum join SEMUA channel berikut:

${channels.map((ch, i) => `${i + 1}. @${ch}`).join('\n')}

Silakan join semua channel terlebih dahulu,
lalu klik tombol "🔄 Coba Lagi"
            `.trim(), {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: channelButtons
                }
            });
        }
        return;
    }

    if (data === 'start_bot') {
        const msg = {
            chat: { id: chatId },
            from: { id: query.from.id }
        };
        
        await bot.deleteMessage(chatId, messageId).catch(() => {});
        handleStart(bot, msg);
        await bot.answerCallbackQuery(query.id, { text: '🚀 Memulai bot...' });
        return;
    }

    // 3. HANDLE BROADCAST - HANYA SUPER ADMIN
    if (data.startsWith('bc_')) {
        if (!isSuperAdmin(query.from.id)) {
            return bot.answerCallbackQuery(query.id, { text: '⛔ Hanya Super Admin!', show_alert: true });
        }

        const action = data;
        const bc = global.pendingBroadcast;

        if (!bc || bc.adminId !== query.from.id) {
            return bot.answerCallbackQuery(query.id, { 
                text: '⚠️ Session expired. Kirim /broadcast lagi.', 
                show_alert: true 
            });
        }

        if (action === 'bc_cancel') {
            await bot.editMessageText('❌ <b>Broadcast dibatalkan.</b>', {
                chat_id: bc.adminId,
                message_id: bc.confirmMsgId,
                parse_mode: 'HTML'
            });
            global.pendingBroadcast = null;
            return bot.answerCallbackQuery(query.id, { text: 'Broadcast dibatalkan' });
        }

        if (action === 'bc_confirm') {
            await bot.answerCallbackQuery(query.id, { text: '🚀 Memulai broadcast...' });

            const startTime = Date.now();
            let success = 0, failed = 0;
            const total = bc.users.length;
            const failedUsersList = [];

            const getProgressBar = (current, total) => {
                const percent = total > 0 ? Math.round((current / total) * 100) : 0;
                const filled = Math.round(percent / 5);
                const empty = 20 - filled;
                return '█'.repeat(Math.max(0, filled)) + '░'.repeat(Math.max(0, empty));
            };

            await bot.editMessageText(`
╔══════════════════════════╗
   🚀  <b>BROADCAST IN PROGRESS</b>  🚀
╚══════════════════════════╝

📊 <b>Progress:</b>
<code>[${getProgressBar(0, total)}]</code> 0%

📬 Sent: <code>0</code>
❌ Failed: <code>0</code>
👥 Total: <code>${total}</code>

⏱ Elapsed: <code>0s</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>⏳ Mohon tunggu...</i>
            `.trim(), {
                chat_id: bc.adminId,
                message_id: bc.confirmMsgId,
                parse_mode: 'HTML'
            });

            let lastUpdate = 0;

            for (let i = 0; i < bc.users.length; i++) {
                const userId = bc.users[i];

                try {
                    if (bc.isReply) {
                        await bot.sendMessage(userId, `
╔═══════════════════════════════╗
     📢  <b>PENGUMUMAN RESMI</b>  📢
╚═══════════════════════════════╝
                        `.trim(), { parse_mode: 'HTML' });
                        await bot.forwardMessage(userId, bc.adminId, bc.replyMsgId);
                    } else {
                        const formattedMessage = `
╔═══════════════════════════════╗
     📢  <b>PENGUMUMAN RESMI</b>  📢
╚═══════════════════════════════╝

${bc.textContent || '⚠️ Tidak ada konten pesan'}

━━━━━━━━━━━━━━━━━━━━━━━━━━
🤖 <i>Pesan otomatis dari Web2APK Bot</i>
📅 <i>${new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</i>
                        `.trim();
                        await bot.sendMessage(userId, formattedMessage, { parse_mode: 'HTML' });
                    }
                    success++;
                } catch (e) {
                    failed++;
                    
                    if (e.response?.body?.error_code === 403) {
                        failedUsersList.push(userId);
                        console.log(`🔴 User ${userId} marked for removal (blocked/deleted)`);
                    } else if (e.response?.body?.error_code === 400) {
                        failedUsersList.push(userId);
                        console.log(`🔴 User ${userId} marked for removal (invalid)`);
                    }
                }

                const current = i + 1;
                if (current - lastUpdate >= 10 || current === total) {
                    const elapsed = Math.round((Date.now() - startTime) / 1000);
                    const percent = total > 0 ? Math.round((current / total) * 100) : 0;

                    await bot.editMessageText(`
╔══════════════════════════╗
   🚀  <b>BROADCAST IN PROGRESS</b>  🚀
╚══════════════════════════╝

📊 <b>Progress:</b>
<code>[${getProgressBar(current, total)}]</code> ${percent}%

📬 Sent: <code>${success}</code>
❌ Failed: <code>${failed}</code>
👥 Total: <code>${total}</code>

⏱ Elapsed: <code>${elapsed}s</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>⏳ ${current}/${total} processed...</i>
                    `.trim(), {
                        chat_id: bc.adminId,
                        message_id: bc.confirmMsgId,
                        parse_mode: 'HTML'
                    }).catch(() => {});

                    lastUpdate = current;
                }

                await new Promise(r => setTimeout(r, 50));
            }

            let removedCount = 0;
            if (failedUsersList.length > 0) {
                console.log(`🗑️ Removing ${failedUsersList.length} failed users from database...`);
                removedCount = userService.removeUsers(failedUsersList);
                console.log(`✅ Removed ${removedCount} users from database`);
            }

            const totalTime = Math.round((Date.now() - startTime) / 1000);
            const successRate = total > 0 ? Math.round((success / total) * 100) : 0;

            let failedUsersMessage = '';
            if (failedUsersList.length > 0) {
                const shownUsers = failedUsersList.slice(0, 10);
                const remaining = failedUsersList.length - 10;
                failedUsersMessage = `\n\n📋 <b>Users Removed:</b>\n<code>${shownUsers.join('\n')}</code>`;
                if (remaining > 0) {
                    failedUsersMessage += `\n<i>... dan ${remaining} lainnya</i>`;
                }
            }

            await bot.editMessageText(`
╔══════════════════════════╗
   ✅  <b>BROADCAST COMPLETE</b>  ✅
╚══════════════════════════╝

📊 <b>Final Result:</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<code>[████████████████████]</code> 100%

📬 Sent: <code>${success}</code> ✓
❌ Failed: <code>${failed}</code>
📈 Success Rate: <code>${successRate}%</code>

⏱ Total Time: <code>${totalTime}s</code>
📅 Completed: <code>${new Date().toLocaleString('id-ID')}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
${failed > 0 ? `⚠️ <i>${removedCount} users telah dihapus dari database (blocked/deleted)</i>` : '🎉 <i>Semua pesan terkirim dengan sukses!</i>'}
${failedUsersMessage}
            `.trim(), {
                chat_id: bc.adminId,
                message_id: bc.confirmMsgId,
                parse_mode: 'HTML'
            });

            global.pendingBroadcast = null;
        }
        return;
    }

    // 4. HANDLE PINPESAN - HANYA SUPER ADMIN
    if (data.startsWith('pinpesan_')) {
        if (!isSuperAdmin(query.from.id)) {
            return bot.answerCallbackQuery(query.id, { text: '⛔ Hanya Super Admin!', show_alert: true });
        }

        const action = data;
        const pin = global.pendingPinpesan;

        if (!pin || pin.adminId !== query.from.id) {
            return bot.answerCallbackQuery(query.id, { 
                text: '⚠️ Session expired. Kirim /pinpesan lagi.', 
                show_alert: true 
            });
        }

        if (action === 'pinpesan_cancel') {
            await bot.editMessageText('❌ <b>Pin Pesan dibatalkan.</b>', {
                chat_id: pin.adminId,
                message_id: pin.confirmMsgId,
                parse_mode: 'HTML'
            });
            global.pendingPinpesan = null;
            return bot.answerCallbackQuery(query.id, { text: 'Pin Pesan dibatalkan' });
        }

        if (action === 'pinpesan_confirm') {
            await bot.answerCallbackQuery(query.id, { text: '🚀 Memulai pin pesan...' });

            const startTime = Date.now();
            let success = 0, failed = 0, pinned = 0;
            const total = pin.users.length;

            const getProgressBar = (current, total) => {
                const percent = total > 0 ? Math.round((current / total) * 100) : 0;
                const filled = Math.round(percent / 5);
                const empty = 20 - filled;
                return '█'.repeat(Math.max(0, filled)) + '░'.repeat(Math.max(0, empty));
            };

            await bot.editMessageText(`
╔══════════════════════════╗
   📌  <b>PIN PESAN PROGRESS</b>  📌
╚══════════════════════════╝

📊 <b>Progress:</b>
<code>[${getProgressBar(0, total)}]</code> 0%

📬 Sent: <code>0</code>
📌 Pinned: <code>0</code>
❌ Failed: <code>0</code>
👥 Total: <code>${total}</code>

⏱ Elapsed: <code>0s</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>⏳ Mengirim & mem-pin pesan...</i>
            `.trim(), {
                chat_id: pin.adminId,
                message_id: pin.confirmMsgId,
                parse_mode: 'HTML'
            });

            let lastUpdate = 0;
            const failedUsersList = [];

            for (let i = 0; i < pin.users.length; i++) {
                const userId = pin.users[i];

                try {
                    const forwardedMsg = await bot.forwardMessage(userId, pin.replyChatId, pin.replyMsgId);
                    success++;

                    try {
                        await bot.pinChatMessage(userId, forwardedMsg.message_id, { disable_notification: true });
                        pinned++;
                    } catch (pinError) {
                        console.log(`Gagal pin untuk user ${userId}:`, pinError.message);
                    }

                } catch (e) {
                    failed++;
                    if (e.response?.body?.error_code === 403) {
                        failedUsersList.push(userId);
                        console.log(`🔴 User ${userId} marked for removal (blocked/deleted)`);
                    }

                    try {
                        const replyMsg = await bot.forwardMessage(pin.adminId, pin.replyChatId, pin.replyMsgId);
                        if (replyMsg.text) {
                            const sentMsg = await bot.sendMessage(userId, replyMsg.text, {
                                parse_mode: 'HTML',
                                disable_web_page_preview: true
                            });
                            success++;
                            try {
                                await bot.pinChatMessage(userId, sentMsg.message_id, { disable_notification: true });
                                pinned++;
                            } catch (pinError2) {
                                console.log(`Gagal pin (retry) untuk user ${userId}:`, pinError2.message);
                            }
                        }
                    } catch (retryError) {
                        console.log(`Retry gagal untuk user ${userId}:`, retryError.message);
                    }
                }

                const current = i + 1;
                if (current - lastUpdate >= 10 || current === total) {
                    const elapsed = Math.round((Date.now() - startTime) / 1000);
                    const percent = total > 0 ? Math.round((current / total) * 100) : 0;

                    await bot.editMessageText(`
╔══════════════════════════╗
   📌  <b>PIN PESAN PROGRESS</b>  📌
╚══════════════════════════╝

📊 <b>Progress:</b>
<code>[${getProgressBar(current, total)}]</code> ${percent}%

📬 Sent: <code>${success}</code>
📌 Pinned: <code>${pinned}</code>
❌ Failed: <code>${failed}</code>
👥 Total: <code>${total}</code>

⏱ Elapsed: <code>${elapsed}s</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>⏳ ${current}/${total} processed...</i>
                    `.trim(), {
                        chat_id: pin.adminId,
                        message_id: pin.confirmMsgId,
                        parse_mode: 'HTML'
                    }).catch(() => {});

                    lastUpdate = current;
                }

                await new Promise(r => setTimeout(r, 50));
            }

            let removedCount = 0;
            if (failedUsersList.length > 0) {
                console.log(`🗑️ Removing ${failedUsersList.length} failed users from database...`);
                removedCount = userService.removeUsers(failedUsersList);
                console.log(`✅ Removed ${removedCount} users from database`);
            }

            const totalTime = Math.round((Date.now() - startTime) / 1000);
            const successRate = total > 0 ? Math.round((success / total) * 100) : 0;
            const pinRate = success > 0 ? Math.round((pinned / success) * 100) : 0;

            let failedUsersMessage = '';
            if (failedUsersList.length > 0) {
                const shownUsers = failedUsersList.slice(0, 10);
                const remaining = failedUsersList.length - 10;
                failedUsersMessage = `\n\n📋 <b>Users Removed:</b>\n<code>${shownUsers.join('\n')}</code>`;
                if (remaining > 0) {
                    failedUsersMessage += `\n<i>... dan ${remaining} lainnya</i>`;
                }
            }

            await bot.editMessageText(`
╔══════════════════════════╗
   ✅  <b>PIN PESAN SELESAI</b>  ✅
╚══════════════════════════╝

📊 <b>Final Result:</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<code>[████████████████████]</code> 100%

📬 Sent: <code>${success}</code> ✓
📌 Pinned: <code>${pinned}</code>
❌ Failed: <code>${failed}</code>
📈 Success Rate: <code>${successRate}%</code>
📌 Pin Rate: <code>${pinRate}%</code>

⏱ Total Time: <code>${totalTime}s</code>
📅 Completed: <code>${new Date().toLocaleString('id-ID')}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
${failed > 0 ? `⚠️ <i>${removedCount} users telah dihapus dari database (blocked/deleted)</i>` : '🎉 <i>Semua pesan terkirim & ter-pin dengan sukses!</i>'}
${failedUsersMessage}
            `.trim(), {
                chat_id: pin.adminId,
                message_id: pin.confirmMsgId,
                parse_mode: 'HTML'
            });

            global.pendingPinpesan = null;
        }
        return;
    }

    // 5. HANDLE LISTKEY PAGINATION
    if (data.startsWith('listkey_page_')) {
        if (!isAdmin(query.from.id)) {
            return bot.answerCallbackQuery(query.id, { text: '⛔ Akses ditolak' });
        }

        const page = parseInt(data.replace('listkey_page_', ''), 10);
        await bot.answerCallbackQuery(query.id);
        await showLicenseKeyPage(bot, chatId, page, messageId);
        return;
    }

    // 6. HANDLE OTHER CALLBACKS (dari callbackHandler)
    userService.saveUser(query.from.id, bot);
    handleCallback(bot, query);
});

bot.onText(/\/help/, (msg) => handleStart(bot, msg));

bot.onText(/\/backup/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (isSuperAdmin(userId)) {
        await backupManager.sendBackupToOwner();
    } else {
        bot.sendMessage(chatId, '❌ Anda tidak memiliki izin untuk menggunakan perintah ini.');
    }
});

bot.onText(/\/backupstatus/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (isSuperAdmin(userId)) {
        try {
            const configPath = path.join(__dirname, '../backups/config.json');
            const config = await fs.readJson(configPath).catch(() => null);
            const backupsDir = path.join(__dirname, '../backups');
            const backups = fs.existsSync(backupsDir) ? fs.readdirSync(backupsDir).filter(f => f.endsWith('.zip')) : [];
            
            let message = `📊 *BACKUP STATUS*\n━━━━━━━━━━━━━━━━━━\n`;
            message += `📦 Total backups: ${backups.length}\n`;
            if (config && config.interval) {
                message += `⏰ Schedule: Setiap ${config.interval} jam\n`;
                message += `📅 Last set: ${new Date(config.lastSet).toLocaleString('id-ID')}\n`;
            } else {
                message += `⏰ Schedule: Tidak diatur\n`;
            }
            message += `💾 Backup folder: ${backupsDir}\n`;
            
            let totalSize = 0;
            for (const backup of backups) {
                const stat = fs.statSync(path.join(backupsDir, backup));
                totalSize += stat.size;
            }
            message += `📊 Total size: ${(totalSize / (1024 * 1024)).toFixed(2)} MB\n`;
            
            if (backups.length > 0) {
                const lastBackups = backups.slice(-3).reverse();
                message += `\n📋 *Last 3 backups:*\n`;
                for (const backup of lastBackups) {
                    const stat = fs.statSync(path.join(backupsDir, backup));
                    const sizeMB = (stat.size / (1024 * 1024)).toFixed(2);
                    const date = stat.mtime.toLocaleString('id-ID');
                    message += `• ${backup.substring(0, 30)}... (${sizeMB}MB) - ${date}\n`;
                }
            }
            
            bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
        } catch (error) {
            bot.sendMessage(chatId, `❌ Error: ${error.message}`);
        }
    } else {
        bot.sendMessage(chatId, '❌ Anda tidak memiliki izin.');
    }
});

bot.onText(/\/setbackup (\d+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const hours = parseInt(match[1]);
    
    if (isSuperAdmin(userId)) {
        if (hours >= 1 && hours <= 168) {
            const backupConfig = {
                interval: hours,
                lastSet: new Date().toISOString()
            };
            const configPath = path.join(__dirname, '../backups/config.json');
            await fs.ensureDir(path.dirname(configPath));
            await fs.writeJson(configPath, backupConfig, { spaces: 2 });
            
            bot.sendMessage(chatId, `✅ Jadwal backup diatur setiap ${hours} jam.\nBackup otomatis akan berjalan.`);
            
            if (global.backupInterval) clearInterval(global.backupInterval);
            global.backupInterval = setInterval(async () => {
                console.log('Auto backup running...');
                await backupManager.sendBackupToOwner();
            }, hours * 60 * 60 * 1000);
        } else {
            bot.sendMessage(chatId, '❌ Interval harus antara 1-168 jam.');
        }
    } else {
        bot.sendMessage(chatId, '❌ Anda tidak memiliki izin.');
    }
});

bot.onText(/\/stats/, async (msg) => {
    if (!isAdmin(msg.chat.id)) return;

    const stats = `
📊 <b>BOT STATISTICS</b>
━━━━━━━━━━━━━━━━━━
👥 Total Users: <code>${userService.getCount()}</code>
🔄 Active Sessions: <code>${global.sessions.size}</code>
⏱ Uptime: <code>${Math.floor(process.uptime() / 60)} minutes</code>
━━━━━━━━━━━━━━━━━━
    `.trim();

    bot.sendMessage(msg.chat.id, stats, { parse_mode: 'HTML' });
});

bot.onText(/\/addreseller(?:\s+(.+))?/, async (msg, match) => {
    if (!isAdmin(msg.chat.id)) return;

    const input = match[1];
    if (!input) {
        return bot.sendMessage(msg.chat.id, `
👥 <b>ADD RESELLER</b>
━━━━━━━━━━━━━━━━━━

<b>Penggunaan:</b>
<code>/addreseller telegram_id,nama_reseller</code>

<b>Contoh:</b>
<code>/addreseller 123456789,BudiReseller</code>
        `.trim(), { parse_mode: 'HTML' });
    }

    const parts = input.split(',').map(p => p.trim());
    if (parts.length !== 2) {
        return bot.sendMessage(msg.chat.id, '❌ Format salah! Gunakan: <code>/addreseller id,nama</code>', { parse_mode: 'HTML' });
    }

    const [userId, name] = parts;

    if (isNaN(parseInt(userId, 10))) {
        return bot.sendMessage(msg.chat.id, '❌ User ID harus berupa angka!', { parse_mode: 'HTML' });
    }

    const result = resellerService.addReseller(userId, name);

    if (result.success) {
        bot.sendMessage(msg.chat.id, `
✅ <b>RESELLER ADDED</b>
━━━━━━━━━━━━━━━━━━
👤 User ID: <code>${userId}</code>
📝 Name: <b>${name}</b>

<i>User tersebut sekarang dapat akses /addkey dan tools lainnya.</i>
        `.trim(), { parse_mode: 'HTML' });

        bot.sendMessage(userId, `
🎉 <b>Selamat! Anda telah diangkat menjadi Reseller.</b>

<b>Akses Anda:</b>
✅ Membuat License Key (/addkey)
✅ Memperpanjang License Key (/extendkey)
✅ Akses Project Tools (Analyze, Cleanup, Build ZIP)
❌ Hapus License Key (Hubungi Admin)
        `.trim(), { parse_mode: 'HTML' }).catch(() => { });

    } else {
        bot.sendMessage(msg.chat.id, `❌ <b>Gagal:</b> ${result.error}`, { parse_mode: 'HTML' });
    }
});

bot.onText(/\/delreseller(?:\s+(.+))?/, async (msg, match) => {
    if (!isAdmin(msg.chat.id)) return;

    const userId = match[1]?.trim();
    if (!userId) {
        return bot.sendMessage(msg.chat.id, '❌ Masukkan User ID reseller yang akan dihapus.', { parse_mode: 'HTML' });
    }

    const result = resellerService.removeReseller(userId);

    if (result.success) {
        bot.sendMessage(msg.chat.id, `✅ User ID <code>${userId}</code> telah dihapus dari daftar reseller.`, { parse_mode: 'HTML' });
    } else {
        bot.sendMessage(msg.chat.id, `❌ <b>Gagal:</b> ${result.error}`, { parse_mode: 'HTML' });
    }
});

bot.onText(/\/listreseller/, async (msg) => {
    if (!isAdmin(msg.chat.id)) return;

    const resellers = resellerService.listResellers();

    if (resellers.length === 0) {
        return bot.sendMessage(msg.chat.id, '📋 Belum ada reseller terdaftar.', { parse_mode: 'HTML' });
    }

    let message = `
👥 <b>DAFTAR RESELLER</b> (${resellers.length})
━━━━━━━━━━━━━━━━━━
`;

    resellers.forEach((r, i) => {
        message += `
${i + 1}. <b>${r.name}</b>
   ID: <code>${r.id}</code>
   Sejak: ${new Date(r.createdAt).toLocaleDateString('id-ID')}
`;
    });

    bot.sendMessage(msg.chat.id, message.trim(), { parse_mode: 'HTML' });
});

bot.onText(/\/addkey(?:\s+(.+))?/, async (msg, match) => {
    if (!isAdmin(msg.chat.id) && !isReseller(msg.chat.id)) return;

    const input = match[1];
    if (!input) {
        return bot.sendMessage(msg.chat.id, `
🔑 <b>ADD LICENSE KEY</b>
━━━━━━━━━━━━━━━━━━

<b>Penggunaan:</b>
<code>/addkey username,hari,telegram_id</code>

<b>Contoh:</b>
<code>/addkey john,30,123456789</code>
<code>/addkey user123,7,987654321</code>

💡 <i>Hari harus antara 1-365</i>

⚠️ <b>PENTING:</b>
<i>Pastikan user sudah /start bot ini terlebih dahulu agar link download dapat dikirim ke Telegram mereka!</i>
        `.trim(), { parse_mode: 'HTML' });
    }

    const parts = input.split(',').map(p => p.trim());
    if (parts.length !== 3) {
        return bot.sendMessage(msg.chat.id, '❌ Format salah! Gunakan: <code>/addkey username,hari,telegram_id</code>', { parse_mode: 'HTML' });
    }

    const [username, daysStr, telegramId] = parts;
    const days = parseInt(daysStr, 10);

    if (isNaN(days)) {
        return bot.sendMessage(msg.chat.id, '❌ Jumlah hari harus berupa angka!', { parse_mode: 'HTML' });
    }

    if (!telegramId || isNaN(parseInt(telegramId, 10))) {
        return bot.sendMessage(msg.chat.id, '❌ Telegram ID harus berupa angka!', { parse_mode: 'HTML' });
    }

    const result = licenseKeyService.createKey(username, days, telegramId);

    if (result.success) {
        bot.sendMessage(msg.chat.id, `
✅ <b>LICENSE KEY CREATED</b>
━━━━━━━━━━━━━━━━━━

👤 <b>Username:</b> <code>${result.username}</code>
🔑 <b>Key:</b> <code>${result.key}</code>
📅 <b>Berlaku:</b> ${result.days} hari
⏰ <b>Expired:</b> ${new Date(result.expiresAt).toLocaleDateString('id-ID', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        })}
📱 <b>Telegram ID:</b> <code>${result.telegramId}</code>

📤 <i>Mengirim data ke user...</i>
        `.trim(), { parse_mode: 'HTML' });

        const loginUrl = process.env.WEB_URL || `http://localhost:${process.env.WEB_PORT || 3000}`;

        try {
            await bot.sendMessage(telegramId, `
╔═══════════════════════════════╗
     🎉  <b>AKUN ANDA TELAH DIBUAT</b>  🎉
╚═══════════════════════════════╝

Selamat! Akun Web2APK Anda telah berhasil dibuat.

━━━━━━━━━━━━━━━━━━━━━━━━━━

👤 <b>Username:</b>
<code>${result.username}</code>

🔑 <b>License Key:</b>
<code>${result.key}</code>

📅 <b>Berlaku hingga:</b>
${new Date(result.expiresAt).toLocaleDateString('id-ID', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            })}

━━━━━━━━━━━━━━━━━━━━━━━━━━

🌐 <b>Link Login:</b>
${loginUrl}/login.html

📱 <b>Cara Menggunakan:</b>
1. Klik link di atas atau buka di browser
2. Login dengan username dan key
3. Mulai convert URL atau ZIP menjadi APK!

⚠️ <i>Simpan data ini dengan baik. Jangan bagikan ke orang lain.</i>

━━━━━━━━━━━━━━━━━━━━━━━━━━
🤖 <i>Web2APK Bot - Auto Generated</i>
            `.trim(), { parse_mode: 'HTML' });

            bot.sendMessage(msg.chat.id, `✅ Data akun berhasil dikirim ke Telegram ID <code>${telegramId}</code>`, { parse_mode: 'HTML' });
        } catch (sendError) {
            bot.sendMessage(msg.chat.id, `
⚠️ <b>Gagal mengirim ke user!</b>
━━━━━━━━━━━━━━━━━━
Error: ${sendError.message}

<i>Kemungkinan penyebab:</i>
• User belum pernah /start bot ini
• Telegram ID salah
• User memblokir bot

💡 <i>Silakan kirim data akun secara manual ke user.</i>
            `.trim(), { parse_mode: 'HTML' });
        }
    } else {
        bot.sendMessage(msg.chat.id, `❌ <b>Gagal:</b> ${result.error}`, { parse_mode: 'HTML' });
    }
});

const KEYS_PER_PAGE = 5;

bot.onText(/\/listkey/, async (msg) => {
    if (!isAdmin(msg.chat.id)) return;
    await showLicenseKeyPage(bot, msg.chat.id, 0);
});

async function showLicenseKeyPage(bot, chatId, page, messageId = null) {
    const keys = licenseKeyService.listKeys();

    if (keys.length === 0) {
        const emptyMsg = `
📋 <b>LICENSE KEYS</b>
━━━━━━━━━━━━━━━━━━

<i>Belum ada license key.</i>

💡 Gunakan <code>/addkey username,hari,telegram_id</code> untuk membuat key baru.
        `.trim();

        if (messageId) {
            return bot.editMessageText(emptyMsg, { chat_id: chatId, message_id: messageId, parse_mode: 'HTML' });
        }
        return bot.sendMessage(chatId, emptyMsg, { parse_mode: 'HTML' });
    }

    const totalPages = Math.ceil(keys.length / KEYS_PER_PAGE);
    const currentPage = Math.max(0, Math.min(page, totalPages - 1));
    const startIdx = currentPage * KEYS_PER_PAGE;
    const pageKeys = keys.slice(startIdx, startIdx + KEYS_PER_PAGE);

    let message = `
📋 <b>LICENSE KEYS</b> (${keys.length})
━━━━━━━━━━━━━━━━━━
`;

    pageKeys.forEach((k, i) => {
        const status = k.isExpired ? '🔴 Expired' : (k.deviceId ? '🟢 Active' : '🟡 Unused');
        message += `
${startIdx + i + 1}. <b>${k.username}</b>
   🔑 <code>${k.key}</code>
   ${status} ${!k.isExpired ? `(${k.daysLeft} hari lagi)` : ''}
   📱 ${k.deviceId ? `Device: <code>${k.deviceId.substring(0, 12)}...</code>` : 'Belum login'}
   📲 Telegram: ${k.telegramId ? `<code>${k.telegramId}</code>` : '<i>Tidak ada</i>'}
`;
    });

    message += `
━━━━━━━━━━━━━━━━━━
📄 Halaman ${currentPage + 1}/${totalPages}
💡 <code>/delkey username</code> untuk hapus
💡 <code>/extendkey user,hari</code> untuk perpanjang`;

    const buttons = [];
    if (currentPage > 0) {
        buttons.push({ text: '◀️ Prev', callback_data: `listkey_page_${currentPage - 1}` });
    }
    if (currentPage < totalPages - 1) {
        buttons.push({ text: 'Next ▶️', callback_data: `listkey_page_${currentPage + 1}` });
    }

    const keyboard = buttons.length > 0 ? { inline_keyboard: [buttons] } : undefined;

    if (messageId) {
        await bot.editMessageText(message.trim(), {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    } else {
        await bot.sendMessage(chatId, message.trim(), {
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    }
}

bot.onText(/\/delkey(?:\s+(.+))?/, async (msg, match) => {
    if (!isAdmin(msg.chat.id)) return;

    const username = match[1]?.trim();
    if (!username) {
        return bot.sendMessage(msg.chat.id, `
🗑️ <b>DELETE LICENSE KEY</b>
━━━━━━━━━━━━━━━━━━

<b>Penggunaan:</b>
<code>/delkey username</code>

<b>Contoh:</b>
<code>/delkey john</code>
        `.trim(), { parse_mode: 'HTML' });
    }

    const result = licenseKeyService.deleteKey(username);

    if (result.success) {
        bot.sendMessage(msg.chat.id, `✅ License key untuk <b>${result.username}</b> berhasil dihapus.`, { parse_mode: 'HTML' });
    } else {
        bot.sendMessage(msg.chat.id, `❌ <b>Gagal:</b> ${result.error}`, { parse_mode: 'HTML' });
    }
});

bot.onText(/\/extendkey(?:\s+(.+))?/, async (msg, match) => {
    if (!isAdmin(msg.chat.id) && !isReseller(msg.chat.id)) return;

    const input = match[1];
    if (!input) {
        return bot.sendMessage(msg.chat.id, `
📅 <b>EXTEND LICENSE KEY</b>
━━━━━━━━━━━━━━━━━━

<b>Penggunaan:</b>
<code>/extendkey username,hari</code>

<b>Contoh:</b>
<code>/extendkey john,30</code>
<code>/extendkey user123,7</code>

💡 <i>Menambah masa aktif key (1-365 hari)</i>
💡 <i>Jika key sudah expired, akan dihitung dari hari ini</i>
        `.trim(), { parse_mode: 'HTML' });
    }

    const parts = input.split(',').map(p => p.trim());
    if (parts.length !== 2) {
        return bot.sendMessage(msg.chat.id, '❌ Format salah! Gunakan: <code>/extendkey username,hari</code>', { parse_mode: 'HTML' });
    }

    const [username, daysStr] = parts;
    const days = parseInt(daysStr, 10);

    if (isNaN(days)) {
        return bot.sendMessage(msg.chat.id, '❌ Jumlah hari harus berupa angka!', { parse_mode: 'HTML' });
    }

    const result = licenseKeyService.extendKey(username, days);

    if (result.success) {
        const newExpireDate = new Date(result.newExpiresAt).toLocaleDateString('id-ID', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });

        const prevExpireDate = new Date(result.previousExpires).toLocaleDateString('id-ID', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });

        bot.sendMessage(msg.chat.id, `
✅ <b>LICENSE KEY EXTENDED</b>
━━━━━━━━━━━━━━━━━━

👤 <b>Username:</b> <code>${result.username}</code>
➕ <b>Ditambah:</b> ${result.addedDays} hari

📅 <b>Sebelum:</b> ${prevExpireDate}${result.wasExpired ? ' (EXPIRED)' : ''}
📅 <b>Sesudah:</b> ${newExpireDate}

${result.wasExpired ? '💡 <i>Key expired telah diaktifkan kembali!</i>' : ''}
        `.trim(), { parse_mode: 'HTML' });
    } else {
        bot.sendMessage(msg.chat.id, `❌ <b>Gagal:</b> ${result.error}`, { parse_mode: 'HTML' });
    }
});

bot.onText(/\/analyze(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;

    const isAuthorized = isAdmin(chatId) || isReseller(chatId) || licenseKeyService.isUserAuthorized(chatId);

    if (!isAuthorized) {
        return bot.sendMessage(chatId, '❌ Fitur ini hanya untuk user berlisensi atau admin.');
    }

    const projectType = match[1]?.toLowerCase();

    if (!projectType || !['flutter', 'android'].includes(projectType)) {
        return bot.sendMessage(chatId, `
🔍 <b>ANALYZE PROJECT</b>
━━━━━━━━━━━━━━━━━━

<b>Penggunaan:</b>
<code>/analyze flutter</code> - Untuk project Flutter
<code>/analyze android</code> - Untuk project Android

<b>Langkah:</b>
1. Kirim command di atas
2. Upload file ZIP project anda
3. Tunggu hasil analisis

💡 <i>Akan menjalankan flutter analyze atau gradle lint</i>
        `.trim(), { parse_mode: 'HTML' });
    }

    global.sessions.set(chatId, {
        step: 'analyze_upload',
        projectType: projectType,
        createdAt: Date.now()
    });

    bot.sendMessage(chatId, `
📤 <b>Upload Project ZIP</b>
━━━━━━━━━━━━━━━━━━

📁 <b>Tipe:</b> ${projectType.toUpperCase()}
🔍 <b>Mode:</b> Analyze

Kirim file <b>.zip</b> project anda sekarang.

⏱ <i>Menunggu file... (timeout: 30 menit)</i>
    `.trim(), { parse_mode: 'HTML' });

    setTimeout(() => {
        const session = global.sessions.get(chatId);
        if (session?.step === 'analyze_upload') {
            global.sessions.delete(chatId);
            bot.sendMessage(chatId, '⏰ Timeout! Silakan kirim /analyze lagi.');
        }
    }, 30 * 60 * 1000);
});

bot.onText(/\/cleanup(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;

    const isAuthorized = isAdmin(chatId) || isReseller(chatId) || licenseKeyService.isUserAuthorized(chatId);

    if (!isAuthorized) {
        return bot.sendMessage(chatId, '❌ Fitur ini hanya untuk user berlisensi atau admin.');
    }

    const projectType = match[1]?.toLowerCase();

    if (!projectType || !['flutter', 'android'].includes(projectType)) {
        return bot.sendMessage(chatId, `
🧹 <b>CLEANUP PROJECT</b>
━━━━━━━━━━━━━━━━━━

<b>Penggunaan:</b>
<code>/cleanup flutter</code> - Untuk project Flutter
<code>/cleanup android</code> - Untuk project Android

<b>Langkah:</b>
1. Kirim command di atas
2. Upload file ZIP project anda
3. Dapatkan project yang sudah bersih

💡 <i>Akan menghapus cache & build files</i>
        `.trim(), { parse_mode: 'HTML' });
    }

    global.sessions.set(chatId, {
        step: 'cleanup_upload',
        projectType: projectType,
        createdAt: Date.now()
    });

    bot.sendMessage(chatId, `
📤 <b>Upload Project ZIP</b>
━━━━━━━━━━━━━━━━━━

📁 <b>Tipe:</b> ${projectType.toUpperCase()}
🧹 <b>Mode:</b> Cleanup

Kirim file <b>.zip</b> project anda sekarang.

⏱ <i>Menunggu file... (timeout: 30 menit)</i>
    `.trim(), { parse_mode: 'HTML' });

    setTimeout(() => {
        const session = global.sessions.get(chatId);
        if (session?.step === 'cleanup_upload') {
            global.sessions.delete(chatId);
            bot.sendMessage(chatId, '⏰ Timeout! Silakan kirim /cleanup lagi.');
        }
    }, 30 * 60 * 1000);
});

// ============================================
// BROADCAST - HANYA SUPER ADMIN
// ============================================
bot.onText(/\/broadcast(?: (.+))?/, async (msg, match) => {
    if (!isSuperAdmin(msg.chat.id)) return;

    const textContent = match[1];
    const isReply = msg.reply_to_message;

    if (!isReply && !textContent) {
        return bot.sendMessage(msg.chat.id, `
╔══════════════════════════╗
     📢  <b>BROADCAST CENTER</b>  📢
╚══════════════════════════╝

<b>📝 Cara Penggunaan:</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━

<b>1️⃣ Text Broadcast:</b>
<code>/broadcast &lt;pesan anda&gt;</code>

<b>2️⃣ Forward Message:</b>
Reply pesan apapun dengan <code>/broadcast</code>

<b>3️⃣ Rich Format (HTML):</b>
<code>/broadcast &lt;b&gt;Bold&lt;/b&gt; &lt;i&gt;Italic&lt;/i&gt;</code>

━━━━━━━━━━━━━━━━━━━━━━━━━━
👥 Total Users: <code>${userService.getCount()}</code>
        `.trim(), { parse_mode: 'HTML' });
    }

    const users = userService.getBroadcastList();
    const totalUsers = users.length;

    if (totalUsers === 0) {
        return bot.sendMessage(msg.chat.id, `
╔══════════════════════════╗
   ⚠️  <b>TIDAK ADA USER</b>  ⚠️
╚══════════════════════════╝

❌ Tidak ada user yang terdaftar untuk broadcast.

📌 <i>Pastikan ada user yang menggunakan bot ini.</i>
        `.trim(), { parse_mode: 'HTML' });
    }

    const estimatedTime = Math.ceil(totalUsers * 0.02);

    const confirmMsg = await bot.sendMessage(msg.chat.id, `
╔══════════════════════════╗
   ⚠️  <b>KONFIRMASI BROADCAST</b>  ⚠️
╚══════════════════════════╝

📊 <b>Statistik:</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
👥 Target: <code>${totalUsers}</code> users
⏱ Estimasi: <code>~${estimatedTime}</code> detik
📨 Tipe: ${isReply ? 'Forward Message' : 'Text Message'}

📝 <b>Preview:</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
${isReply ? '📎 <i>(Forward dari pesan yang di-reply)</i>' : (textContent?.substring(0, 200) + (textContent?.length > 200 ? '...' : '') || '<i>(kosong)</i>')}

━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>Klik tombol untuk melanjutkan...</i>
    `.trim(), {
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '✅ Mulai Broadcast', callback_data: 'bc_confirm' },
                    { text: '❌ Batal', callback_data: 'bc_cancel' }
                ]
            ]
        }
    });

    global.pendingBroadcast = {
        adminId: msg.chat.id,
        confirmMsgId: confirmMsg.message_id,
        isReply,
        textContent,
        replyMsgId: isReply ? msg.reply_to_message.message_id : null,
        users: [...users],
        failedUsers: [],
        timestamp: Date.now()
    };
});

bot.on('photo', (msg) => {
    if (maintenanceService.isEnabled() && !isAdmin(msg.chat.id)) {
        return bot.sendMessage(msg.chat.id, '⚠️ <b>MAINTENANCE MODE:</b> Upload foto tidak aktif.', { parse_mode: 'HTML' });
    }
    handleMessage(bot, msg, 'photo');
});

bot.on('document', async (msg) => {
    const chatId = msg.chat.id;

    if (maintenanceService.isEnabled() && !isAdmin(chatId)) {
        return bot.sendMessage(chatId, `
⚠️ <b>MAINTENANCE MODE</b>
━━━━━━━━━━━━━━━━━━

Upload file dinonaktifkan sementara.
        `.trim(), { parse_mode: 'HTML' });
    }

    const document = msg.document;

    if (document.file_name?.endsWith('.zip')) {
        const session = global.sessions.get(chatId);

        if (session?.step === 'zip_upload' || session?.step === 'analyze_upload' || session?.step === 'cleanup_upload') {
            const fileSize = document.file_size || 0;
            const fileSizeMB = (fileSize / 1024 / 1024).toFixed(2);

            const MAX_SIZE = process.env.LOCAL_API_URL
                ? 2 * 1024 * 1024 * 1024
                : 20 * 1024 * 1024;

            if (fileSize > MAX_SIZE) {
                const limitMB = process.env.LOCAL_API_URL ? '2048' : '20';
                return bot.sendMessage(chatId, `
⚠️ <b>File Terlalu Besar!</b>
━━━━━━━━━━━━━━━━━━

📦 <b>Ukuran:</b> ${fileSizeMB} MB
❌ <b>Batas:</b> ${limitMB} MB

${!process.env.LOCAL_API_URL ? `
💡 <b>Untuk file lebih besar:</b>
Setup Local Bot API Server untuk limit 2GB!
<code>sudo ./scripts/setup-local-api.sh API_ID API_HASH</code>
` : ''}
                `.trim(), { parse_mode: 'HTML' });
            }

            try {
                console.log(`📥 Downloading file (${fileSizeMB} MB)...`);
                console.log(`   File ID: ${document.file_id}`);
                console.log(`   Mode: ${session.step}`);

                const fileName = document.file_name || `file_${Date.now()}.zip`;
                const result = await downloadTelegramFile(
                    bot,
                    document.file_id,
                    path.join(__dirname, '..', 'temp'),
                    fileName
                );

                if (!result.success) {
                    return bot.sendMessage(chatId, `❌ Gagal mengunduh file: ${result.error}`);
                }

                console.log(`✅ File downloaded: ${result.path}`);

                if (session.step === 'zip_upload') {
                    await handleZipUpload(bot, chatId, result.path);
                } else if (session.step === 'analyze_upload') {
                    await handleAnalyzeUpload(bot, chatId, result.path, session.projectType);
                } else if (session.step === 'cleanup_upload') {
                    await handleCleanupUpload(bot, chatId, result.path, session.projectType);
                }

            } catch (error) {
                console.error('Error downloading ZIP:', error);
                bot.sendMessage(chatId, `❌ Gagal mengunduh file: ${error.message}`);
            }
        } else {
            bot.sendMessage(chatId, '⚠️ Untuk menggunakan file ZIP, kirim salah satu command:\n• /analyze flutter\n• /analyze android\n• /cleanup flutter\n• /cleanup android\n• Atau klik tombol BUILD PROJECT (ZIP)');
        }
    }
});

async function handleAnalyzeUpload(bot, chatId, zipPath, projectType) {
    const { analyzeProject, safeExtractZip } = require('./builder/zipBuilder');
    const { v4: uuidv4 } = require('uuid');

    const jobId = uuidv4();
    const tempDir = path.join(__dirname, '..', 'temp', 'analyze-' + jobId);

    try {
        const statusMsg = await bot.sendMessage(chatId, `
🔍 <b>ANALYZING PROJECT</b>
━━━━━━━━━━━━━━━━━━

📁 Tipe: ${projectType.toUpperCase()}
⏳ Status: Mengekstrak file...
        `.trim(), { parse_mode: 'HTML' });

        const extractResult = await safeExtractZip(zipPath, tempDir);

        let statusText = 'Menjalankan analyze...';
        if (extractResult.sanitized) {
            statusText = 'Beberapa nama file disanitasi. Menjalankan analyze...';
        }

        await bot.editMessageText(`
🔍 <b>ANALYZING PROJECT</b>
━━━━━━━━━━━━━━━━━━

📁 Tipe: ${projectType.toUpperCase()}
⏳ Status: ${statusText}
        `.trim(), { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });

        const targetFile = projectType === 'flutter' ? 'pubspec.yaml' : 'build.gradle';
        let projectRoot = tempDir;

        if (!await fs.pathExists(path.join(tempDir, targetFile))) {
            const items = await fs.readdir(tempDir);
            for (const item of items) {
                const itemPath = path.join(tempDir, item);
                if ((await fs.stat(itemPath)).isDirectory()) {
                    if (await fs.pathExists(path.join(itemPath, targetFile))) {
                        projectRoot = itemPath;
                        break;
                    }
                }
            }
        }

        const result = await analyzeProject(projectRoot, projectType);

        const logDir = path.join(__dirname, '..', 'logs', 'tools');
        await fs.ensureDir(logDir);
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const logFileName = `analyze_${projectType}_${timestamp}.txt`;
        const logFilePath = path.join(logDir, logFileName);

        const logContent = `=== PROJECT ANALYZE LOG ===
Date: ${new Date().toLocaleString('id-ID')}
Project Type: ${projectType}
Status: ${result.success ? 'SUCCESS' : 'FAILED'}

=== OUTPUT ===
${result.output || result.error || 'No output'}
`;
        await fs.writeFile(logFilePath, logContent);

        if (result.success) {
            await bot.editMessageText(`
✅ <b>ANALYZE COMPLETE</b>
━━━━━━━━━━━━━━━━━━

📁 Tipe: ${projectType.toUpperCase()}
📊 Status: Berhasil

📋 <b>Hasil telah dikirim sebagai file.</b>
            `.trim(), { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });
        } else {
            await bot.editMessageText(`
❌ <b>ANALYZE FAILED</b>
━━━━━━━━━━━━━━━━━━

📁 Tipe: ${projectType.toUpperCase()}
⚠️ Error: ${result.error || 'Unknown error'}

📋 <b>Log telah dikirim sebagai file.</b>
            `.trim(), { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });
        }

        await bot.sendDocument(chatId, logFilePath, {
            caption: `📊 Analyze Log - ${projectType.toUpperCase()}`
        });

    } catch (error) {
        bot.sendMessage(chatId, `❌ Analyze gagal: ${error.message}`);
    } finally {
        global.sessions.delete(chatId);
        await fs.remove(zipPath).catch(() => { });
        await fs.remove(tempDir).catch(() => { });
    }
}

async function handleCleanupUpload(bot, chatId, zipPath, projectType) {
    const { cleanupProject, safeExtractZip } = require('./builder/zipBuilder');
    const archiver = require('archiver');
    const { v4: uuidv4 } = require('uuid');

    const jobId = uuidv4();
    const tempDir = path.join(__dirname, '..', 'temp', 'cleanup-' + jobId);
    const outputZipPath = path.join(__dirname, '..', 'temp', `cleaned-${jobId}.zip`);

    try {
        const statusMsg = await bot.sendMessage(chatId, `
🧹 <b>CLEANING PROJECT</b>
━━━━━━━━━━━━━━━━━━

📁 Tipe: ${projectType.toUpperCase()}
⏳ Status: Mengekstrak file...
        `.trim(), { parse_mode: 'HTML' });

        const extractResult = await safeExtractZip(zipPath, tempDir);

        let statusText = 'Menjalankan cleanup...';
        if (extractResult.sanitized) {
            statusText = 'Beberapa nama file disanitasi. Menjalankan cleanup...';
        }

        await bot.editMessageText(`
🧹 <b>CLEANING PROJECT</b>
━━━━━━━━━━━━━━━━━━

📁 Tipe: ${projectType.toUpperCase()}
⏳ Status: ${statusText}
        `.trim(), { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });

        const targetFile = projectType === 'flutter' ? 'pubspec.yaml' : 'build.gradle';
        let projectRoot = tempDir;

        if (!await fs.pathExists(path.join(tempDir, targetFile))) {
            const items = await fs.readdir(tempDir);
            for (const item of items) {
                const itemPath = path.join(tempDir, item);
                if ((await fs.stat(itemPath)).isDirectory()) {
                    if (await fs.pathExists(path.join(itemPath, targetFile))) {
                        projectRoot = itemPath;
                        break;
                    }
                }
            }
        }

        const result = await cleanupProject(projectRoot, projectType);

        if (result.success) {
            await bot.editMessageText(`
🧹 <b>CLEANING PROJECT</b>
━━━━━━━━━━━━━━━━━━

📁 Tipe: ${projectType.toUpperCase()}
⏳ Status: Mengompres hasil...
            `.trim(), { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });

            const output = fs.createWriteStream(outputZipPath);
            const archive = archiver('zip', { zlib: { level: 9 } });

            await new Promise((resolve, reject) => {
                output.on('close', resolve);
                archive.on('error', reject);
                archive.pipe(output);
                archive.directory(projectRoot, false);
                archive.finalize();
            });

            const sizeSavedMB = ((result.savedBytes || 0) / (1024 * 1024)).toFixed(2);
            const sizeBeforeMB = ((result.sizeBefore || 0) / (1024 * 1024)).toFixed(2);
            const sizeAfterMB = ((result.sizeAfter || 0) / (1024 * 1024)).toFixed(2);

            await bot.editMessageText(`
✅ <b>CLEANUP COMPLETE</b>
━━━━━━━━━━━━━━━━━━

📁 Tipe: ${projectType.toUpperCase()}
📊 Before: ${sizeBeforeMB} MB
📊 After: ${sizeAfterMB} MB
💾 Saved: ${sizeSavedMB} MB

📥 <b>Mengirim file...</b>
            `.trim(), { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });

            await bot.sendDocument(chatId, outputZipPath, {
                caption: `📦 Cleaned Project\n\n📊 Before: ${sizeBeforeMB} MB\n📊 After: ${sizeAfterMB} MB\n💾 Saved: ${sizeSavedMB} MB`
            });

        } else {
            await bot.editMessageText(`
❌ <b>CLEANUP FAILED</b>
━━━━━━━━━━━━━━━━━━

📁 Tipe: ${projectType.toUpperCase()}
⚠️ Error: ${result.error || 'Unknown error'}
            `.trim(), { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' });
        }

    } catch (error) {
        bot.sendMessage(chatId, `❌ Cleanup gagal: ${error.message}`);
    } finally {
        global.sessions.delete(chatId);
        await fs.remove(zipPath).catch(() => { });
        await fs.remove(tempDir).catch(() => { });
        await fs.remove(outputZipPath).catch(() => { });
    }
}

bot.on('polling_error', (error) => {
    console.error('Polling error:', error.message);
});

bot.on('error', (error) => {
    console.error('Bot error:', error.message);
});

setInterval(() => {
    cleanupOldFiles(path.join(__dirname, '..', 'temp'), 15);
    cleanupOldFiles(path.join(__dirname, '..', 'output'), 15);
}, 15 * 60 * 1000);

(async () => {
    console.log('🗑️ Cleaning up leftover temp files...');
    await cleanupOldFiles(path.join(__dirname, '..', 'temp'), 1);
    await cleanupOldFiles(path.join(__dirname, '..', 'output'), 1);
    console.log('✅ Startup cleanup complete');
})();

console.log('🤖 Web2APK Bot berhasil dijalankan!');
console.log(`   Total users: ${userService.getCount()} `);
console.log('   Tekan Ctrl+C untuk menghentikan bot');

bot.onText(/\/notif(?: (.+))?/, async (msg, match) => {
    if (!isAdmin(msg.chat.id)) return;

    const text = match[1];
    if (!text) {
        return bot.sendMessage(msg.chat.id, '❌ Gunakan format: <code>/notif pesan anda</code>', { parse_mode: 'HTML' });
    }

    updateNotification(text);

    bot.sendMessage(msg.chat.id, `
✅ <b>Notifikasi Dikirim!</b>
━━━━━━━━━━━━━━━━━━
📝 <b>Pesan:</b>
${text}

        <i>Akan muncul di aplikasi dalam ~1 menit.</i>
        `.trim(), { parse_mode: 'HTML' });
});

bot.onText(/\/clearcache/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (!isSuperAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk Super Admin.');
    }
    
    await bot.sendMessage(chatId, '🗑️ <b>Membersihkan cache...</b>\n\nMohon tunggu, ini mungkin memakan waktu 10-30 detik.', { parse_mode: 'HTML' });
    
    const result = await clearAllCaches();
    
    await sendCacheCleanupReport(bot, result, 'manual');
    
    const freedMB = (result.freedBytes / 1024 / 1024).toFixed(2);
    await bot.sendMessage(chatId, `
✅ <b>Cache Cleanup Selesai!</b>
━━━━━━━━━━━━━━━━━━
💾 <b>Total dibersihkan:</b> <code>${freedMB} MB</code>

📋 <i>Laporan lengkap sudah dikirim ke DM Owner.</i>
    `.trim(), { parse_mode: 'HTML' });
});

let autoCleanupInterval = null;

function startAutoCacheCleanup(bot) {
    if (autoCleanupInterval) {
        clearInterval(autoCleanupInterval);
    }
    
    autoCleanupInterval = setInterval(async () => {
        console.log(`[${new Date().toLocaleString()}] 🔄 Running auto cache cleanup...`);
        
        try {
            const result = await clearAllCaches();
            const freedMB = (result.freedBytes / 1024 / 1024).toFixed(2);
            
            if (result.freedBytes > 1 * 1024 * 1024 || !result.success) {
                await sendCacheCleanupReport(bot, result, 'auto');
            } else {
                console.log(`✅ Auto cleanup: ${freedMB} MB freed (no report sent)`);
            }
            
            const logDir = path.join(__dirname, '..', 'logs');
            await fs.ensureDir(logDir);
            const logPath = path.join(logDir, 'cache_cleanup.log');
            const logEntry = `[${new Date().toISOString()}] Freed: ${freedMB} MB | Details: ${JSON.stringify(result.details)}\n`;
            await fs.appendFile(logPath, logEntry).catch(() => {});
            
        } catch (error) {
            console.error('Auto cache cleanup error:', error);
            
            const ownerId = SUPER_ADMIN_ID;
            await bot.sendMessage(ownerId, `
⚠️ <b>Auto Cache Cleanup Error</b>
━━━━━━━━━━━━━━━━━━
🕐 <b>Waktu:</b> ${new Date().toLocaleString('id-ID')}
❌ <b>Error:</b> <code>${error.message}</code>

<i>Check logs for details.</i>
            `.trim(), { parse_mode: 'HTML' }).catch(() => {});
        }
    }, 30 * 60 * 1000);
    
    console.log('🗑️ Auto cache cleaner started: every 10 minutes');
}

startAutoCacheCleanup(bot);

bot.onText(/\/cachestatus/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    if (!isSuperAdmin(userId)) {
        return bot.sendMessage(chatId, '❌ Command ini hanya untuk Super Admin.');
    }
    
    await bot.sendMessage(chatId, '📊 <b>Mengukur ukuran cache...</b>', { parse_mode: 'HTML' });
    
    const cachePaths = [
        { path: '/root/.gradle/caches/', name: 'Gradle Caches' },
        { path: '/root/.gradle/wrapper/dists/', name: 'Gradle Wrapper' },
        { path: '/root/.npm/_cacache/', name: 'NPM Cache' },
        { path: '/root/.pub-cache/', name: 'Pub Cache' },
        { path: '/root/.android/cache/', name: 'Android Cache' }
    ];
    
    let totalSize = 0;
    let details = '';
    
    for (const cache of cachePaths) {
        try {
            const size = await getDirectorySize(cache.path);
            const sizeMB = (size / 1024 / 1024).toFixed(2);
            totalSize += size;
            details += `📁 ${cache.name}: <code>${sizeMB} MB</code>\n`;
        } catch {
            details += `📁 ${cache.name}: <i>Tidak bisa diakses</i>\n`;
        }
    }
    
    const diskUsage = await getDiskUsage();
    const totalMB = (totalSize / 1024 / 1024).toFixed(2);
    
    const message = `
📦 <b>CACHE STATUS</b>
━━━━━━━━━━━━━━━━━━
🕐 <b>Waktu:</b> ${new Date().toLocaleString('id-ID')}

<b>Per Cache:</b>
${details}
━━━━━━━━━━━━━━━━━━
<b>Total Cache:</b> <code>${totalMB} MB</code>

<b>Disk Usage (/root):</b>
<code>${diskUsage}</code>
━━━━━━━━━━━━━━━━━━
💡 Gunakan <code>/clearcache</code> untuk membersihkan
    `;
    
    await bot.sendMessage(chatId, message.trim(), { parse_mode: 'HTML' });
});

bot.onText(/\/maintenance(?:\s+(.+))?/, async (msg, match) => {
    if (!isAdmin(msg.chat.id)) return;

    const action = match[1]?.toLowerCase();
    if (!action || !['on', 'off'].includes(action)) {
        const status = maintenanceService.isEnabled() ? '✅ ON' : '❌ OFF';
        return bot.sendMessage(msg.chat.id, `
🛠 <b>MAINTENANCE MODE</b>
━━━━━━━━━━━━━━━━━━

Status: ${status}

<b>Penggunaan:</b>
<code>/maintenance on</code> - Aktifkan mode perbaikan
<code>/maintenance off</code> - Matikan mode perbaikan

⚠️ <i>Saat ON, user dan pemilik key addkey TIDAK BISA menggunakan bot. Hanya ADMIN yang terdaftar di env yang bisa.</i>
        `.trim(), { parse_mode: 'HTML' });
    }

    const enable = action === 'on';
    maintenanceService.set(enable);

    bot.sendMessage(msg.chat.id, `
${enable ? '🔴' : '🟢'} <b>MAINTENANCE MODE ${enable ? 'ACTIVATED' : 'DEACTIVATED'}</b>
━━━━━━━━━━━━━━━━━━

Bot sekarang ${enable ? 'HANYA bisa diakses oleh Owner.' : 'bisa diakses oleh semua user.'}
    `.trim(), { parse_mode: 'HTML' });
});

bot.onText(/\/cat (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const filePath = match[1].trim();

    if (!filePath.startsWith('/root/webapp/logs/')) {
        return bot.sendMessage(chatId, '❌ Hanya bisa mengakses file di folder /root/webapp/logs/');
    }

    if (!fs.existsSync(filePath)) {
        return bot.sendMessage(chatId, `❌ File tidak ditemukan: ${filePath}`);
    }

    try {
        const content = fs.readFileSync(filePath, 'utf8');

        if (!content.trim()) {
            return bot.sendMessage(chatId, '⚠️ File error kosong.');
        }

        const tempFileName = `log_error_${Date.now()}.txt`;
        const tempFilePath = path.join('/tmp', tempFileName);
        
        fs.writeFileSync(tempFilePath, content, 'utf8');

        await bot.sendDocument(chatId, tempFilePath, {
            caption: `📁 ${path.basename(filePath)}`
        });

        fs.unlinkSync(tempFilePath);

    } catch (err) {
        bot.sendMessage(chatId, `❌ Gagal membaca file: ${err.message}`);
    }
});

bot.onText(/\/cat$/, (msg) => {
    bot.sendMessage(msg.chat.id, '❌ Gunakan: /cat <path_to_file>\n\nContoh:\n/cat /root/webapp/logs/build_1777710300598.log.error');
});

console.log('✅ Bot berjalan...');
console.log('📁 Hanya bisa mengakses: /root/webapp/logs/');

bot.on('message', async (msg) => {
    if (maintenanceService.isEnabled() && !isAdmin(msg.chat.id)) {
        if (msg.chat.type === 'private' && (!msg.text || !msg.text.startsWith('/'))) {
            bot.sendMessage(msg.chat.id, `
⚠️ <b>MAINTENANCE MODE</b>
━━━━━━━━━━━━━━━━━━

Bot sedang dalam perbaikan.
Silakan coba lagi nanti.
        `.trim(), { parse_mode: 'HTML' });
        }
        return;
    }

    if (msg.text && msg.text.startsWith('/')) return;
    handleMessage(bot, msg);
});

// --- ADMIN: BUILD STATUS COMMAND ---
bot.onText(/\/buildstatus/, async (msg) => {
    if (!isAdmin(msg.chat.id)) return;

    const { buildManager } = require('./utils/buildQueue');
    const stats = buildManager.getStats();
    const activeBuilds = buildManager.getActiveBuilds();
    const queueInfo = buildManager.getQueueInfo();
    const queueList = buildManager.getQueueList();

    let message = `
📊 <b>BUILD STATUS</b>
━━━━━━━━━━━━━━━━━━

👑 <b>Owner:</b> ${stats.ownerActive} build aktif
👤 <b>User:</b> ${stats.userActive}/${queueInfo.maxConcurrent} slot
⏳ <b>Antrian:</b> ${queueInfo.waiting} menunggu
━━━━━━━━━━━━━━━━━━
📈 <b>Total:</b> ${stats.total} | ✅ ${stats.success} | ❌ ${stats.failed}
⏱️ <b>Avg:</b> ~${stats.avgTime}s
━━━━━━━━━━━━━━━━━━
`;

    if (activeBuilds.length > 0) {
        message += `\n<b>🔨 Sedang Berjalan:</b>\n`;
        for (const build of activeBuilds) {
            const mins = Math.floor(build.duration / 60);
            const secs = build.duration % 60;
            let emoji = build.isOwner ? '👑 ' : (build.priorityLevel === 1 ? '⭐ ' : '');
            const typeIcon = build.type === 'url' ? '🌐' : '📦';
            message += `• ${emoji}${typeIcon} ${escapeHtml(build.userName)} - ${escapeHtml(build.projectName)} (${mins}m ${secs}s)\n`;
            message += `  🆔 <code>${build.buildId}</code>\n`;
        }
    } else {
        message += `\n🟢 <i>Tidak ada build aktif</i>`;
    }

    if (queueList.length > 0) {
        message += `\n<b>⏳ Antrian:</b>\n`;
        for (const item of queueList.slice(0, 5)) {
            let emoji = '';
            if (item.priorityLevel === 2) emoji = '👑 ';
            else if (item.priorityLevel === 1) emoji = '⭐ ';
            message += `${item.position}. ${emoji}${escapeHtml(item.userName)} - ${escapeHtml(item.projectName)} (${item.waitingTime}m)\n`;
        }
        if (queueList.length > 5) {
            message += `<i>...${queueList.length - 5} lainnya</i>`;
        }
    }

    bot.sendMessage(msg.chat.id, message.trim(), { parse_mode: 'HTML' });
});

// --- ADMIN: KILL BUILD ---
bot.onText(/\/killbuild (.+)/, async (msg, match) => {
    if (!isAdmin(msg.chat.id)) return;

    const { buildManager } = require('./utils/buildQueue');
    const buildId = match[1].trim();
    const build = buildManager.getBuildInfo(buildId);

    if (!build) {
        return bot.sendMessage(msg.chat.id, `❌ Build ID <code>${buildId}</code> tidak ditemukan.`, { parse_mode: 'HTML' });
    }

    await buildManager.forceRelease(buildId);
    
    bot.sendMessage(msg.chat.id, `
✅ <b>Build Dibatalkan!</b>
━━━━━━━━━━━━━━━━━━

🆔 <code>${buildId}</code>
👤 ${escapeHtml(build.userName)}
📱 ${escapeHtml(build.projectName)}
${build.isOwner ? '👑 Owner Build' : ''}

💡 <i>Build telah dihentikan paksa.</i>
    `.trim(), { parse_mode: 'HTML' });
});

// --- SUPER ADMIN: SET MAX CONCURRENT ---
bot.onText(/\/setbuildslot (\d+)/, async (msg, match) => {
    if (!isSuperAdmin(msg.chat.id)) return;

    const { buildManager } = require('./utils/buildQueue');
    const count = parseInt(match[1]);
    
    if (count < 1 || count > 10) {
        return bot.sendMessage(msg.chat.id, '❌ Slot harus antara 1-10.');
    }

    buildManager.setMaxConcurrent(count);

    bot.sendMessage(msg.chat.id, `
✅ <b>Build Slot Diperbarui!</b>
━━━━━━━━━━━━━━━━━━

📊 <b>Max Concurrent:</b> <code>${count}</code> build untuk user

👑 <b>Owner:</b> Unlimited (tidak terbatas)
👤 <b>User:</b> ${count} build sekaligus

💡 <i>Owner tetap bisa build tanpa batas!</i>
    `.trim(), { parse_mode: 'HTML' });
});

// --- SUPER ADMIN: ADD OWNER COMMAND ---
bot.onText(/\/addowner(?:\s+(.+))?/, async (msg, match) => {
    if (!isSuperAdmin(msg.chat.id)) {
        return bot.sendMessage(msg.chat.id, '❌ Anda tidak memiliki izin!');
    }

    const input = match[1]?.trim();
    if (!input) {
        return bot.sendMessage(msg.chat.id, `
👑 <b>ADD OWNER</b>
━━━━━━━━━━━━━━━━━━

<b>Penggunaan:</b>
<code>/addowner telegram_id</code>

<b>Contoh:</b>
<code>/addowner 123456789</code>

💡 <i>Owner memiliki akses unlimited build!</i>
        `.trim(), { parse_mode: 'HTML' });
    }

    const userId = input.trim();
    if (isNaN(parseInt(userId, 10))) {
        return bot.sendMessage(msg.chat.id, '❌ User ID harus berupa angka!', { parse_mode: 'HTML' });
    }

    // CEK APAKAH USER SUDAH MENJADI RESELLER ATAU MEMBER
    const isReseller = resellerService.isReseller(userId);
    const hasLicense = licenseKeyService.isUserAuthorized(userId);

    let warningMessage = '';
    if (isReseller) {
        warningMessage += '⚠️ User ini adalah RESELLER. Akan dihapus dari daftar reseller.\n';
    }
    if (hasLicense) {
        warningMessage += '⚠️ User ini memiliki LICENSE KEY. Akan dihapus dari daftar member.\n';
    }

    if (warningMessage) {
        await bot.sendMessage(msg.chat.id, warningMessage, { parse_mode: 'HTML' });
    }

    // HAPUS DARI RESELLER JIKA ADA
    if (isReseller) {
        resellerService.removeReseller(userId);
    }

    // HAPUS DARI MEMBER JIKA ADA
    if (hasLicense) {
        const username = licenseKeyService.getUsernameByTelegramId(userId);
        if (username) {
            licenseKeyService.deleteKey(username);
        }
    }

    // TAMBAHKAN KE OWNER
    const result = ownerManager.addOwner(userId);

    if (result.success) {
        bot.sendMessage(msg.chat.id, `
✅ <b>OWNER ADDED</b>
━━━━━━━━━━━━━━━━━━
👑 User ID: <code>${userId}</code>

${isReseller ? '✅ Dihapus dari daftar RESELLER\n' : ''}${hasLicense ? '✅ Dihapus dari daftar MEMBER\n' : ''}
<i>User tersebut sekarang memiliki akses UNLIMITED build!</i>
        `.trim(), { parse_mode: 'HTML' });

        bot.sendMessage(userId, `
🎉 <b>Selamat! Anda telah diangkat menjadi OWNER!</b>

<b>Akses Anda:</b>
✅ Build UNLIMITED (tanpa batas)
✅ Build banyak sekaligus
✅ Tanpa antrian
✅ Prioritas tertinggi
✅ Akses semua fitur

💡 <i>Anda sekarang bisa build tanpa batas!</i>
        `.trim(), { parse_mode: 'HTML' }).catch(() => {});
    } else {
        bot.sendMessage(msg.chat.id, `❌ <b>Gagal:</b> ${result.error}`, { parse_mode: 'HTML' });
    }
});

// --- SUPER ADMIN: REMOVE OWNER COMMAND ---
bot.onText(/\/removeowner(?:\s+(.+))?/, async (msg, match) => {
    if (!isSuperAdmin(msg.chat.id)) {
        return bot.sendMessage(msg.chat.id, '❌ Anda tidak memiliki izin!');
    }

    const input = match[1]?.trim();
    if (!input) {
        return bot.sendMessage(msg.chat.id, `
👑 <b>REMOVE OWNER</b>
━━━━━━━━━━━━━━━━━━

<b>Penggunaan:</b>
<code>/removeowner telegram_id</code>

<b>Contoh:</b>
<code>/removeowner 123456789</code>

⚠️ <i>Tidak bisa menghapus Owner utama (SUPER_ADMIN).</i>
        `.trim(), { parse_mode: 'HTML' });
    }

    const userId = input.trim();
    const result = ownerManager.removeOwner(userId);

    if (result.success) {
        bot.sendMessage(msg.chat.id, `✅ Owner ID <code>${userId}</code> telah dihapus.`, { parse_mode: 'HTML' });
    } else {
        bot.sendMessage(msg.chat.id, `❌ <b>Gagal:</b> ${result.error}`, { parse_mode: 'HTML' });
    }
});

// --- SUPER ADMIN: LIST OWNERS COMMAND ---
bot.onText(/\/listowners/, async (msg) => {
    if (!isSuperAdmin(msg.chat.id)) {
        return bot.sendMessage(msg.chat.id, '❌ Anda tidak memiliki izin!');
    }

    const owners = ownerManager.listOwners();

    if (owners.length === 0) {
        return bot.sendMessage(msg.chat.id, '📋 Belum ada Owner terdaftar.', { parse_mode: 'HTML' });
    }

    let message = `
👑 <b>DAFTAR OWNER</b> (${owners.length})
━━━━━━━━━━━━━━━━━━
`;

    owners.forEach((id, i) => {
        const isMain = id === SUPER_ADMIN_ID ? '⭐ (Super Admin)' : '';
        message += `
${i + 1}. <code>${id}</code> ${isMain}
`;
    });

    bot.sendMessage(msg.chat.id, message.trim(), { parse_mode: 'HTML' });
});

// --- SUPER ADMIN: CEK OWNER COMMAND ---
bot.onText(/\/cekowner(?:\s+(.+))?/, async (msg, match) => {
    if (!isSuperAdmin(msg.chat.id)) {
        return bot.sendMessage(msg.chat.id, '❌ Anda tidak memiliki izin!');
    }

    const input = match[1]?.trim();
    
    if (!input) {
        return bot.sendMessage(msg.chat.id, `
🔍 <b>CEK STATUS OWNER</b>
━━━━━━━━━━━━━━━━━━

<b>Penggunaan:</b>
<code>/cekowner telegram_id</code>

<b>Contoh:</b>
<code>/cekowner 123456789</code>

💡 <i>Mengecek apakah user terdaftar sebagai Owner</i>
        `.trim(), { parse_mode: 'HTML' });
    }

    const userId = input.trim();
    const isOwner = ownerManager.isOwner(userId);
    const isReseller = resellerService.isReseller(userId);
    const hasLicense = licenseKeyService.isUserAuthorized(userId);
    const username = licenseKeyService.getUsernameByTelegramId(userId);

    let status = [];
    if (isOwner) status.push('👑 Owner');
    if (isReseller) status.push('👥 Reseller');
    if (hasLicense) status.push('🔑 Member (License)');

    let message = `
🔍 <b>STATUS USER</b>
━━━━━━━━━━━━━━━━━━
👤 User ID: <code>${userId}</code>
`;

    if (username) {
        message += `📝 Username: <code>${username}</code>\n`;
    }

    message += `\n📊 <b>Status:</b>\n`;

    if (status.length === 0) {
        message += `❌ User biasa (tidak terdaftar)\n`;
    } else {
        status.forEach(s => {
            message += `✅ ${s}\n`;
        });
    }

    message += `\n━━━━━━━━━━━━━━━━━━`;

    if (isOwner) {
        message += `\n💡 <b>Owner:</b> Build unlimited & prioritas tertinggi`;
    } else if (isReseller) {
        message += `\n💡 <b>Reseller:</b> Bisa membuat license key`;
    } else if (hasLicense) {
        message += `\n💡 <b>Member:</b> Bisa build project (terbatas)`;
    } else {
        message += `\n💡 <b>User biasa:</b> Bisa menggunakan fitur dasar bot`;
    }

    bot.sendMessage(msg.chat.id, message.trim(), { parse_mode: 'HTML' });
});

// --- COMMAND: RENAME ---
bot.onText(/\/rename(?:\s+(.+))?/, async (msg, match) => {
    await handleRenameCommand(bot, msg, match);
});

// --- SUPER ADMIN: PIN PESAN (PIN + FORWARD) ---
bot.onText(/\/pinpesan/, async (msg) => {
    if (!isSuperAdmin(msg.chat.id)) return;

    const isReply = msg.reply_to_message;

    if (!isReply) {
        return bot.sendMessage(msg.chat.id, `
╔══════════════════════════╗
     📌  <b>PIN PESAN</b>  📌
╚══════════════════════════╝

<b>📝 Cara Penggunaan:</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━

<b>1️⃣ Reply pesan yang ingin di-pin</b>
<b>2️⃣ Kirim command:</b> <code>/pinpesan</code>

<b>📌 Fitur:</b>
• Pesan akan di-FORWARD ke semua user
• Pesan akan di-PIN di chat user
• Format pesan tetap (termasuk foto/sticker)

━━━━━━━━━━━━━━━━━━━━━━━━━━
👥 Total Users: <code>${userService.getCount()}</code>
⚠️ <i>Pesan akan di-pin di semua user!</i>
        `.trim(), { parse_mode: 'HTML' });
    }

    const users = userService.getBroadcastList();
    const totalUsers = users.length;

    if (totalUsers === 0) {
        return bot.sendMessage(msg.chat.id, `
⚠️ <b>Tidak ada user yang terdaftar.</b>
        `.trim(), { parse_mode: 'HTML' });
    }

    const estimatedTime = Math.ceil(totalUsers * 0.03);

    const confirmMsg = await bot.sendMessage(msg.chat.id, `
╔══════════════════════════╗
   ⚠️  <b>KONFIRMASI PIN PESAN</b>  ⚠️
╚══════════════════════════╝

📊 <b>Statistik:</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
👥 Target: <code>${totalUsers}</code> users
⏱ Estimasi: <code>~${estimatedTime}</code> detik
📨 Tipe: Forward + Pin Message

📝 <b>Preview Pesan:</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 <i>Pesan yang akan di-pin:</i>
${msg.reply_to_message.text ? msg.reply_to_message.text.substring(0, 200) + (msg.reply_to_message.text.length > 200 ? '...' : '') : '📎 <i>(Media/File)</i>'}

━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>Klik tombol untuk melanjutkan...</i>
    `.trim(), {
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [
                    { text: '✅ Mulai Pin', callback_data: 'pinpesan_confirm' },
                    { text: '❌ Batal', callback_data: 'pinpesan_cancel' }
                ]
            ]
        }
    });

    global.pendingPinpesan = {
        adminId: msg.chat.id,
        confirmMsgId: confirmMsg.message_id,
        replyMsgId: msg.reply_to_message.message_id,
        replyChatId: msg.reply_to_message.chat.id,
        users: [...users],
        timestamp: Date.now()
    };
});

startWebServer();

// Test notification on startup (opsional)
setTimeout(async () => {
    try {
        await sendBuildNotification(bot, 'start', {
            appName: 'System Ready',
            userName: 'Bot System',
            userId: 'System'
        });
        console.log('✅ Channel notification test sent');
    } catch (error) {
        console.log('ℹ️ Channel notification not configured yet');
    }
}, 5000);

(async () => {
    try {
        const configPath = path.join(__dirname, '../backups/config.json');
        const config = await fs.readJson(configPath).catch(() => null);
        
        if (config && config.interval) {
            console.log(`🔄 Auto backup enabled: every ${config.interval} hours`);
            global.backupInterval = setInterval(async () => {
                console.log('🔄 Running scheduled auto backup...');
                await backupManager.sendBackupToOwner();
            }, config.interval * 60 * 60 * 1000);
            
            setTimeout(async () => {
                console.log('🔄 Running initial auto backup...');
                await backupManager.sendBackupToOwner();
            }, 120000);
        } else {
            console.log('ℹ️ Auto backup not configured. Use /setbackup to enable');
        }
    } catch (error) {
        console.log('ℹ️ No backup config found. Auto backup disabled');
    }
})();

process.removeAllListeners('SIGINT');
process.on('SIGINT', () => {
    console.log('\n👋 Bot dihentikan');
    if (global.backupInterval) clearInterval(global.backupInterval);
    if (autoCleanupInterval) clearInterval(autoCleanupInterval);
    bot.stopPolling();
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n👋 Bot dihentikan');
    if (global.backupInterval) clearInterval(global.backupInterval);
    if (autoCleanupInterval) clearInterval(autoCleanupInterval);
    bot.stopPolling();
    process.exit(0);
});