#!/bin/bash

# ============================================
# Web2APK Gen 3 - Simple VPS Setup Script
# ============================================

set -e

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

step() {
    echo ""
    echo -e "${CYAN}============================================================${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}============================================================${NC}"
}

ok()   { echo -e "${GREEN}[OK] $1${NC}"; }
fail() { echo -e "${RED}[FAIL] $1${NC}"; }
info() { echo -e "${YELLOW}[INFO] $1${NC}"; }

detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS_NAME=$ID
        OS_VERSION=$VERSION_ID
        OS_CODENAME=$VERSION_CODENAME
    else
        OS_NAME="unknown"
        OS_CODENAME="unknown"
    fi
}

# ============================================
# STEP 1: System Update & Node.js 22
# ============================================
install_nodejs() {
    step "STEP 1/8: System Update & Node.js 22"

    info "Updating system packages..."
    sudo apt update
    sudo apt upgrade -y
    ok "System updated"

    info "Installing Node.js 22..."
    if ! command -v node &> /dev/null || [[ $(node -v | cut -d. -f1 | tr -d 'v') -lt 22 ]]; then
        curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
        sudo apt install -y nodejs
    fi
    ok "Node.js $(node -v) | npm v$(npm -v)"
}

# ============================================
# STEP 2: Java 17 & Gradle 8.7
# ============================================
install_java_gradle() {
    step "STEP 2/8: Java 17 & Gradle 8.7"

    info "Installing Java 17..."
    if [ "$OS_NAME" = "debian" ]; then
        sudo apt install -y wget apt-transport-https gnupg
        if [ ! -f /usr/share/keyrings/adoptium.gpg ]; then
            wget -qO - https://packages.adoptium.net/artifactory/api/gpg/key/public | sudo gpg --dearmor -o /usr/share/keyrings/adoptium.gpg
        fi
        if [ ! -f /etc/apt/sources.list.d/adoptium.list ]; then
            echo "deb [signed-by=/usr/share/keyrings/adoptium.gpg] https://packages.adoptium.net/artifactory/deb $OS_CODENAME main" | sudo tee /etc/apt/sources.list.d/adoptium.list
        fi
        sudo apt update
        sudo apt install -y temurin-17-jdk
        export JAVA_HOME=/usr/lib/jvm/temurin-17-jdk-amd64
    else
        sudo apt install -y openjdk-17-jdk
        export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
    fi

    if ! java -version &>/dev/null; then
        fail "Java installation failed"
        exit 1
    fi
    ok "$(java -version 2>&1 | head -n1)"

    info "Installing Gradle 8.7..."
    GRADLE_VERSION="8.7"
    if ! gradle -v 2>/dev/null | grep -q "$GRADLE_VERSION"; then
        cd /tmp
        wget -q "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -O gradle.zip
        sudo rm -rf /opt/gradle-${GRADLE_VERSION}
        sudo unzip -q -d /opt gradle.zip
        sudo ln -sf /opt/gradle-${GRADLE_VERSION}/bin/gradle /usr/bin/gradle
        rm gradle.zip
        cd - > /dev/null
    fi
    ok "Gradle $(gradle -v | grep Gradle | awk '{print $2}')"
}

# ============================================
# STEP 3: Android SDK
# ============================================
install_android_sdk() {
    step "STEP 3/8: Android SDK"

    info "Installing Android SDK dependencies..."
    sudo apt install -y wget unzip zip lib32z1 lib32stdc++6

    ANDROID_HOME=/opt/android-sdk
    sudo mkdir -p $ANDROID_HOME/cmdline-tools
    cd $ANDROID_HOME/cmdline-tools

    if [ ! -d "latest" ]; then
        info "Downloading Android SDK command line tools..."
        sudo wget -q "https://dl.google.com/android/repository/commandlinetools-linux-10406996_latest.zip" -O tools.zip
        sudo unzip -q tools.zip
        if [ -d "cmdline-tools" ]; then
            sudo mv cmdline-tools latest
        fi
        sudo rm -f tools.zip
    fi

    sudo chmod -R 777 $ANDROID_HOME
    export ANDROID_HOME=/opt/android-sdk
    export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

    info "Accepting licenses..."
    yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses || true

    info "Installing SDK components (lihat proses di bawah)..."
    $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager \
        "platforms;android-36" \
        "platforms;android-35" \
        "platforms;android-34" \
        "build-tools;36.0.0" \
        "build-tools;35.0.0" \
        "build-tools;34.0.0" \
        "build-tools;28.0.3" \
        "platform-tools" \
        "ndk;27.0.12077973" \
        "cmake;3.22.1"

    export ANDROID_NDK_HOME=$ANDROID_HOME/ndk/27.0.12077973
    ok "Android SDK + NDK 27.0.12077973 installed"
}

# ============================================
# STEP 4: Flutter SDK
# ============================================
install_flutter() {
    step "STEP 4/8: Flutter SDK"

    FLUTTER_HOME=/opt/flutter

    info "Installing Flutter dependencies..."
    sudo apt install -y curl git xz-utils libglu1-mesa clang cmake ninja-build pkg-config libgtk-3-dev

    if [ ! -d "$FLUTTER_HOME" ]; then
        info "Cloning Flutter SDK (lihat proses)..."
        cd /opt
        sudo git clone https://github.com/flutter/flutter.git -b stable --depth 1
        sudo chmod -R 777 $FLUTTER_HOME
        cd - > /dev/null
    fi

    export PATH=$PATH:$FLUTTER_HOME/bin

    info "Running flutter precache & doctor..."
    flutter precache --android || true
    flutter doctor || true

    ok "Flutter $(flutter --version | head -n1 | awk '{print $2}')"
}

# ============================================
# STEP 5: Environment Variables
# ============================================
setup_environment() {
    step "STEP 5/8: Environment Variables"

    ANDROID_HOME=/opt/android-sdk
    FLUTTER_HOME=/opt/flutter

    sudo sed -i '/JAVA_HOME/d' /etc/environment
    sudo sed -i '/ANDROID_HOME/d' /etc/environment
    sudo sed -i '/FLUTTER_HOME/d' /etc/environment

    echo "JAVA_HOME=$JAVA_HOME" | sudo tee -a /etc/environment
    echo "ANDROID_HOME=$ANDROID_HOME" | sudo tee -a /etc/environment
    echo "FLUTTER_HOME=$FLUTTER_HOME" | sudo tee -a /etc/environment

    if ! grep -q "export FLUTTER_HOME" $HOME/.bashrc; then
        {
            echo ""
            echo "# Web2APK Environment"
            echo "export JAVA_HOME=$JAVA_HOME"
            echo "export ANDROID_HOME=$ANDROID_HOME"
            echo "export ANDROID_NDK_HOME=$ANDROID_HOME/ndk/27.0.12077973"
            echo "export FLUTTER_HOME=$FLUTTER_HOME"
            echo "export PATH=\$PATH:\$ANDROID_HOME/cmdline-tools/latest/bin:\$ANDROID_HOME/platform-tools:\$FLUTTER_HOME/bin"
        } >> $HOME/.bashrc
    fi

    ok "Environment variables configured"
}

# ============================================
# STEP 6: PM2
# ============================================
install_pm2() {
    step "STEP 6/8: PM2"

    info "Installing PM2..."
    sudo npm install -g pm2
    ok "PM2 $(pm2 -v)"
}

# ============================================
# STEP 7: Telegram Local Bot API
# ============================================
install_local_api() {
    step "STEP 7/8: Telegram Local Bot API Server"

    echo "Dapatkan API ID & HASH dari https://my.telegram.org/apps"
    read -p "API ID   : " API_ID
    read -p "API HASH : " API_HASH

    if [ -z "$API_ID" ] || [ -z "$API_HASH" ]; then
        fail "API ID dan API HASH wajib diisi"
        exit 1
    fi

    info "Installing build dependencies..."
    sudo apt-get install -y make git zlib1g-dev libssl-dev gperf cmake g++ build-essential

    info "Cloning telegram-bot-api..."
    cd /opt
    if [ -d "telegram-bot-api" ]; then
        cd telegram-bot-api
        git pull
    else
        git clone --recursive https://github.com/tdlib/telegram-bot-api.git
        cd telegram-bot-api
    fi

    info "Building Telegram Bot API Server (10-30 menit, lihat proses)..."
    rm -rf build
    mkdir build
    cd build
    cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX:PATH=/usr/local ..
    cmake --build . --target install -j $(nproc)

    info "Creating systemd service..."
    sudo tee /etc/systemd/system/telegram-bot-api.service > /dev/null << EOF
[Unit]
Description=Telegram Bot API Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/telegram-bot-api --api-id=${API_ID} --api-hash=${API_HASH} --local --http-port=8081
Restart=always
RestartSec=5
User=root
WorkingDirectory=/opt/telegram-bot-api

[Install]
WantedBy=multi-user.target
EOF

    sudo systemctl daemon-reload
    sudo systemctl enable telegram-bot-api
    sudo systemctl start telegram-bot-api
    sleep 3

    if systemctl is-active --quiet telegram-bot-api; then
        ok "Local Bot API running on port 8081"
    else
        fail "Local Bot API gagal start. Cek: journalctl -u telegram-bot-api -e"
        exit 1
    fi
}

# ============================================
# SUMMARY
# ============================================
show_summary() {
    step "STEP 8/8: SELESAI"

    echo -e "${GREEN}Komponen terinstall:${NC}"
    echo "  Node.js      : $(node -v)"
    echo "  npm          : v$(npm -v)"
    echo "  Java         : $(java -version 2>&1 | head -n1)"
    echo "  Gradle       : $(gradle -v | grep Gradle | awk '{print $2}')"
    echo "  Android SDK  : API 34-36 + NDK 27.0.12077973"
    echo "  Flutter      : $(flutter --version | head -n1 | awk '{print $2}')"
    echo "  PM2          : $(pm2 -v)"
    if systemctl is-active --quiet telegram-bot-api 2>/dev/null; then
        echo "  Local API    : Running di port 8081"
    fi

    echo ""
    echo -e "${CYAN}Langkah selanjutnya:${NC}"
    echo "  1. source ~/.bashrc"
    echo "  2. git clone <repo> && cd web2apk"
    echo "  3. npm install"
    echo "  4. cp .env.example .env && nano .env"
    echo "     BOT_TOKEN=xxx"
    echo "     LOCAL_API_URL=http://localhost:8081"
    echo "  5. pm2 start src/bot.js --name web2apk"
    echo "     pm2 save && pm2 startup"
    echo ""
    echo -e "${GREEN}Selesai!${NC}"
}

# ============================================
# MAIN
# ============================================
detect_os
echo -e "${CYAN}OS terdeteksi: $OS_NAME $OS_VERSION ($OS_CODENAME)${NC}"

install_nodejs
install_java_gradle
install_android_sdk
install_flutter
setup_environment
install_pm2

echo ""
read -p "Install Telegram Local Bot API? (y/n): " INSTALL_API
if [[ "$INSTALL_API" =~ ^[Yy]$ ]]; then
    install_local_api
else
    info "Skip Local Bot API. File limit tetap 50MB."
fi

show_summary
