const axios = require('axios');
const fs = require('fs-extra');
const path = require('path');

const PAKASIR_API_URL = 'https://app.pakasir.com/api';
const PAKASIR_PROJECT = 'aan-digital';
const PAKASIR_API_KEY = 'QO7tbGxTZ1tYkAHtKkyYetXwUzW3eL6C';

const OWNER_PRICE = 5000;
const RESELLER_PRICE = 15000;
const MEMBER_PRICES = {
    '1d': 1000,
    '7d': 5000,
    '30d': 10000
};

async function createPakasirQRIS(amount, orderId) {
    try {
        console.log(`[PAKASIR] Creating QRIS for amount: ${amount}, order_id: ${orderId}`);
        
        const url = `${PAKASIR_API_URL}/transactioncreate/qris`;
        
        const payload = {
            project: PAKASIR_PROJECT,
            order_id: orderId,
            amount: amount,
            api_key: PAKASIR_API_KEY
        };
        
        console.log('[PAKASIR] Request payload:', JSON.stringify(payload));
        
        const response = await axios.post(url, payload, {
            headers: {
                'Content-Type': 'application/json'
            },
            timeout: 30000
        });
        
        console.log('[PAKASIR] Response status:', response.status);
        
        if (response.data && response.data.payment) {
            const payment = response.data.payment;
            return {
                success: true,
                qr_string: payment.payment_number || '',
                trxid: payment.order_id || orderId,
                expired: payment.expired_at || new Date(Date.now() + 10 * 60000).toISOString(),
                nominal: payment.amount || amount,
                total_payment: payment.total_payment || amount,
                fee: payment.fee || 0,
                payment_method: payment.payment_method || 'qris',
                payment_number: payment.payment_number || '',
                raw: payment
            };
        } else {
            return { 
                success: false, 
                error: response.data?.message || 'Gagal membuat Qris Payment' 
            };
        }
    } catch (error) {
        console.error('[PAKASIR] Create QRIS error:', error.response?.data || error.message);
        return { 
            success: false, 
            error: error.response?.data?.message || error.message 
        };
    }
}

async function checkPakasirTransaction(orderId, amount) {
    try {
        const url = `${PAKASIR_API_URL}/transactiondetail?project=${PAKASIR_PROJECT}&amount=${amount}&order_id=${orderId}&api_key=${PAKASIR_API_KEY}`;
        
        console.log('[PAKASIR] Checking transaction:', orderId);
        
        const response = await axios.get(url, { timeout: 30000 });
        
        console.log('[PAKASIR] Check response status:', response.status);
        
        if (response.data && response.data.transaction) {
            const transaction = response.data.transaction;
            console.log('[PAKASIR] Transaction status:', transaction.status);
            
            return {
                success: true,
                data: transaction
            };
        } else {
            return { 
                success: false, 
                data: null, 
                error: response.data?.message || 'Gagal cek transaksi Pakasir' 
            };
        }
    } catch (error) {
        console.error('[PAKASIR] Check transaction error:', error.response?.data || error.message);
        return { success: false, data: null, error: error.message };
    }
}

async function cancelPakasirTransaction(orderId, amount) {
    try {
        const url = `${PAKASIR_API_URL}/transactioncancel`;
        
        const payload = {
            project: PAKASIR_PROJECT,
            order_id: orderId,
            amount: amount,
            api_key: PAKASIR_API_KEY
        };
        
        console.log('[PAKASIR] Cancelling transaction:', orderId);
        
        const response = await axios.post(url, payload, {
            headers: {
                'Content-Type': 'application/json'
            },
            timeout: 30000
        });
        
        return {
            success: response.data?.success || false,
            data: response.data
        };
    } catch (error) {
        console.error('[PAKASIR] Cancel transaction error:', error.response?.data || error.message);
        return { success: false, error: error.message };
    }
}

module.exports = {
    PAKASIR_API_URL,
    PAKASIR_PROJECT,
    PAKASIR_API_KEY,
    OWNER_PRICE,
    RESELLER_PRICE,
    MEMBER_PRICES,
    createPakasirQRIS,
    checkPakasirTransaction,
    cancelPakasirTransaction
};
