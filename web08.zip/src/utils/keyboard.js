/**
 * Generate inline keyboards for bot
 */

// Main menu keyboard
function getMainKeyboard() {
    return {
        inline_keyboard: [
            [
                { text: '📱 BUAT APLIKASI (URL)', callback_data: 'create_apk', style: "danger" },
                { text: '📦 BUILD PROJECT (ZIP)', callback_data: 'build_zip', style: "danger" }
            ],
            [
                { text: '📋 Cek Antrian', callback_data: 'check_queue', style: "primary" },
                { text: '📜 Menu Perintah', callback_data: 'show_commands', style: "danger" },
                { text: '📢 Channel', url: 'https://t.me/aanchannell', style: "primary" }
            ],
            [               
                { text: '🛒 Beli Akses', callback_data: 'buy_access', style: "success" }
            ]
        ]
    };
}

// Color selection keyboard
function getColorKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '🔵 Biru', callback_data: 'color_blue' }, { text: '🔴 Merah', callback_data: 'color_red' }, { text: '🟢 Hijau', callback_data: 'color_green' }],
            [{ text: '🟣 Ungu', callback_data: 'color_purple' }, { text: '🟠 Oranye', callback_data: 'color_orange' }, { text: '🔵 Teal', callback_data: 'color_teal' }],
            [{ text: '💗 Pink', callback_data: 'color_pink' }, { text: '🔵 Indigo', callback_data: 'color_indigo' }],
            [{ text: '❌ Batal', callback_data: 'cancel' }]
        ]
    };
}

// Confirmation keyboard
function getConfirmKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '✅ Buat APK', callback_data: 'confirm_build', style: "success" }],
            [{ text: '❌ Batal', callback_data: 'cancel', style: "danger" }]
        ]
    };
}

// Cancel keyboard
function getCancelKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '❌ Batal', callback_data: 'cancel', style: "danger" }]
        ]
    };
}

// Icon upload keyboard
function getIconKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '⏭️ Lewati (Gunakan Default)', callback_data: 'skip_icon', style: "success" }],
            [{ text: '❌ Batal', callback_data: 'cancel', style: "danger" }]
        ]
    };
}

// ZIP project type keyboard
function getZipTypeKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '🤖 Android Studio / Gradle', callback_data: 'zip_android', style: "success" }, { text: '💙 Flutter Project', callback_data: 'zip_flutter', style: "success" }],
            [{ text: '❌ Batal', callback_data: 'cancel', style: "danger" }]
        ]
    };
}

// ZIP build type keyboard (debug/release)
function getZipBuildTypeKeyboard() {
    return {
        inline_keyboard: [
            [{ text: '🐛 Debug APK (Fast)', callback_data: 'zipbuild_debug', style: "success" }, { text: '🚀 Release APK', callback_data: 'zipbuild_release', style: "success" }],
            [{ text: '❌ Batal', callback_data: 'cancel', style: "danger" }]
        ]
    };
}

module.exports = {
    getMainKeyboard,
    getColorKeyboard,
    getConfirmKeyboard,
    getCancelKeyboard,
    getIconKeyboard,
    getZipTypeKeyboard,
    getZipBuildTypeKeyboard
};
