#!/bin/bash

# ============================================
# Web2APK Gen 3 - Complete VPS Setup Script
# ============================================
# This script combines:
#   1. VPS Setup (Node.js 22, Java, Gradle, Android SDK, Flutter, PM2)
#   2. Telegram Local Bot API Server Setup
# ============================================

set -e

# Colors with better styling
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BLUE='\033[0;34m'
WHITE='\033[1;37m'
BOLD='\033[1m'
NC='\033[0m'

# ============================================
# Banner Function with Animation Effect
# ============================================
show_banner() {
    clear
    echo ""
    echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║${NC}          ${BOLD}${MAGENTA}🚀 Web2APK Gen 3 - Ultimate VPS Setup${NC}              ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}              ${GREEN}✨ All-in-One Installation Script ✨${NC}                    ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}                                                                  ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  ${WHITE}📦 Includes:${NC} Node.js 22 • Java 17 • Gradle 8.7             ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  ${WHITE}🔧 Android SDK • Flutter • PM2 • Telegram Local API${NC}       ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}                                                                  ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  ${YELLOW}💡 Supports 2GB File Uploads via Local Bot API${NC}            ${CYAN}║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# ============================================
# Loading Animation
# ============================================
show_loading() {
    local msg="$1"
    local chars="/-\|"
    local i=0
    echo -ne "${YELLOW}⏳ ${msg} ${NC}"
    while true; do
        echo -ne "\b${chars:i++%4:1}"
        sleep 0.1
    done
}

stop_loading() {
    kill $! 2>/dev/null
    echo -e "\r${GREEN}✅ Done!${NC}                    "
}

# ============================================
# OS Detection Function
# ============================================
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS_NAME=$ID
        OS_VERSION=$VERSION_ID
        OS_CODENAME=$VERSION_CODENAME
    else
        OS_NAME="unknown"
        OS_CODENAME="unknown"
    fi
}

# ============================================
# Progress Bar
# ============================================
show_progress() {
    local current=$1
    local total=$2
    local width=40
    local percent=$((current * 100 / total))
    local filled=$((percent * width / 100))
    local empty=$((width - filled))
    
    printf "\r${CYAN}[${GREEN}"
    printf "%${filled}s" | tr ' ' '█'
    printf "${RED}"
    printf "%${empty}s" | tr ' ' '░'
    printf "${CYAN}] ${WHITE}%3d%%${NC}" "$percent"
}

# ============================================
# PART 1: System Update & Node.js 22
# ============================================
install_nodejs() {
    echo ""
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC}  ${BOLD}${WHITE}📦 STEP 1/8: System Update & Node.js 22 Installation${NC}   ${BLUE}║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    echo -e "${YELLOW}🔄 Updating system packages...${NC}"
    sudo apt update && sudo apt upgrade -y > /dev/null 2>&1
    echo -e "${GREEN}✅ System updated successfully${NC}"

    echo -e "${YELLOW}📥 Installing Node.js 22 LTS...${NC}"
    if ! command -v node &> /dev/null || [[ $(node -v | cut -d. -f1 | tr -d 'v') -lt 22 ]]; then
        curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - > /dev/null 2>&1
        sudo apt install -y nodejs > /dev/null 2>&1
    fi
    echo -e "${GREEN}✅ Node.js $(node -v) installed${NC}"
    echo -e "${GREEN}✅ npm v$(npm -v) installed${NC}"
    echo ""
}

# ============================================
# PART 2: Java & Gradle
# ============================================
install_java_gradle() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC}  ${BOLD}${WHITE}☕ STEP 2/8: Java 17 & Gradle 8.7 Setup${NC}                  ${BLUE}║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""

    echo -e "${YELLOW}☕ Installing Java 17...${NC}"

    if [ "$OS_NAME" = "debian" ]; then
        echo -e "${CYAN}  → Detected Debian, using Eclipse Temurin JDK${NC}"
        sudo apt install -y wget apt-transport-https gnupg > /dev/null 2>&1
        
        if [ ! -f /usr/share/keyrings/adoptium.gpg ]; then
            wget -qO - https://packages.adoptium.net/artifactory/api/gpg/key/public | sudo gpg --dearmor -o /usr/share/keyrings/adoptium.gpg
        fi
        
        if [ ! -f /etc/apt/sources.list.d/adoptium.list ]; then
            echo "deb [signed-by=/usr/share/keyrings/adoptium.gpg] https://packages.adoptium.net/artifactory/deb $OS_CODENAME main" | sudo tee /etc/apt/sources.list.d/adoptium.list > /dev/null
        fi
        
        sudo apt update > /dev/null 2>&1
        sudo apt install -y temurin-17-jdk > /dev/null 2>&1
        export JAVA_HOME=/usr/lib/jvm/temurin-17-jdk-amd64
    else
        echo -e "${CYAN}  → Using OpenJDK 17${NC}"
        sudo apt install -y openjdk-17-jdk > /dev/null 2>&1
        export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
    fi

    if ! java -version &>/dev/null; then
        echo -e "${RED}❌ ERROR: Java installation failed!${NC}"
        exit 1
    fi
    echo -e "${GREEN}✅ $(java -version 2>&1 | head -n1)${NC}"

    echo -e "${YELLOW}📦 Installing Gradle 8.7...${NC}"
    GRADLE_VERSION="8.7"
    if ! gradle -v 2>/dev/null | grep -q "$GRADLE_VERSION"; then
        cd /tmp > /dev/null
        wget -q "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -O gradle.zip
        sudo rm -rf /opt/gradle-${GRADLE_VERSION}
        sudo unzip -q -d /opt gradle.zip
        sudo ln -sf /opt/gradle-${GRADLE_VERSION}/bin/gradle /usr/bin/gradle
        rm gradle.zip
        cd - > /dev/null
    fi
    echo -e "${GREEN}✅ Gradle $(gradle -v | grep Gradle | awk '{print $2}') installed${NC}"
    echo ""
}

# ============================================
# PART 3: Android SDK
# ============================================
install_android_sdk() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC}  ${BOLD}${WHITE}📱 STEP 3/8: Android SDK Setup${NC}                          ${BLUE}║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""

    echo -e "${YELLOW}🔧 Installing Android SDK dependencies...${NC}"
    sudo apt install -y wget unzip zip lib32z1 lib32stdc++6 > /dev/null 2>&1

    ANDROID_HOME=/opt/android-sdk
    sudo mkdir -p $ANDROID_HOME/cmdline-tools
    cd $ANDROID_HOME/cmdline-tools > /dev/null

    if [ ! -d "latest" ]; then
        echo -e "${YELLOW}📥 Downloading Android SDK command line tools...${NC}"
        sudo wget -q "https://dl.google.com/android/repository/commandlinetools-linux-10406996_latest.zip" -O tools.zip
        sudo unzip -q tools.zip
        
        if [ -d "cmdline-tools" ]; then
            sudo mv cmdline-tools latest
        fi
        sudo rm -f tools.zip
    fi

    sudo chmod -R 777 $ANDROID_HOME

    export ANDROID_HOME=/opt/android-sdk
    export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

    echo -e "${YELLOW}📦 Installing SDK components (this may take a while)...${NC}"
    
    # Show progress for SDK installation
    echo -e "${CYAN}  → Accepting licenses...${NC}"
    yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses > /dev/null 2>&1 || true

    echo -e "${CYAN}  → Installing platforms and build tools...${NC}"
    $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager \
        "platforms;android-36" \
        "platforms;android-35" \
        "platforms;android-34" \
        "build-tools;36.0.0" \
        "build-tools;35.0.0" \
        "build-tools;34.0.0" \
        "build-tools;28.0.3" \
        "platform-tools" \
        "ndk;27.0.12077973" \
        "cmake;3.22.1" > /dev/null 2>&1

    export ANDROID_NDK_HOME=$ANDROID_HOME/ndk/27.0.12077973
    echo -e "${GREEN}✅ Android SDK installed with NDK 27.0.12077973${NC}"
    echo ""
}

# ============================================
# PART 4: Flutter SDK
# ============================================
install_flutter() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC}  ${BOLD}${WHITE}🦋 STEP 4/8: Flutter SDK Installation${NC}                    ${BLUE}║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""

    FLUTTER_HOME=/opt/flutter

    echo -e "${YELLOW}🔧 Installing Flutter dependencies...${NC}"
    sudo apt install -y curl git xz-utils libglu1-mesa clang cmake ninja-build pkg-config libgtk-3-dev > /dev/null 2>&1

    if [ ! -d "$FLUTTER_HOME" ]; then
        echo -e "${YELLOW}📥 Downloading Flutter SDK (this may take a while)...${NC}"
        cd /opt > /dev/null
        sudo git clone https://github.com/flutter/flutter.git -b stable --depth 1 > /dev/null 2>&1
        sudo chmod -R 777 $FLUTTER_HOME
        cd - > /dev/null
    fi

    export PATH=$PATH:$FLUTTER_HOME/bin

    echo -e "${CYAN}  → Running flutter doctor...${NC}"
    flutter precache --android > /dev/null 2>&1 || true
    flutter doctor > /dev/null 2>&1 || true

    echo -e "${GREEN}✅ Flutter $(flutter --version | head -n1 | awk '{print $2}') installed${NC}"
    echo ""
}

# ============================================
# PART 5: Environment Variables
# ============================================
setup_environment() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC}  ${BOLD}${WHITE}🌍 STEP 5/8: Environment Variables Setup${NC}                ${BLUE}║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""

    ANDROID_HOME=/opt/android-sdk
    FLUTTER_HOME=/opt/flutter

    sudo sed -i '/JAVA_HOME/d' /etc/environment
    sudo sed -i '/ANDROID_HOME/d' /etc/environment
    sudo sed -i '/FLUTTER_HOME/d' /etc/environment

    echo "JAVA_HOME=$JAVA_HOME" | sudo tee -a /etc/environment > /dev/null
    echo "ANDROID_HOME=$ANDROID_HOME" | sudo tee -a /etc/environment > /dev/null
    echo "FLUTTER_HOME=$FLUTTER_HOME" | sudo tee -a /etc/environment > /dev/null

    if ! grep -q "export FLUTTER_HOME" $HOME/.bashrc; then
        echo "" >> $HOME/.bashrc
        echo "# Web2APK Environment" >> $HOME/.bashrc
        echo "export JAVA_HOME=$JAVA_HOME" >> $HOME/.bashrc
        echo "export ANDROID_HOME=$ANDROID_HOME" >> $HOME/.bashrc
        echo "export ANDROID_NDK_HOME=$ANDROID_HOME/ndk/27.0.12077973" >> $HOME/.bashrc
        echo "export FLUTTER_HOME=$FLUTTER_HOME" >> $HOME/.bashrc
        echo "export PATH=\$PATH:\$ANDROID_HOME/cmdline-tools/latest/bin:\$ANDROID_HOME/platform-tools:\$FLUTTER_HOME/bin" >> $HOME/.bashrc
    fi
    
    echo -e "${GREEN}✅ Environment variables configured${NC}"
    echo ""
}

# ============================================
# PART 6: Install PM2
# ============================================
install_pm2() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC}  ${BOLD}${WHITE}⚡ STEP 6/8: PM2 Installation${NC}                             ${BLUE}║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""

    echo -e "${YELLOW}📦 Installing PM2 process manager...${NC}"
    sudo npm install -g pm2 > /dev/null 2>&1
    
    echo -e "${GREEN}✅ PM2 $(pm2 -v) installed${NC}"
    echo ""
}

# ============================================
# PART 7: Telegram Local Bot API Server
# ============================================
install_local_api() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║${NC}  ${BOLD}${WHITE}🤖 STEP 7/8: Telegram Local Bot API Server${NC}                ${BLUE}║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    echo -e "${YELLOW}💡 This allows 2GB file uploads (bypassing Telegram 50MB limit)${NC}"
    echo ""
    
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${WHITE}Please enter your Telegram API credentials:${NC}"
    echo -e "${YELLOW}(Get these from https://my.telegram.org/apps)${NC}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    
    read -p "  API ID: " API_ID
    read -p "  API HASH: " API_HASH
    
    if [ -z "$API_ID" ] || [ -z "$API_HASH" ]; then
        echo -e "${RED}❌ API ID and API HASH are required!${NC}"
        exit 1
    fi
    
    echo ""
    echo -e "${YELLOW}📦 Installing build dependencies...${NC}"
    apt-get install -y make git zlib1g-dev libssl-dev gperf cmake g++ build-essential > /dev/null 2>&1
    
    echo ""
    echo -e "${YELLOW}📥 Cloning Telegram Bot API repository...${NC}"
    cd /opt > /dev/null
    if [ -d "telegram-bot-api" ]; then
        echo -e "${CYAN}  → Repository exists, pulling latest...${NC}"
        cd telegram-bot-api > /dev/null
        git pull > /dev/null 2>&1
    else
        git clone --recursive https://github.com/tdlib/telegram-bot-api.git > /dev/null 2>&1
        cd telegram-bot-api > /dev/null
    fi
    
    echo ""
    echo -e "${YELLOW}🔨 Building Telegram Bot API Server...${NC}"
    echo -e "${CYAN}  ⏱️  This may take 10-30 minutes...${NC}"
    rm -rf build > /dev/null
    mkdir build > /dev/null
    cd build > /dev/null
    cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX:PATH=/usr/local .. > /dev/null 2>&1
    cmake --build . --target install -j $(nproc) > /dev/null 2>&1
    
    echo ""
    echo -e "${YELLOW}📝 Creating systemd service...${NC}"
    cat > /etc/systemd/system/telegram-bot-api.service << EOF
[Unit]
Description=Telegram Bot API Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/telegram-bot-api --api-id=${API_ID} --api-hash=${API_HASH} --local --http-port=8081
Restart=always
RestartSec=5
User=root
WorkingDirectory=/opt/telegram-bot-api

[Install]
WantedBy=multi-user.target
EOF
    
    echo ""
    echo -e "${YELLOW}🚀 Starting Telegram Bot API Server...${NC}"
    systemctl daemon-reload > /dev/null
    systemctl enable telegram-bot-api > /dev/null 2>&1
    systemctl start telegram-bot-api > /dev/null
    
    sleep 3
    
    if systemctl is-active --quiet telegram-bot-api; then
        echo -e "${GREEN}✅ Local Bot API Server is running on port 8081${NC}"
    else
        echo -e "${RED}❌ Failed to start Telegram Bot API Server${NC}"
        echo "   Check logs: journalctl -u telegram-bot-api -e"
        exit 1
    fi
    echo ""
}

# ============================================
# Show Final Summary with Better UI
# ============================================
show_summary() {
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║${NC}          ${BOLD}${WHITE}🎉 INSTALLATION COMPLETE!${NC}                         ${GREEN}║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║${NC}  ${BOLD}${WHITE}📦 Installed Components${NC}                                      ${CYAN}║${NC}"
    echo -e "${CYAN}╠══════════════════════════════════════════════════════════════════╣${NC}"
    echo -e "${CYAN}║${NC}  ✅ Node.js      : ${GREEN}$(node -v)${NC}                                          ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  ✅ npm          : ${GREEN}v$(npm -v)${NC}                                          ${CYAN}║${NC}"
    if [ "$OS_NAME" = "debian" ]; then
        echo -e "${CYAN}║${NC}  ✅ Java         : ${GREEN}Eclipse Temurin 17${NC}                               ${CYAN}║${NC}"
    else
        echo -e "${CYAN}║${NC}  ✅ Java         : ${GREEN}OpenJDK 17${NC}                                      ${CYAN}║${NC}"
    fi
    echo -e "${CYAN}║${NC}  ✅ Gradle       : ${GREEN}8.7${NC}                                                ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  ✅ Android SDK  : ${GREEN}API 34-36 with NDK${NC}                                 ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  ✅ Flutter      : ${GREEN}$(flutter --version | head -n1 | awk '{print $2}')${NC}                                          ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  ✅ PM2          : ${GREEN}$(pm2 -v)${NC}                                          ${CYAN}║${NC}"
    if systemctl is-active --quiet telegram-bot-api 2>/dev/null; then
        echo -e "${CYAN}║${NC}  ✅ Local API    : ${GREEN}Running on port 8081${NC}                           ${CYAN}║${NC}"
    fi
    echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""

    echo -e "${YELLOW}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}║${NC}  ${BOLD}${WHITE}📋 Next Steps${NC}                                                 ${YELLOW}║${NC}"
    echo -e "${YELLOW}╠══════════════════════════════════════════════════════════════════╣${NC}"
    echo -e "${YELLOW}║${NC}  1. Apply environment variables:                            ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}     ${GREEN}source ~/.bashrc${NC}                                            ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}                                                             ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}  2. Clone your bot repository:                             ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}     ${GREEN}git clone <your-repo-url>${NC}                                    ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}     ${GREEN}cd web2apk${NC}                                                  ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}                                                             ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}  3. Install dependencies:                                  ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}     ${GREEN}npm install${NC}                                                ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}                                                             ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}  4. Configure .env file:                                   ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}     ${GREEN}cp .env.example .env${NC}                                         ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}     ${GREEN}nano .env${NC}                                                  ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}                                                             ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}     Add these lines:                                        ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}     ${WHITE}BOT_TOKEN=your_bot_token${NC}                                      ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}     ${WHITE}LOCAL_API_URL=http://localhost:8081${NC}                           ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}                                                             ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}  5. Start your bot with PM2:                               ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}     ${GREEN}pm2 start src/bot.js --name web2apk${NC}                           ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}     ${GREEN}pm2 save${NC}                                                    ${YELLOW}║${NC}"
    echo -e "${YELLOW}║${NC}     ${GREEN}pm2 startup${NC}                                                 ${YELLOW}║${NC}"
    echo -e "${YELLOW}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""

    echo -e "${CYAN}╔══════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║${NC}  ${BOLD}${WHITE}📊 Useful Commands${NC}                                           ${CYAN}║${NC}"
    echo -e "${CYAN}╠══════════════════════════════════════════════════════════════════╣${NC}"
    echo -e "${CYAN}║${NC}  • Bot status      : ${GREEN}pm2 status${NC}                                    ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  • Bot logs        : ${GREEN}pm2 logs web2apk${NC}                               ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  • Restart bot     : ${GREEN}pm2 restart web2apk${NC}                            ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  • Local API status: ${GREEN}systemctl status telegram-bot-api${NC}              ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}  • Local API logs  : ${GREEN}journalctl -u telegram-bot-api -f${NC}              ${CYAN}║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════════════════════════╝${NC}"
    echo ""

    echo -e "${GREEN}══════════════════════════════════════════════════════════════════${NC}"
    echo -e "${BOLD}${WHITE}  🚀 Your VPS is ready for Web2APK Gen 3!${NC}"
    echo -e "${GREEN}══════════════════════════════════════════════════════════════════${NC}"
    echo ""
}

# ============================================
# Main Execution
# ============================================

show_banner

# Check if running as root for Local API setup
if [ "$EUID" -ne 0 ]; then
    echo -e "${YELLOW}⚠️  Note: Telegram Local Bot API Server requires root privileges.${NC}"
    echo -e "${YELLOW}   The script will ask for sudo when needed.${NC}"
    echo ""
fi

# Run VPS Setup
detect_os
echo -e "${CYAN}┌──────────────────────────────────────────────────────────────────┐${NC}"
echo -e "${CYAN}│${NC}  Detected OS: ${GREEN}$OS_NAME $OS_VERSION ($OS_CODENAME)${NC}                          ${CYAN}│${NC}"
echo -e "${CYAN}└──────────────────────────────────────────────────────────────────┘${NC}"
echo ""

install_nodejs
install_java_gradle
install_android_sdk
install_flutter
setup_environment
install_pm2

echo ""
echo -e "${GREEN}✅ VPS Setup Complete!${NC}"

# Ask if user wants to install Local Bot API
echo ""
echo -e "${CYAN}┌──────────────────────────────────────────────────────────────────┐${NC}"
echo -e "${CYAN}│${NC}  ${BOLD}${WHITE}🤖 Telegram Local Bot API Server${NC}                                     ${CYAN}│${NC}"
echo -e "${CYAN}├──────────────────────────────────────────────────────────────────┤${NC}"
echo -e "${CYAN}│${NC}  ${YELLOW}💡 This allows 2GB file uploads${NC}                                            ${CYAN}│${NC}"
echo -e "${CYAN}│${NC}  ${YELLOW}   Bypasses Telegram 50MB limit${NC}                                           ${CYAN}│${NC}"
echo -e "${CYAN}└──────────────────────────────────────────────────────────────────┘${NC}"
echo ""
read -p "$(echo -e ${WHITE}"Install Local Bot API? (y/n): "${NC})" INSTALL_API

if [[ "$INSTALL_API" =~ ^[Yy]$ ]]; then
    install_local_api
else
    echo -e "${YELLOW}⚠️  Skipping Local Bot API installation.${NC}"
    echo -e "${YELLOW}   Your bot will have 50MB file size limit.${NC}"
    echo ""
fi

show_summary