#!/bin/bash

# ============================================
# Web2APK Gen 3 - Complete VPS Setup Script
# ============================================
# This script combines:
#   1. VPS Setup (Node.js, Java, Gradle, Android SDK, Flutter, PM2)
#   2. Telegram Local Bot API Server Setup
# ============================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BLUE='\033[0;34m'
NC='\033[0m'

# ============================================
# Banner Function
# ============================================
show_banner() {
    echo ""
    echo -e "${CYAN}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║${NC}        ${MAGENTA}Web2APK Gen 3 - Complete VPS Setup${NC}                   ${CYAN}║${NC}"
    echo -e "${CYAN}║${NC}                    ${GREEN}All-in-One Installation${NC}                       ${CYAN}║${NC}"
    echo -e "${CYAN}╚════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# ============================================
# OS Detection Function
# ============================================
detect_os() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        OS_NAME=$ID
        OS_VERSION=$VERSION_ID
        OS_CODENAME=$VERSION_CODENAME
    else
        OS_NAME="unknown"
        OS_CODENAME="unknown"
    fi
}

# ============================================
# PART 1: System Update & Node.js
# ============================================
install_nodejs() {
    echo -e "${MAGENTA}[1/8] Updating system...${NC}"
    sudo apt update && sudo apt upgrade -y

    echo -e "${MAGENTA}[2/8] Installing Node.js 20...${NC}"
    if ! command -v node &> /dev/null || [[ $(node -v | cut -d. -f1 | tr -d 'v') -lt 18 ]]; then
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
        sudo apt install -y nodejs
    fi
    echo -e "${GREEN}  Node.js $(node -v)${NC}"
    echo -e "${GREEN}  npm v$(npm -v)${NC}"
}

# ============================================
# PART 2: Java & Gradle
# ============================================
install_java_gradle() {
    echo -e "${MAGENTA}[3/8] Installing Java 17...${NC}"

    if [ "$OS_NAME" = "debian" ]; then
        echo -e "${YELLOW}  Debian detected - Installing Eclipse Temurin JDK 17...${NC}"
        
        sudo apt install -y wget apt-transport-https gnupg
        
        if [ ! -f /usr/share/keyrings/adoptium.gpg ]; then
            wget -qO - https://packages.adoptium.net/artifactory/api/gpg/key/public | sudo gpg --dearmor -o /usr/share/keyrings/adoptium.gpg
        fi
        
        if [ ! -f /etc/apt/sources.list.d/adoptium.list ]; then
            echo "deb [signed-by=/usr/share/keyrings/adoptium.gpg] https://packages.adoptium.net/artifactory/deb $OS_CODENAME main" | sudo tee /etc/apt/sources.list.d/adoptium.list
        fi
        
        sudo apt update
        sudo apt install -y temurin-17-jdk
        
        export JAVA_HOME=/usr/lib/jvm/temurin-17-jdk-amd64
    else
        echo -e "${YELLOW}  Ubuntu/Other detected - Installing OpenJDK 17...${NC}"
        sudo apt install -y openjdk-17-jdk
        
        export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
    fi

    if ! java -version &>/dev/null; then
        echo -e "${RED}  ERROR: Java installation failed!${NC}"
        exit 1
    fi
    echo -e "${GREEN}  $(java -version 2>&1 | head -n1)${NC}"
    echo -e "${GREEN}  JAVA_HOME=$JAVA_HOME${NC}"

    echo -e "${MAGENTA}[4/8] Installing Gradle 8.7...${NC}"
    GRADLE_VERSION="8.7"
    if ! gradle -v 2>/dev/null | grep -q "$GRADLE_VERSION"; then
        cd /tmp
        wget -q "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip" -O gradle.zip
        sudo rm -rf /opt/gradle-${GRADLE_VERSION}
        sudo unzip -q -d /opt gradle.zip
        sudo ln -sf /opt/gradle-${GRADLE_VERSION}/bin/gradle /usr/bin/gradle
        rm gradle.zip
    fi
    echo -e "${GREEN}  Gradle $(gradle -v | grep Gradle | awk '{print $2}')${NC}"
}

# ============================================
# PART 3: Android SDK
# ============================================
install_android_sdk() {
    echo -e "${MAGENTA}[5/8] Setting up Android SDK...${NC}"
    sudo apt install -y wget unzip zip lib32z1 lib32stdc++6

    ANDROID_HOME=/opt/android-sdk
    sudo mkdir -p $ANDROID_HOME/cmdline-tools
    cd $ANDROID_HOME/cmdline-tools

    if [ ! -d "latest" ]; then
        echo -e "${YELLOW}  Downloading Android SDK command line tools...${NC}"
        sudo wget -q "https://dl.google.com/android/repository/commandlinetools-linux-10406996_latest.zip" -O tools.zip
        sudo unzip -q tools.zip
        
        if [ -d "cmdline-tools" ]; then
            sudo mv cmdline-tools latest
        fi
        sudo rm -f tools.zip
    fi

    sudo chmod -R 777 $ANDROID_HOME

    export ANDROID_HOME=/opt/android-sdk
    export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools

    echo -e "${YELLOW}  Installing SDK components (this may take a while)...${NC}"
    yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses > /dev/null 2>&1 || true

    $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager \
        "platforms;android-36" \
        "platforms;android-35" \
        "platforms;android-34" \
        "build-tools;36.0.0" \
        "build-tools;35.0.0" \
        "build-tools;34.0.0" \
        "build-tools;28.0.3" \
        "platform-tools" \
        "ndk;27.0.12077973" \
        "cmake;3.22.1"

    export ANDROID_NDK_HOME=$ANDROID_HOME/ndk/27.0.12077973
    echo -e "${GREEN}  NDK 27.0.12077973 installed${NC}"
}

# ============================================
# PART 4: Flutter SDK
# ============================================
install_flutter() {
    echo -e "${MAGENTA}[6/8] Installing Flutter SDK...${NC}"
    FLUTTER_HOME=/opt/flutter

    sudo apt install -y curl git xz-utils libglu1-mesa clang cmake ninja-build pkg-config libgtk-3-dev

    if [ ! -d "$FLUTTER_HOME" ]; then
        echo -e "${YELLOW}  Downloading Flutter SDK (this may take a while)...${NC}"
        cd /opt
        sudo git clone https://github.com/flutter/flutter.git -b stable --depth 1
        sudo chmod -R 777 $FLUTTER_HOME
    fi

    export PATH=$PATH:$FLUTTER_HOME/bin

    echo -e "${YELLOW}  Running flutter doctor...${NC}"
    flutter precache --android 2>/dev/null || true
    flutter doctor 2>/dev/null || true

    echo -e "${GREEN}  Flutter $(flutter --version | head -n1 | awk '{print $2}')${NC}"
}

# ============================================
# PART 5: Environment Variables
# ============================================
setup_environment() {
    echo -e "${MAGENTA}[7/8] Setting environment variables...${NC}"

    ANDROID_HOME=/opt/android-sdk
    FLUTTER_HOME=/opt/flutter

    sudo sed -i '/JAVA_HOME/d' /etc/environment
    sudo sed -i '/ANDROID_HOME/d' /etc/environment
    sudo sed -i '/FLUTTER_HOME/d' /etc/environment

    echo "JAVA_HOME=$JAVA_HOME" | sudo tee -a /etc/environment
    echo "ANDROID_HOME=$ANDROID_HOME" | sudo tee -a /etc/environment
    echo "FLUTTER_HOME=$FLUTTER_HOME" | sudo tee -a /etc/environment

    if ! grep -q "export FLUTTER_HOME" $HOME/.bashrc; then
        echo "" >> $HOME/.bashrc
        echo "# Web2APK Environment" >> $HOME/.bashrc
        echo "export JAVA_HOME=$JAVA_HOME" >> $HOME/.bashrc
        echo "export ANDROID_HOME=$ANDROID_HOME" >> $HOME/.bashrc
        echo "export ANDROID_NDK_HOME=$ANDROID_HOME/ndk/27.0.12077973" >> $HOME/.bashrc
        echo "export FLUTTER_HOME=$FLUTTER_HOME" >> $HOME/.bashrc
        echo "export PATH=\$PATH:\$ANDROID_HOME/cmdline-tools/latest/bin:\$ANDROID_HOME/platform-tools:\$FLUTTER_HOME/bin" >> $HOME/.bashrc
    fi
}

# ============================================
# PART 6: Install PM2
# ============================================
install_pm2() {
    echo -e "${MAGENTA}[8/8] Installing PM2...${NC}"
    sudo npm install -g pm2
    
    source $HOME/.bashrc 2>/dev/null || true
}

# ============================================
# PART 7: Telegram Local Bot API Server
# ============================================
install_local_api() {
    echo ""
    echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}     Telegram Local Bot API Server Setup${NC}"
    echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${YELLOW}This will install Telegram Local Bot API Server for 2GB file uploads${NC}"
    echo ""
    
    # Get API credentials
    echo -e "${CYAN}Please enter your Telegram API credentials:${NC}"
    echo -e "${YELLOW}(Get these from https://my.telegram.org/apps)${NC}"
    echo ""
    
    read -p "API ID: " API_ID
    read -p "API HASH: " API_HASH
    
    if [ -z "$API_ID" ] || [ -z "$API_HASH" ]; then
        echo -e "${RED}❌ API ID and API HASH are required!${NC}"
        exit 1
    fi
    
    echo ""
    echo -e "${YELLOW}📦 Installing dependencies...${NC}"
    apt-get install -y make git zlib1g-dev libssl-dev gperf cmake g++ build-essential
    
    echo ""
    echo -e "${YELLOW}📥 Cloning Telegram Bot API repository...${NC}"
    cd /opt
    if [ -d "telegram-bot-api" ]; then
        echo "   Repository already exists, pulling latest..."
        cd telegram-bot-api
        git pull
    else
        git clone --recursive https://github.com/tdlib/telegram-bot-api.git
        cd telegram-bot-api
    fi
    
    echo ""
    echo -e "${YELLOW}🔨 Building Telegram Bot API Server...${NC}"
    echo -e "${YELLOW}   This may take 10-30 minutes depending on your VPS specs...${NC}"
    rm -rf build
    mkdir build
    cd build
    cmake -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX:PATH=/usr/local ..
    cmake --build . --target install -j $(nproc)
    
    echo ""
    echo -e "${YELLOW}📝 Creating systemd service...${NC}"
    cat > /etc/systemd/system/telegram-bot-api.service << EOF
[Unit]
Description=Telegram Bot API Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/telegram-bot-api --api-id=${API_ID} --api-hash=${API_HASH} --local --http-port=8081
Restart=always
RestartSec=5
User=root
WorkingDirectory=/opt/telegram-bot-api

[Install]
WantedBy=multi-user.target
EOF
    
    echo ""
    echo -e "${YELLOW}🚀 Starting Telegram Bot API Server...${NC}"
    systemctl daemon-reload
    systemctl enable telegram-bot-api
    systemctl start telegram-bot-api
    
    sleep 3
    
    if systemctl is-active --quiet telegram-bot-api; then
        echo -e "${GREEN}✅ Local Bot API Server is running!${NC}"
    else
        echo -e "${RED}❌ Failed to start Telegram Bot API Server${NC}"
        echo "   Check logs: journalctl -u telegram-bot-api -e"
        exit 1
    fi
}

# ============================================
# Show Summary
# ============================================
show_summary() {
    echo ""
    echo -e "${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║           ✅ COMPLETE SETUP SUCCESSFUL!                    ║${NC}"
    echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${CYAN}📦 Installed Components:${NC}"
    echo "  • Node.js $(node -v)"
    echo "  • npm v$(npm -v)"
    if [ "$OS_NAME" = "debian" ]; then
        echo "  • Java 17 (Eclipse Temurin)"
    else
        echo "  • Java 17 (OpenJDK)"
    fi
    echo "  • Gradle 8.7"
    echo "  • Android SDK 34-36 + Build Tools + NDK"
    echo "  • Flutter SDK"
    echo "  • PM2"
    echo "  • Telegram Local Bot API Server (Port 8081)"
    echo ""
    echo -e "${CYAN}📋 Next Steps:${NC}"
    echo ""
    echo "  1. Apply environment variables:"
    echo -e "     ${GREEN}source ~/.bashrc${NC}"
    echo ""
    echo "  2. Clone your bot repository:"
    echo -e "     ${GREEN}git clone <your-repo-url>${NC}"
    echo -e "     ${GREEN}cd web2apk${NC}"
    echo ""
    echo "  3. Install dependencies:"
    echo -e "     ${GREEN}npm install${NC}"
    echo ""
    echo "  4. Configure .env file:"
    echo -e "     ${GREEN}cp .env.example .env${NC}"
    echo -e "     ${GREEN}nano .env${NC}"
    echo ""
    echo "     Add these lines to .env:"
    echo -e "     ${YELLOW}BOT_TOKEN=your_bot_token${NC}"
    echo -e "     ${YELLOW}LOCAL_API_URL=http://localhost:8081${NC}"
    echo ""
    echo "  5. Start your bot with PM2:"
    echo -e "     ${GREEN}pm2 start src/bot.js --name web2apk${NC}"
    echo -e "     ${GREEN}pm2 save${NC}"
    echo -e "     ${GREEN}pm2 startup${NC}"
    echo ""
    echo -e "${CYAN}📊 Useful Commands:${NC}"
    echo "  • Check bot status:    pm2 status"
    echo "  • View bot logs:       pm2 logs web2apk"
    echo "  • Restart bot:         pm2 restart web2apk"
    echo "  • Local API status:    systemctl status telegram-bot-api"
    echo "  • Local API logs:      journalctl -u telegram-bot-api -f"
    echo ""
    echo -e "${GREEN}════════════════════════════════════════════════════════════${NC}"
}

# ============================================
# Main Execution
# ============================================

show_banner

# Check if running as root for Local API setup
if [ "$EUID" -ne 0 ]; then
    echo -e "${YELLOW}⚠️  Note: Telegram Local Bot API Server requires root privileges.${NC}"
    echo -e "${YELLOW}   The script will ask for sudo when needed.${NC}"
    echo ""
fi

# Run VPS Setup
detect_os
echo -e "${CYAN}Detected OS: ${GREEN}$OS_NAME $OS_VERSION ($OS_CODENAME)${NC}"
echo ""

install_nodejs
install_java_gradle
install_android_sdk
install_flutter
setup_environment
install_pm2

echo ""
echo -e "${GREEN}✅ VPS Setup Complete!${NC}"

# Ask if user wants to install Local Bot API
echo ""
echo -e "${CYAN}Do you want to install Telegram Local Bot API Server?${NC}"
echo -e "${YELLOW}(This allows 2GB file uploads, bypassing Telegram 50MB limit)${NC}"
read -p "Install Local Bot API? (y/n): " INSTALL_API

if [[ "$INSTALL_API" =~ ^[Yy]$ ]]; then
    install_local_api
else
    echo -e "${YELLOW}⚠️  Skipping Local Bot API installation.${NC}"
    echo -e "${YELLOW}   Your bot will have 50MB file size limit.${NC}"
fi

show_summary