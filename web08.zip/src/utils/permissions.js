const ownerManager = require('./ownerManager');
const resellerService = require('./resellerService');

function isAdmin(chatId) {
    return ownerManager.isOwner(chatId);
}

function isReseller(chatId) {
    return resellerService.isReseller(chatId);
}

function getPriorityLevel(chatId) {
    if (isAdmin(chatId)) {
        return 2;
    }
    if (isReseller(chatId)) {
        return 1;
    }
    return 0;
}

module.exports = { isAdmin, isReseller, getPriorityLevel };