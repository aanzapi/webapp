const fs = require('fs-extra');
const path = require('path');

const OWNER_DB_PATH = path.join(__dirname, '..', 'data', 'owners.json');

class OwnerManager {
    constructor() {
        this.owners = new Set();
        this.loadDatabase();
    }

    loadDatabase() {
        try {
            fs.ensureDirSync(path.dirname(OWNER_DB_PATH));
            if (fs.existsSync(OWNER_DB_PATH)) {
                const data = fs.readFileSync(OWNER_DB_PATH, 'utf8');
                const parsed = JSON.parse(data);
                this.owners = new Set(parsed);
                console.log(`📂 Owners loaded: ${this.owners.size} owners`);
            } else {
                this.owners = new Set();
                this.persist();
            }
        } catch (error) {
            console.error('Failed to load owners database:', error);
            this.owners = new Set();
            this.persist();
        }
    }

    persist() {
        try {
            fs.ensureDirSync(path.dirname(OWNER_DB_PATH));
            fs.writeFileSync(OWNER_DB_PATH, JSON.stringify([...this.owners], null, 2));
        } catch (error) {
            console.error('Failed to save owners database:', error);
        }
    }

    isOwner(chatId) {
        const adminIds = (process.env.ADMIN_IDS || '').split(',').map(id => id.trim());
        return adminIds.includes(String(chatId)) || this.owners.has(String(chatId));
    }

    addOwner(chatId) {
        if (!chatId) return { success: false, error: 'ID tidak valid' };
        
        const id = String(chatId);
        if (this.owners.has(id)) {
            return { success: false, error: 'User sudah menjadi Owner' };
        }
        
        this.owners.add(id);
        this.persist();
        console.log(`👑 Owner added: ${id}`);
        return { success: true, message: 'Owner berhasil ditambahkan' };
    }

    removeOwner(chatId) {
        if (!chatId) return { success: false, error: 'ID tidak valid' };
        
        const id = String(chatId);
        const adminIds = (process.env.ADMIN_IDS || '').split(',').map(id => id.trim());
        
        if (adminIds.includes(id)) {
            return { success: false, error: 'Tidak bisa menghapus Owner utama (ADMIN_IDS)' };
        }
        
        if (!this.owners.has(id)) {
            return { success: false, error: 'User bukan Owner' };
        }
        
        this.owners.delete(id);
        this.persist();
        console.log(`👑 Owner removed: ${id}`);
        return { success: true, message: 'Owner berhasil dihapus' };
    }

    listOwners() {
        const adminIds = (process.env.ADMIN_IDS || '').split(',').map(id => id.trim());
        const allOwners = [...adminIds, ...this.owners];
        return allOwners;
    }

    getCount() {
        return this.owners.size;
    }

    getMainOwner() {
        const adminIds = (process.env.ADMIN_IDS || '').split(',').map(id => id.trim());
        return adminIds[0] || null;
    }
}

module.exports = new OwnerManager();