const { getMainKeyboard } = require('../utils/keyboard');
const { createPakasirQRIS, checkPakasirTransaction, cancelPakasirTransaction, OWNER_PRICE, RESELLER_PRICE, MEMBER_PRICES } = require('../utils/pakasir');
const ownerManager = require('../utils/ownerManager');
const resellerService = require('../utils/resellerService');
const licenseKeyService = require('../utils/licenseKeyService');
const { escapeHtml } = require('../utils/progressUI');
const fs = require('fs-extra');
const path = require('path');

const PAYMENT_SESSIONS = new Map();
const CHECK_INTERVALS = new Map();
const NOTIFICATION_PHOTO = 'https://cdn.phototourl.com/free/2026-07-14-e0899d92-7155-4fa7-8ec8-1ce6b3db23b7.png';
const CHANNEL_ID = '@aanmarket';

async function sendPaymentNotification(bot, type, data) {
    const timestamp = new Date().toLocaleString('id-ID', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });

    let message = '';
    let statusIcon = '';

    if (type === 'success') {
        statusIcon = '✅';
        message = `
╔═══════════════════════════════════╗
     ${statusIcon}  <b>PEMBAYARAN BERHASIL</b>  ${statusIcon}
╚═══════════════════════════════════╝

${data.notifMessage || 'Pembayaran berhasil!'}

🆔 <b>User ID:</b> <code>${data.userId || 'N/A'}</code>
👤 <b>User:</b> ${escapeHtml(data.userName || 'Unknown')}
💳 <b>Nominal:</b> <code>Rp ${data.amount?.toLocaleString() || 'N/A'}</code>
📅 <b>Waktu:</b> ${timestamp}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎉 <i>Akses telah diaktifkan!</i>
        `;
    }

    if (message) {
        try {
            await bot.sendPhoto(CHANNEL_ID, NOTIFICATION_PHOTO, {
                caption: message.trim(),
                parse_mode: 'HTML'
            });
            console.log(`📢 Payment notification sent to channel: ${type}`);
        } catch (error) {
            console.error(`Failed to send notification:`, error.message);
        }
    }
}

async function handlePaymentCallback(bot, query) {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const data = query.data;

    await bot.answerCallbackQuery(query.id);

    if (data === 'buy_access') {
        await showBuyAccessMenu(bot, chatId, messageId);
        return;
    }

    if (data === 'buy_owner') {
        await showOwnerPurchase(bot, chatId, messageId);
        return;
    }

    if (data === 'buy_reseller') {
        await showResellerPurchase(bot, chatId, messageId);
        return;
    }

    if (data === 'buy_member') {
        await showMemberPurchase(bot, chatId, messageId);
        return;
    }

    if (data.startsWith('buy_member_')) {
        const duration = data.replace('buy_member_', '');
        await showMemberPayment(bot, chatId, messageId, duration);
        return;
    }

    if (data === 'back_buy_menu') {
        await showBuyAccessMenu(bot, chatId, messageId);
        return;
    }

    if (data === 'back_main') {
        await backToMain(bot, chatId, messageId);
        return;
    }

    if (data.startsWith('pay_')) {
        const parts = data.split('_');
        const type = parts[1];
        const duration = parts[2] || null;
        await processPayment(bot, chatId, messageId, type, duration);
        return;
    }

    if (data === 'cancel_payment') {
        await cancelPayment(bot, chatId, messageId);
        return;
    }
}

async function showBuyAccessMenu(bot, chatId, messageId) {
    const isOwner = ownerManager.isOwner(chatId);
    const isReseller = resellerService.isReseller(chatId);
    const hasLicense = licenseKeyService.isUserAuthorized(chatId);

    let statusMessage = '';
    if (isOwner) {
        statusMessage = '👑 <b>Anda adalah OWNER!</b> (Akses unlimited)';
    } else if (isReseller) {
        statusMessage = '⭐ <b>Anda adalah RESELLER!</b> (Akses prioritas)';
    } else if (hasLicense) {
        statusMessage = '🎫 <b>Anda memiliki License!</b> (Akses member)';
    }

    const message = `
     🛒  <b>BELI AKSES BOT</b>  🛒

${statusMessage ? statusMessage + '\n\n' : ''}

Pilih tipe akses yang ingin Anda beli:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👑 <b>OWNER</b>
• Akses UNLIMITED build
• Bisa build banyak sekaligus
• Tanpa antrian
• Bisa buat akses Reseller & Member
• Harga: <code>Rp ${OWNER_PRICE.toLocaleString()}</code>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⭐ <b>RESELLER</b>
• Akses prioritas
• Bisa membuat license key
• Harga: <code>Rp ${RESELLER_PRICE.toLocaleString()}</code>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎫 <b>MEMBER</b>
• Akses build project
• Pilih durasi:
  • 1 Hari: <code>Rp ${MEMBER_PRICES['1d'].toLocaleString()}</code>
  • 7 Hari: <code>Rp ${MEMBER_PRICES['7d'].toLocaleString()}</code>
  • 30 Hari: <code>Rp ${MEMBER_PRICES['30d'].toLocaleString()}</code>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 <i>Pilih tipe akses di bawah:</i>
    `.trim();

    const keyboard = {
        inline_keyboard: [
            [{ text: '👑 Beli Owner', callback_data: 'buy_owner' }],
            [{ text: '⭐ Beli Reseller', callback_data: 'buy_reseller' }],
            [{ text: '🎫 Beli Member', callback_data: 'buy_member' }],
            [{ text: '◀️ Kembali ke Menu', callback_data: 'back_main' }]
        ]
    };

    try {
        await bot.editMessageText(message, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    } catch (error) {
        if (error.message.includes('there is no text in the message to edit')) {
            await bot.deleteMessage(chatId, messageId).catch(() => {});
            await bot.sendMessage(chatId, message, {
                parse_mode: 'HTML',
                reply_markup: keyboard
            });
        }
    }
}

async function showOwnerPurchase(bot, chatId, messageId) {
    const message = `
     👑  <b>BELI AKSES OWNER</b>  👑


<b>Benefit Owner:</b>
✅ Build UNLIMITED (tanpa batas)
✅ Build banyak sekaligus
✅ Tanpa antrian
✅ Prioritas tertinggi
✅ Bisa buat akses Reseller & Member
✅ Akses semua fitur

<b>Harga:</b> <code>Rp ${OWNER_PRICE.toLocaleString()}</code>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💰 <i>Pembayaran via QRIS (Pakasir)</i>
⏰ <i>QRIS berlaku 10 menit</i>

Klik tombol di bawah untuk melanjutkan pembayaran:
    `.trim();

    const keyboard = {
        inline_keyboard: [
            [{ text: '💰 Bayar Sekarang', callback_data: 'pay_owner' }],
            [{ text: '◀️ Kembali', callback_data: 'back_buy_menu' }]
        ]
    };

    try {
        await bot.editMessageText(message, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    } catch (error) {
        if (error.message.includes('there is no text in the message to edit')) {
            await bot.deleteMessage(chatId, messageId).catch(() => {});
            await bot.sendMessage(chatId, message, {
                parse_mode: 'HTML',
                reply_markup: keyboard
            });
        }
    }
}

async function showResellerPurchase(bot, chatId, messageId) {
    const message = `

     ⭐  <b>BELI AKSES RESELLER</b>  ⭐


<b>Benefit Reseller:</b>
✅ Akses build prioritas
✅ Bisa membuat license key (/addkey)
✅ Bisa memperpanjang license (/extendkey)
✅ Akses project tools

<b>Harga:</b> <code>Rp ${RESELLER_PRICE.toLocaleString()}</code>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💰 <i>Pembayaran via QRIS (Pakasir)</i>
⏰ <i>QRIS berlaku 10 menit</i>

Klik tombol di bawah untuk melanjutkan pembayaran:
    `.trim();

    const keyboard = {
        inline_keyboard: [
            [{ text: '💰 Bayar Sekarang', callback_data: 'pay_reseller' }],
            [{ text: '◀️ Kembali', callback_data: 'back_buy_menu' }]
        ]
    };

    try {
        await bot.editMessageText(message, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    } catch (error) {
        if (error.message.includes('there is no text in the message to edit')) {
            await bot.deleteMessage(chatId, messageId).catch(() => {});
            await bot.sendMessage(chatId, message, {
                parse_mode: 'HTML',
                reply_markup: keyboard
            });
        }
    }
}

async function showMemberPurchase(bot, chatId, messageId) {
    const message = `

     🎫  <b>BELI AKSES MEMBER</b>  🎫


Pilih durasi akses:

📅 <b>1 Hari</b> - <code>Rp ${MEMBER_PRICES['1d'].toLocaleString()}</code>
📅 <b>7 Hari</b> - <code>Rp ${MEMBER_PRICES['7d'].toLocaleString()}</code>
📅 <b>30 Hari</b> - <code>Rp ${MEMBER_PRICES['30d'].toLocaleString()}</code>

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💡 <i>Pilih durasi di bawah:</i>
    `.trim();

    const keyboard = {
        inline_keyboard: [
            [{ text: '📅 1 Hari (1K)', callback_data: 'buy_member_1d' }],
            [{ text: '📅 7 Hari (5K)', callback_data: 'buy_member_7d' }],
            [{ text: '📅 30 Hari (10K)', callback_data: 'buy_member_30d' }],
            [{ text: '◀️ Kembali', callback_data: 'back_buy_menu' }]
        ]
    };

    try {
        await bot.editMessageText(message, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    } catch (error) {
        if (error.message.includes('there is no text in the message to edit')) {
            await bot.deleteMessage(chatId, messageId).catch(() => {});
            await bot.sendMessage(chatId, message, {
                parse_mode: 'HTML',
                reply_markup: keyboard
            });
        }
    }
}

async function showMemberPayment(bot, chatId, messageId, duration) {
    const price = MEMBER_PRICES[duration];
    const durationText = {
        '1d': '1 Hari',
        '7d': '7 Hari',
        '30d': '30 Hari'
    }[duration];

    const message = `

     🎫  <b>BELI AKSES MEMBER</b>  🎫


<b>Durasi:</b> ${durationText}
<b>Harga:</b> <code>Rp ${price.toLocaleString()}</code>

<b>Benefit Member:</b>
✅ Akses build project
✅ Build dari URL
✅ Build dari ZIP
✅ Project tools (Analyze/Cleanup)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💰 <i>Pembayaran via QRIS (Pakasir)</i>
⏰ <i>QRIS berlaku 10 menit</i>

Klik tombol di bawah untuk melanjutkan pembayaran:
    `.trim();

    const keyboard = {
        inline_keyboard: [
            [{ text: '💰 Bayar Sekarang', callback_data: `pay_member_${duration}` }],
            [{ text: '◀️ Kembali', callback_data: 'buy_member' }]
        ]
    };

    try {
        await bot.editMessageText(message, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    } catch (error) {
        if (error.message.includes('there is no text in the message to edit')) {
            await bot.deleteMessage(chatId, messageId).catch(() => {});
            await bot.sendMessage(chatId, message, {
                parse_mode: 'HTML',
                reply_markup: keyboard
            });
        }
    }
}

async function processPayment(bot, chatId, messageId, type, duration = null) {
    let amount, orderId, description;

    if (type === 'owner') {
        amount = OWNER_PRICE;
        orderId = `OWNER_${chatId}_${Date.now()}`;
        description = 'Akses Owner Unlimited';
    } else if (type === 'reseller') {
        amount = RESELLER_PRICE;
        orderId = `RESELLER_${chatId}_${Date.now()}`;
        description = 'Akses Reseller';
    } else if (type === 'member') {
        amount = MEMBER_PRICES[duration];
        orderId = `MEMBER_${chatId}_${duration}_${Date.now()}`;
        description = `Akses Member ${duration}`;
    } else {
        return bot.sendMessage(chatId, '❌ Tipe pembayaran tidak valid');
    }

    const result = await createPakasirQRIS(amount, orderId);

    if (!result.success) {
        const errorMessage = `
❌ <b>Gagal Membuat QRIS!</b>
━━━━━━━━━━━━━━━━━━

Error: ${result.error}

💡 <i>Silakan coba lagi atau hubungi admin.</i>
        `.trim();

        try {
            await bot.editMessageText(errorMessage, {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔄 Coba Lagi', callback_data: `pay_${type}${duration ? '_' + duration : ''}` }],
                        [{ text: '◀️ Kembali', callback_data: 'back_buy_menu' }]
                    ]
                }
            });
        } catch (error) {
            if (error.message.includes('there is no text in the message to edit')) {
                await bot.deleteMessage(chatId, messageId).catch(() => {});
                await bot.sendMessage(chatId, errorMessage, {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Coba Lagi', callback_data: `pay_${type}${duration ? '_' + duration : ''}` }],
                            [{ text: '◀️ Kembali', callback_data: 'back_buy_menu' }]
                        ]
                    }
                });
            }
        }
        return;
    }

    const session = {
        type,
        duration,
        amount,
        orderId,
        trxid: result.trxid,
        createdAt: Date.now(),
        messageId: messageId,
        completed: false,
        chatId: chatId
    };

    PAYMENT_SESSIONS.set(chatId, session);

    const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(result.qr_string)}`;

    const message = `

     💳  <b>KONFIRMASI PEMBAYARAN</b>  💳


<b>Order ID:</b> <code>${orderId}</code>
<b>Jenis:</b> ${description}
<b>Nominal:</b> <code>Rp ${amount.toLocaleString()}</code>

📱 <b>Scan QRIS di bawah:</b>

⏰ <i>QRIS berlaku 10 menit</i>
💡 <i>Bot otomatis mendeteksi pembayaran!</i>
    `.trim();

    const keyboard = {
        inline_keyboard: [
            [{ text: '❌ Batalkan', callback_data: 'cancel_payment' }],
            [{ text: '◀️ Kembali', callback_data: 'back_buy_menu' }]
        ]
    };

    try {
        await bot.editMessageText(message, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: keyboard
        });
    } catch (error) {
        if (error.message.includes('there is no text in the message to edit')) {
            await bot.deleteMessage(chatId, messageId).catch(() => {});
            await bot.sendMessage(chatId, message, {
                parse_mode: 'HTML',
                reply_markup: keyboard
            });
        }
    }

    await bot.sendPhoto(chatId, qrImageUrl, {
        caption: `📱 <b>QRIS Payment</b>\n\n💳 <b>Nominal:</b> Rp ${amount.toLocaleString()}\n🆔 <code>${orderId}</code>\n\n⏰ <i>QRIS berlaku 10 menit</i>`,
        parse_mode: 'HTML'
    });

    startAutoCheck(bot, chatId, session);
}

function startAutoCheck(bot, chatId, session) {
    let checkCount = 0;
    const maxChecks = 30;
    const interval = 5000;

    console.log(`[AUTOCHECK] Starting auto check for ${session.orderId}`);

    if (CHECK_INTERVALS.has(chatId)) {
        clearInterval(CHECK_INTERVALS.get(chatId));
        CHECK_INTERVALS.delete(chatId);
    }

    const intervalId = setInterval(async () => {
        checkCount++;
        
        if (session.completed) {
            console.log(`[AUTOCHECK] Session already completed for ${session.orderId}`);
            clearInterval(intervalId);
            CHECK_INTERVALS.delete(chatId);
            return;
        }

        console.log(`[AUTOCHECK] Check #${checkCount} for ${session.orderId}`);

        const result = await checkPakasirTransaction(session.orderId, session.amount);

        if (result.success && result.data) {
            const transaction = result.data;
            const status = transaction.status || '';
            
            console.log(`[AUTOCHECK] Status: ${status}`);

            if (status === 'completed' || status === 'paid' || status === 'success') {
                console.log(`[AUTOCHECK] ✅ Payment completed for ${session.orderId}`);
                session.completed = true;
                clearInterval(intervalId);
                CHECK_INTERVALS.delete(chatId);
                
                await handleSuccessfulPayment(bot, chatId, session);
                PAYMENT_SESSIONS.delete(chatId);
                return;
            }
        }

        if (checkCount >= maxChecks) {
            console.log(`[AUTOCHECK] ⏰ Timeout for ${session.orderId}`);
            clearInterval(intervalId);
            CHECK_INTERVALS.delete(chatId);
            
            await bot.sendMessage(chatId, `
⏰ <b>Auto-Check Timeout!</b>
━━━━━━━━━━━━━━━━━━

Jika sudah bayar, silakan klik tombol "Cek Manual".

💡 <i>Atau hubungi admin jika masih masalah.</i>
            `.trim(), {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🔍 Cek Manual', callback_data: 'check_payment' }]
                    ]
                }
            });
        }
    }, interval);

    CHECK_INTERVALS.set(chatId, intervalId);
}

async function handleSuccessfulPayment(bot, chatId, session) {
    const { type, duration } = session;

    let message = '';
    let notifMessage = '';
    let success = false;

    console.log(`[PAYMENT] Processing payment for user ${chatId}, type: ${type}`);

    if (type === 'owner') {
        // CEK APAKAH USER SUDAH RESELLER ATAU MEMBER
        const isReseller = resellerService.isReseller(chatId);
        const hasLicense = licenseKeyService.isUserAuthorized(chatId);

        console.log(`[PAYMENT] User ${chatId}: isReseller=${isReseller}, hasLicense=${hasLicense}`);

        // HAPUS DARI RESELLER JIKA ADA
        if (isReseller) {
            const removeResult = resellerService.removeReseller(chatId);
            console.log(`[PAYMENT] Remove reseller result:`, removeResult);
        }

        // HAPUS DARI LICENSE/MEMBER JIKA ADA
        if (hasLicense) {
            const username = licenseKeyService.getUsernameByTelegramId(chatId);
            if (username) {
                const deleteResult = licenseKeyService.deleteKey(username);
                console.log(`[PAYMENT] Delete license result:`, deleteResult);
            }
        }

        // TAMBAHKAN KE OWNER
        const result = ownerManager.addOwner(chatId);
        console.log(`[PAYMENT] Add owner result:`, result);
        console.log(`[PAYMENT] All owners now:`, ownerManager.listOwners());

        if (result.success) {
            success = true;
            message = `
✅ <b>PEMBAYARAN BERHASIL!</b>
━━━━━━━━━━━━━━━━━━

🎉 Selamat! Anda sekarang adalah <b>OWNER</b>!

<b>Fitur yang Anda dapatkan:</b>
✅ Build UNLIMITED (tanpa batas)
✅ Build banyak sekaligus
✅ Tanpa antrian
✅ Prioritas tertinggi
✅ Bisa buat akses Reseller & Member
✅ Akses semua fitur

💡 <i>Anda sekarang bisa build tanpa batas!</i>
            `;
            notifMessage = `👑 User ${chatId} telah menjadi OWNER!`;
        } else {
            message = `❌ Gagal menambahkan Owner: ${result.error}`;
        }

    } else if (type === 'reseller') {
        // CEK APAKAH USER SUDAH OWNER
        const isOwner = ownerManager.isOwner(chatId);
        console.log(`[PAYMENT] User ${chatId}: isOwner=${isOwner}`);

        if (isOwner) {
            message = `
⚠️ <b>Anda sudah menjadi OWNER!</b>
━━━━━━━━━━━━━━━━━━

Anda sudah memiliki akses OWNER yang lebih tinggi dari RESELLER.

💡 <i>Anda tetap bisa menggunakan semua fitur Owner!</i>
            `;
            notifMessage = `⚠️ User ${chatId} sudah Owner, tidak perlu Reseller`;
            success = true;
        } else {
            // HAPUS DARI LICENSE/MEMBER JIKA ADA
            const hasLicense = licenseKeyService.isUserAuthorized(chatId);
            if (hasLicense) {
                const username = licenseKeyService.getUsernameByTelegramId(chatId);
                if (username) {
                    licenseKeyService.deleteKey(username);
                    console.log(`[PAYMENT] Deleted license for ${username}`);
                }
            }

            // TAMBAHKAN KE RESELLER
            const result = resellerService.addReseller(chatId, `User_${chatId}`);
            console.log(`[PAYMENT] Add reseller result:`, result);

            if (result.success) {
                success = true;
                message = `
✅ <b>PEMBAYARAN BERHASIL!</b>
━━━━━━━━━━━━━━━━━━

🎉 Selamat! Anda sekarang adalah <b>RESELLER</b>!

<b>Fitur yang Anda dapatkan:</b>
✅ Akses build prioritas
✅ Bisa membuat license key (/addkey)
✅ Bisa memperpanjang license (/extendkey)
✅ Akses project tools

💡 <i>Anda sekarang bisa membuat license key!</i>
                `;
                notifMessage = `⭐ User ${chatId} telah menjadi RESELLER!`;
            } else {
                message = `❌ Gagal menambahkan Reseller: ${result.error}`;
            }
        }

    } else if (type === 'member') {
        // CEK APAKAH USER SUDAH OWNER ATAU RESELLER
        const isOwner = ownerManager.isOwner(chatId);
        const isReseller = resellerService.isReseller(chatId);

        console.log(`[PAYMENT] User ${chatId}: isOwner=${isOwner}, isReseller=${isReseller}`);

        if (isOwner) {
            message = `
⚠️ <b>Anda sudah menjadi OWNER!</b>
━━━━━━━━━━━━━━━━━━

Anda sudah memiliki akses OWNER yang lebih tinggi dari MEMBER.

💡 <i>Anda tetap bisa menggunakan semua fitur Owner!</i>
            `;
            notifMessage = `⚠️ User ${chatId} sudah Owner, tidak perlu Member`;
            success = true;
        } else if (isReseller) {
            message = `
⚠️ <b>Anda sudah menjadi RESELLER!</b>
━━━━━━━━━━━━━━━━━━

Anda sudah memiliki akses RESELLER yang lebih tinggi dari MEMBER.

💡 <i>Anda tetap bisa menggunakan semua fitur Reseller!</i>
            `;
            notifMessage = `⚠️ User ${chatId} sudah Reseller, tidak perlu Member`;
            success = true;
        } else {
            const days = parseInt(duration.replace('d', ''));
            const telegramId = String(chatId);
            const username = `user_${chatId}`;
            
            const result = licenseKeyService.createKey(username, days, telegramId);
            console.log(`[PAYMENT] Create license result:`, result);

            if (result.success) {
                success = true;
                message = `
✅ <b>PEMBAYARAN BERHASIL!</b>
━━━━━━━━━━━━━━━━━━

🎉 Selamat! Anda sekarang memiliki akses <b>MEMBER</b>!

<b>Detail Akses:</b>
📅 Durasi: ${days} Hari
🔑 License Key: <code>${result.key}</code>
⏰ Berlaku hingga: ${new Date(result.expiresAt).toLocaleDateString('id-ID', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                })}

<b>Fitur yang Anda dapatkan:</b>
✅ Akses build project
✅ Build dari URL
✅ Build dari ZIP
✅ Project tools (Analyze/Cleanup)

💡 <i>Simpan License Key Anda!</i>
                `;
                notifMessage = `🎫 User ${chatId} telah menjadi MEMBER (${days} hari)!`;
            } else {
                message = `❌ Gagal membuat License: ${result.error}`;
            }
        }
    }

    // KIRIM PESAN KE USER
    if (message) {
        await bot.sendMessage(chatId, message.trim(), {
            parse_mode: 'HTML',
            reply_markup: getMainKeyboard()
        });
    }

    // KIRIM NOTIFIKASI KE CHANNEL
    if (notifMessage && success) {
        await sendPaymentNotification(bot, 'success', {
            userId: chatId,
            userName: `User ${chatId}`,
            amount: session.amount,
            notifMessage: notifMessage
        });
    }

    // KIRIM NOTIFIKASI KE OWNER
    const ownerId = ownerManager.getMainOwner();
    if (ownerId && notifMessage && success) {
        try {
            await bot.sendMessage(ownerId, `
📢 <b>NOTIFIKASI PEMBAYARAN</b>
━━━━━━━━━━━━━━━━━━

${notifMessage}

🆔 User ID: <code>${chatId}</code>
💳 Nominal: <code>Rp ${session.amount.toLocaleString()}</code>
📅 Waktu: ${new Date().toLocaleString('id-ID')}
            `.trim(), { parse_mode: 'HTML' });
        } catch (error) {
            console.error('Failed to send notification to owner:', error);
        }
    }
}

async function cancelPayment(bot, chatId, messageId) {
    const session = PAYMENT_SESSIONS.get(chatId);
    if (session) {
        await cancelPakasirTransaction(session.orderId, session.amount);
        PAYMENT_SESSIONS.delete(chatId);
    }

    if (CHECK_INTERVALS.has(chatId)) {
        clearInterval(CHECK_INTERVALS.get(chatId));
        CHECK_INTERVALS.delete(chatId);
    }

    const message = `
❌ <b>Pembayaran Dibatalkan</b>
━━━━━━━━━━━━━━━━━━

Pembayaran telah dibatalkan.

💡 <i>Klik menu untuk membeli akses lagi.</i>
    `.trim();

    try {
        await bot.editMessageText(message, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🛒 Beli Akses', callback_data: 'buy_access' }],
                    [{ text: '◀️ Kembali ke Menu', callback_data: 'back_main' }]
                ]
            }
        });
    } catch (error) {
        if (error.message.includes('there is no text in the message to edit')) {
            await bot.deleteMessage(chatId, messageId).catch(() => {});
            await bot.sendMessage(chatId, message, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '🛒 Beli Akses', callback_data: 'buy_access' }],
                        [{ text: '◀️ Kembali ke Menu', callback_data: 'back_main' }]
                    ]
                }
            });
        }
    }
}

async function backToMain(bot, chatId, messageId) {
    global.sessions.delete(chatId);

    await bot.deleteMessage(chatId, messageId).catch(() => {});

    const welcomeCaption = `
👋 <b>Selamat Datang !</b>

🤖 <b>Web2Apk Pro Bot Gen 4 ( Beta )</b> adalah solusi instant mengubah website menjadi aplikasi Android.

✨ <i>Fitur Premium:</i>
• Tanpa Iklan
• Proses Cepat
• Custom Icon Support

👇 <b>Mulai project Anda sekarang:</b>
    `.trim();

    await bot.sendPhoto(chatId, 'https://cdn.phototourl.com/free/2026-07-14-e0899d92-7155-4fa7-8ec8-1ce6b3db23b7.png', {
        caption: welcomeCaption,
        parse_mode: 'HTML',
        reply_markup: getMainKeyboard()
    }).catch(async () => {
        await bot.sendMessage(chatId, welcomeCaption, {
            parse_mode: 'HTML',
            reply_markup: getMainKeyboard()
        });
    });
}

module.exports = { 
    handlePaymentCallback, 
    PAYMENT_SESSIONS,
    CHECK_INTERVALS,
    handleSuccessfulPayment,
    startAutoCheck
};