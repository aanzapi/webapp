const { getMainKeyboard, getConfirmKeyboard, getCancelKeyboard, getZipTypeKeyboard, getZipBuildTypeKeyboard } = require('../utils/keyboard');
const { buildApk } = require('../builder/apkBuilder');
const { buildFromZip } = require('../builder/zipBuilder');
const { sendBuildReport } = require('../utils/adminReporter');
const { formatBuildProgress, formatBuildStartMessage, formatSuccessMessage, formatErrorMessage, formatZipBuildProgress, sendErrorLog, sendBuildNotification, escapeHtml } = require('../utils/progressUI');
const { buildManager } = require('../utils/buildQueue');
const licenseKeyService = require('../utils/licenseKeyService');
const resellerService = require('../utils/resellerService');
const { isReseller, isAdmin } = require('../utils/permissions');
const path = require('path');
const fs = require('fs-extra');

function getUserPriorityLevel(chatId) {
    const ownerManager = require('../utils/ownerManager');
    
    if (ownerManager.isOwner(chatId)) {
        return 2;
    }
    
    if (resellerService.isReseller(chatId)) {
        return 1;
    }
    
    return 0;
}

function getPriorityEmoji(chatId) {
    const adminIds = process.env.ADMIN_IDS?.split(',').map(id => id.trim()) || [];
    
    if (adminIds.includes(String(chatId))) {
        return '👑';
    }
    if (resellerService.isReseller(chatId)) {
        return '⭐';
    }
    return '';
}

async function sendVpsErrorLog(bot, chatId, errorContext) {
    const logsBaseDir = '/root/webapp/logs/';
    
    let latestErrorFile = null;
    let latestTime = 0;
    
    try {
        if (!await fs.pathExists(logsBaseDir)) {
            console.log('Logs directory not found:', logsBaseDir);
            return false;
        }
        
        const files = await fs.readdir(logsBaseDir);
        const errorFiles = files.filter(file => file.endsWith('.log.error'));
        
        if (errorFiles.length === 0) {
            console.log('No .log.error files found in', logsBaseDir);
            return false;
        }
        
        for (const file of errorFiles) {
            const filePath = path.join(logsBaseDir, file);
            const stats = await fs.stat(filePath);
            if (stats.mtimeMs > latestTime) {
                latestTime = stats.mtimeMs;
                latestErrorFile = filePath;
            }
        }
        
        if (!latestErrorFile) {
            return false;
        }
        
        const errorContent = await fs.readFile(latestErrorFile, 'utf8');
        
        if (!errorContent.trim()) {
            return false;
        }
        
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const tempFileName = `error_log_${errorContext}_${timestamp}.txt`;
        const tempFilePath = path.join('/tmp', tempFileName);
        
        const formattedContent = `=== ERROR LOG REPORT ===
Context: ${errorContext}
Date: ${new Date().toLocaleString('id-ID')}
File Source: ${path.basename(latestErrorFile)}
================================

${errorContent}
`;
        
        await fs.writeFile(tempFilePath, formattedContent, 'utf8');
        
        await bot.sendDocument(chatId, tempFilePath, {
            caption: `📋 <b>Error Log Detected</b>\n\n🔍 <b>Source:</b> ${path.basename(latestErrorFile)}\n📂 <b>Context:</b> ${errorContext}\n⏰ <b>Time:</b> ${new Date().toLocaleString('id-ID')}\n\n💡 <i>File ini diambil dari /root/webapp/logs/</i>`,
            parse_mode: 'HTML'
        });
        
        await fs.remove(tempFilePath).catch(() => {});
        
        return true;
        
    } catch (error) {
        console.error('Error reading VPS logs:', error);
        return false;
    }
}

async function cleanupOldErrorLogs(maxAgeHours = 24) {
    const logsBaseDir = '/root/webapp/logs/';
    const maxAgeMs = maxAgeHours * 60 * 60 * 1000;
    const now = Date.now();
    
    try {
        if (!await fs.pathExists(logsBaseDir)) {
            return;
        }
        
        const files = await fs.readdir(logsBaseDir);
        const errorFiles = files.filter(file => file.endsWith('.log.error'));
        
        let deletedCount = 0;
        for (const file of errorFiles) {
            const filePath = path.join(logsBaseDir, file);
            const stats = await fs.stat(filePath);
            const age = now - stats.mtimeMs;
            
            if (age > maxAgeMs) {
                await fs.remove(filePath);
                deletedCount++;
                console.log(`🗑️ Deleted old error log: ${file}`);
            }
        }
        
        if (deletedCount > 0) {
            console.log(`✅ Cleaned up ${deletedCount} old error log files`);
        }
    } catch (error) {
        console.error('Error cleaning up old error logs:', error);
    }
}

async function handleCallback(bot, query) {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
    const data = query.data;

    const userInfo = {
        id: query.from.id,
        firstName: query.from.first_name || 'User',
        lastName: query.from.last_name || '',
        username: query.from.username || null
    };

    await bot.answerCallbackQuery(query.id);

    switch (data) {
        case 'create_apk':
            await startCreateApk(bot, chatId, messageId, userInfo);
            break;

        case 'help':
            await showHelp(bot, chatId, messageId);
            break;

        case 'back_main':
            await backToMain(bot, chatId, messageId);
            break;

        case 'cancel':
            await cancelProcess(bot, chatId, messageId);
            break;

        case 'skip_icon':
            await skipIcon(bot, chatId, messageId);
            break;

        case 'confirm_build':
            await confirmBuild(bot, chatId, messageId);
            break;

        case 'build_zip':
            await startBuildZip(bot, chatId, messageId);
            break;

        case 'zip_android':
            await selectZipType(bot, chatId, messageId, 'android', userInfo);
            break;

        case 'zip_flutter':
            await selectZipType(bot, chatId, messageId, 'flutter', userInfo);
            break;

        case 'zipbuild_debug':
            await selectZipBuildType(bot, chatId, messageId, 'debug', userInfo);
            break;

        case 'zipbuild_release':
            await selectZipBuildType(bot, chatId, messageId, 'release', userInfo);
            break;

        case 'server_status':
            await showServerStatus(bot, chatId, messageId);
            break;

        case 'check_queue':
            await showQueueStatus(bot, chatId, messageId);
            break;

        case 'thanks_to':
            await showThanksTo(bot, chatId, messageId);
            break;

        case 'show_commands':
            await showCommandsMenu(bot, chatId, messageId, query.from);
            break;

        case 'cancel_queue':
            await cancelQueuedBuild(bot, chatId, messageId);
            break;
    }
}

async function startCreateApk(bot, chatId, messageId, userInfo = {}) {
    const fullName = [userInfo.firstName, userInfo.lastName].filter(Boolean).join(' ').trim() || 'Unknown';

    const licenseUsername = licenseKeyService.getUsernameByTelegramId(chatId);

    let displayName = fullName;
    if (userInfo.username) {
        displayName += ` (@${userInfo.username})`;
    }
    if (licenseUsername) {
        displayName += ` [${licenseUsername}]`;
    }

    global.sessions.set(chatId, {
        step: 'url',
        userName: displayName,
        userUsername: userInfo.username || null,
        licenseUsername: licenseUsername,
        data: {
            url: null,
            appName: null,
            iconPath: null,
            themeColor: '#2196F3'
        }
    });

    await bot.deleteMessage(chatId, messageId).catch(() => { });

    const message = `
📱 <b>Buat APK Baru</b>
━━━━━━━━━━━━━━━━━━

<b>Langkah 1/3: URL Website</b>

Silakan kirim URL website yang ingin dikonversi menjadi APK.

<i>Contoh: https://example.com</i>
    `.trim();

    await bot.sendMessage(chatId, message, {
        parse_mode: 'HTML',
        reply_markup: getCancelKeyboard()
    });
}

async function showHelp(bot, chatId, messageId) {
    const helpMessage = `
📚 <b>PANDUAN WEB2APK BOT</b>
━━━━━━━━━━━━━━━━━━

<b>📱 Cara Membuat APK:</b>
1. Klik tombol "BUAT APLIKASI SEKARANG"
2. Masukkan URL website target
3. Masukkan nama aplikasi
4. Upload icon (opsional)
5. Tunggu proses build (~1-3 menit)

<b>💡 Tips:</b>
• URL harus dimulai dengan http:// atau https://
• Nama aplikasi maksimal 30 karakter
• Icon sebaiknya ukuran 512x512 px
• Format icon: JPG/PNG

<b>❓ Butuh Bantuan?</b>
Hubungi: @AanzCuyxzzz
    `.trim();

    await bot.deleteMessage(chatId, messageId).catch(() => { });

    await bot.sendMessage(chatId, helpMessage, {
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [{ text: '◀️ Kembali ke Menu', callback_data: 'back_main', style: "danger" }]
            ]
        }
    });
}

async function showServerStatus(bot, chatId, messageId) {
    const queueInfo = buildManager.getQueueInfo();
    const activeBuilds = buildManager.getActiveBuilds();
    const stats = buildManager.getStats();

    let statusMessage;
    if (activeBuilds.length > 0) {
        const build = activeBuilds[0];
        const minutes = Math.floor(build.duration / 60);
        const seconds = build.duration % 60;

        statusMessage = `
📊 <b>Status Server</b>
━━━━━━━━━━━━━━━━━━

🔴 <b>Status:</b> Sedang Build
📊 <b>Slot:</b> ${queueInfo.processing}/${queueInfo.maxConcurrent}
⏱️ <b>Build pertama:</b> ${minutes}m ${seconds}s
⏳ <b>Antrian:</b> ${queueInfo.waiting} menunggu

💡 <i>Build baru akan masuk antrian otomatis.</i>
        `.trim();
    } else {
        statusMessage = `
📊 <b>Status Server</b>
━━━━━━━━━━━━━━━━━━

🟢 <b>Status:</b> Tersedia
📊 <b>Slot:</b> ${queueInfo.processing}/${queueInfo.maxConcurrent}
✅ <b>Antrian:</b> Kosong

<b>📈 Statistik:</b>
✅ ${stats.success} berhasil | ❌ ${stats.failed} gagal

💡 <i>Server siap menerima build baru!</i>
        `.trim();
    }

    await bot.deleteMessage(chatId, messageId).catch(() => { });

    await bot.sendMessage(chatId, statusMessage, {
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [{ text: '🔄 Refresh', callback_data: 'server_status', style: "primary" }],
                [{ text: '◀️ Kembali ke Menu', callback_data: 'back_main', style: "danger" }]
            ]
        }
    });
}

async function showQueueStatus(bot, chatId, messageId) {
    const queueInfo = buildManager.getQueueInfo();
    const stats = buildManager.getStats();
    const userPosition = buildManager.getUserPosition(chatId);
    const isActive = buildManager.hasActiveBuild(chatId);
    const activeBuilds = buildManager.getActiveBuilds();
    const queueList = buildManager.getQueueList();
    const session = global.sessions.get(chatId);

    let statusIcon = '🟢';
    let statusText = 'Siap';
    if (queueInfo.processing >= queueInfo.maxConcurrent) {
        statusIcon = '🔴';
        statusText = 'Penuh';
    } else if (queueInfo.processing > 0) {
        statusIcon = '🟡';
        statusText = 'Aktif';
    }

    let queueMessage = `📋 <b>Status Antrian Build</b>\n━━━━━━━━━━━━━━━━━━\n\n`;
    queueMessage += `${statusIcon} <b>Server:</b> ${statusText}\n`;
    queueMessage += `📊 <b>Slot:</b> ${queueInfo.processing}/${queueInfo.maxConcurrent}\n`;

    if (activeBuilds.length > 0) {
        queueMessage += `\n<b>🔨 Sedang Berjalan:</b>\n`;
        for (const build of activeBuilds) {
            const mins = Math.floor(build.duration / 60);
            const secs = build.duration % 60;
            const isMe = build.chatId === chatId;
            let activePriorityEmoji = '';
            if (build.isOwner) activePriorityEmoji = '👑 ';
            else if (build.priorityLevel === 1) activePriorityEmoji = '⭐ ';
            queueMessage += `${isMe ? '👉 ' : '• '}${activePriorityEmoji}<b>${escapeHtml(build.userName)}</b> - ${escapeHtml(build.projectName)} (${mins}m ${secs}s)${isMe ? ' ← Anda' : ''}\n`;
        }
    }

    if (queueList.length > 0) {
        queueMessage += `\n<b>⏳ Antrian (${queueList.length}):</b>\n`;
        for (const item of queueList.slice(0, 8)) {
            const isMe = item.chatId === chatId;
            let userPriorityEmoji = '';
            if (item.priorityLevel === 2) userPriorityEmoji = '👑 ';
            else if (item.priorityLevel === 1) userPriorityEmoji = '⭐ ';
            queueMessage += `${item.position}. ${userPriorityEmoji}<b>${escapeHtml(item.userName)}</b> - ${escapeHtml(item.projectName)}${isMe ? ' ← Anda' : ''}\n`;
        }
        if (queueList.length > 8) {
            queueMessage += `<i>...dan ${queueList.length - 8} lainnya</i>\n`;
        }
    }

    queueMessage += `\n<b>📈 Statistik:</b>\n`;
    queueMessage += `✅ ${stats.success} berhasil | ❌ ${stats.failed} gagal | ⏱ ~${stats.avgTime}s\n`;

    if (isActive) {
        const myBuild = activeBuilds.find(b => b.chatId === chatId);
        if (myBuild) {
            queueMessage += `\n🔄 <b>Build Anda sedang berjalan!</b>`;
        }
    } else if (userPosition > 0) {
        const estimatedWait = buildManager.getEstimatedWait(userPosition);
        queueMessage += `\n🎫 <b>Anda di posisi #${userPosition}</b> (~${estimatedWait} menit)`;
        queueMessage += `\n✅ <i>Build otomatis dimulai saat giliran tiba!</i>`;
    } else if (session && session.step) {
        queueMessage += `\n📝 <b>Anda sedang:</b> ${getStepDescription(session.step)}`;
    } else {
        queueMessage += `\n💡 <i>Klik menu untuk mulai build!</i>`;
    }

    let replyMarkup;
    if (isActive) {
        replyMarkup = {
            inline_keyboard: [
                [{ text: '🔄 Refresh', callback_data: 'check_queue', style: "primary" }]
            ]
        };
    } else if (userPosition > 0) {
        replyMarkup = {
            inline_keyboard: [
                [{ text: '🔄 Refresh', callback_data: 'check_queue', style: "primary" }],
                [{ text: '❌ Batalkan Antrian', callback_data: 'cancel_queue', style: "danger" }]
            ]
        };
    } else {
        replyMarkup = {
            inline_keyboard: [
                [{ text: '🔄 Refresh', callback_data: 'check_queue', style: "primary" }],
                [{ text: '◀️ Kembali ke Menu', callback_data: 'back_main', style: "danger" }]
            ]
        };
    }

    await bot.deleteMessage(chatId, messageId).catch(() => { });

    await bot.sendMessage(chatId, queueMessage, {
        parse_mode: 'HTML',
        reply_markup: replyMarkup
    });
}

async function cancelQueuedBuild(bot, chatId, messageId) {
    const session = global.sessions.get(chatId);

    buildManager.removeFromQueue(chatId);

    if (session?.data?.iconPath) {
        await fs.remove(session.data.iconPath).catch(() => { });
    }

    global.sessions.delete(chatId);

    await bot.deleteMessage(chatId, messageId).catch(() => { });

    await bot.sendMessage(chatId, `
✅ <b>Antrian Dibatalkan</b>
━━━━━━━━━━━━━━━━━━

Build Anda telah dihapus dari antrian.

💡 <i>Klik tombol di bawah untuk memulai build baru.</i>
    `.trim(), {
        parse_mode: 'HTML',
        reply_markup: getMainKeyboard()
    });
}

function getStepDescription(step) {
    const descriptions = {
        'url': 'Input URL',
        'app_name': 'Input nama aplikasi',
        'icon': 'Upload icon',
        'confirm': 'Konfirmasi build',
        'zip_upload': 'Upload file ZIP',
        'zip_type': 'Pilih tipe project',
        'analyze_upload': 'Upload untuk Analyze',
        'cleanup_upload': 'Upload untuk Cleanup'
    };
    return descriptions[step] || step;
}

async function showCommandsMenu(bot, chatId, messageId, userInfo) {
    const adminIds = process.env.ADMIN_IDS?.split(',').map(id => id.trim()) || [];
    const isOwner = adminIds.includes(String(userInfo.id));
    const isResellerUser = resellerService.isReseller(userInfo.id);
    const isLicensed = licenseKeyService.isUserAuthorized(userInfo.id);

    let menuMessage = `
📜 <b>DAFTAR PERINTAH</b>
━━━━━━━━━━━━━━━━━━
`;

    if (isOwner) {
        menuMessage += `
👑 <b>OWNER COMMANDS</b>
━━━━━━━━━━━━━━━━━━

<b>👥 Reseller Management:</b>
/addreseller - Tambah Reseller
/delreseller - Hapus Reseller
/listreseller - Daftar Reseller

<b>📊 Admin Commands:</b>
/stats - Statistik bot
/broadcast - Broadcast pesan
/listkey - Daftar license keys
/addkey - Tambah license key
/delkey - Hapus license key
/extendkey - Perpanjang license
/maintenance - Mode Maintenance

<b>🔧 Project Tools:</b>
/analyze flutter - Analyze Flutter project
/analyze android - Analyze Android project
/cleanup flutter - Cleanup Flutter project
/cleanup android - Cleanup Android project

<b>📋 General:</b>
/start - Mulai bot
/help - Bantuan
`;
    } else if (isResellerUser) {
        menuMessage += `
⭐ <b>RESELLER COMMANDS</b>
━━━━━━━━━━━━━━━━━━

<b>🔑 License Management:</b>
/addkey - Buat License Baru
/extendkey - Perpanjang License

<b>🔧 Project Tools (Free):</b>
/analyze flutter - Analyze Flutter project
/analyze android - Analyze Android project
/cleanup flutter - Cleanup Flutter project
/cleanup android - Cleanup Android project

<b>📋 General:</b>
/start - Mulai bot
/help - Bantuan
`;
    } else if (isLicensed) {
        menuMessage += `
🎫 <b>MEMBER COMMANDS</b>
━━━━━━━━━━━━━━━━━━

<b>🔧 Project Tools:</b>
/analyze flutter - Analyze Flutter project
/analyze android - Analyze Android project
/cleanup flutter - Cleanup Flutter project
/cleanup android - Cleanup Android project

<b>📋 General:</b>
/start - Mulai bot
/help - Bantuan

💡 <i>Upload file ZIP setelah mengirim command</i>
`;
    } else {
        menuMessage += `
👤 <b>USER COMMANDS</b>
━━━━━━━━━━━━━━━━━━

<b>📋 General:</b>
/start - Mulai bot
/help - Bantuan

⚠️ <i>Dapatkan license untuk akses tools!</i>
`;
    }

    await bot.deleteMessage(chatId, messageId).catch(() => { });

    await bot.sendMessage(chatId, menuMessage.trim(), {
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [{ text: '◀️ Kembali ke Menu', callback_data: 'back_main', style: "danger" }]
            ]
        }
    });
}

async function showThanksTo(bot, chatId, messageId) {
    const thanksMessage = `
🙏 <b>Thanks You To (TQTO)</b>
━━━━━━━━━━━━━━━━━━

Terima kasih kepada:

👤 <b>Pengguna setia Web2APK</b>
   Kalian yang selalu support kami!

👥 <b>Member komunitas</b>
   Terus berkembang bersama!

⭐ <b>Special thanks to:</b>
   @AanzCuyxzzz
   <i>Sebagai support development</i>

━━━━━━━━━━━━━━━━━━
💙 <i>Terima kasih sudah menggunakan Web2APK!</i>
    `.trim();

    await bot.deleteMessage(chatId, messageId).catch(() => { });

    await bot.sendMessage(chatId, thanksMessage, {
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: [
                [{ text: '◀️ Kembali ke Menu', callback_data: 'back_main', style: "danger" }]
            ]
        }
    });
}

async function backToMain(bot, chatId, messageId) {
    global.sessions.delete(chatId);

    await bot.deleteMessage(chatId, messageId).catch(() => { });

    const welcomeCaption = `
👋 <b>Selamat Datang !</b>

🤖 <b>Web2Apk Pro Bot Gen 4 ( Beta )</b> adalah solusi instant mengubah website menjadi aplikasi Android.

✨ <i>Fitur Premium:</i>
• Tanpa Iklan
• Proses Cepat
• Custom Icon Support

👇 <b>Mulai project Anda sekarang:</b>
    `.trim();

    await bot.sendPhoto(chatId, 'https://cdn.phototourl.com/free/2026-07-14-e0899d92-7155-4fa7-8ec8-1ce6b3db23b7.png', {
        caption: welcomeCaption,
        parse_mode: 'HTML',
        reply_markup: getMainKeyboard()
    }).catch(async () => {
        await bot.sendMessage(chatId, welcomeCaption, {
            parse_mode: 'HTML',
            reply_markup: getMainKeyboard()
        });
    });
}

async function cancelProcess(bot, chatId, messageId) {
    const session = global.sessions.get(chatId);

    if (session?.data?.iconPath) {
        await fs.remove(session.data.iconPath).catch(() => { });
    }

    global.sessions.delete(chatId);

    await bot.editMessageText('❌ Proses dibatalkan.\n\nKlik tombol di bawah untuk memulai lagi.', {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: getMainKeyboard()
    });
}

async function skipIcon(bot, chatId, messageId) {
    const session = global.sessions.get(chatId);
    if (!session) return;

    session.step = 'confirm';
    global.sessions.set(chatId, session);

    const message = `
📱 *Konfirmasi Pembuatan APK*

*Detail Aplikasi:*
🌐 URL: ${session.data.url}
📝 Nama: ${session.data.appName}
🖼️ Icon: Default

Klik "✅ Buat APK" untuk memulai proses build.
    `.trim();

    await bot.editMessageText(message, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'Markdown',
        reply_markup: getConfirmKeyboard()
    });
}

async function confirmBuild(bot, chatId, messageId) {
    const session = global.sessions.get(chatId);
    if (!session) return;

    const userName = session.userName || session.userUsername || 'User';

    const buildData = {
        ...session.data,
        userName: userName,
        userUsername: session.userUsername,
        userId: chatId,
        messageId: messageId
    };

    const priorityLevel = getUserPriorityLevel(chatId);
    const isOwner = priorityLevel === 2;

    const existingBuild = buildManager.isUserBuilding(chatId);
    if (existingBuild) {
        return bot.editMessageText(`
⚠️ <b>ANDA SEDANG BUILD!</b>
━━━━━━━━━━━━━━━━━━

🔄 <b>Build ID:</b> <code>${existingBuild.buildId}</code>
📱 <b>Project:</b> ${escapeHtml(existingBuild.projectName)}
⏱️ <b>Berjalan:</b> ${Math.floor(existingBuild.duration/60)}m ${existingBuild.duration%60}s

💡 <i>Tunggu build selesai sebelum memulai yang baru.</i>
        `.trim(), {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: getMainKeyboard()
        });
        return;
    }

    if (isOwner) {
        await startOwnerBuild(bot, chatId, messageId, session, buildData, userName);
        return;
    }

    const queueResult = buildManager.addToQueue(chatId, buildData, 'url', userName, priorityLevel);

    if (queueResult.queued) {
        const queueInfo = buildManager.getQueueInfo();
        const queueList = buildManager.getQueueList();
        const activeBuilds = buildManager.getActiveBuilds();

        let queueMessage = `📋 <b>Build Masuk Antrian</b>\n━━━━━━━━━━━━━━━━━━\n\n`;

        if (queueResult.isPriority) {
            queueMessage += `⭐ <b>PRIORITAS RESELLER!</b> (Antrian didahulukan)\n\n`;
        }

        queueMessage += `🎫 <b>Posisi Anda:</b> #${queueResult.position}\n`;
        queueMessage += `⏱ <b>Estimasi:</b> ~${queueResult.estimatedWait} menit\n`;
        queueMessage += `📊 <b>Build Aktif:</b> ${queueInfo.processing}/${queueInfo.maxConcurrent}\n`;

        if (queueInfo.ownerActive > 0) {
            queueMessage += `👑 <b>Owner Build:</b> ${queueInfo.ownerActive} aktif\n`;
        }
        queueMessage += `\n`;

        if (activeBuilds.length > 0) {
            queueMessage += `<b>🔨 Sedang Berjalan:</b>\n`;
            for (const build of activeBuilds) {
                const mins = Math.floor(build.duration / 60);
                const secs = build.duration % 60;
                let emoji = '';
                if (build.isOwner) emoji = '👑 ';
                else if (build.priorityLevel === 1) emoji = '⭐ ';
                queueMessage += `• ${emoji}${escapeHtml(build.userName)} - ${escapeHtml(build.projectName)} (${mins}m ${secs}s)\n`;
            }
            queueMessage += `\n`;
        }

        const aheadOfMe = queueList.filter(q => q.position < queueResult.position);
        if (aheadOfMe.length > 0) {
            queueMessage += `<b>⏳ Di Depan Anda (${aheadOfMe.length}):</b>\n`;
            for (const item of aheadOfMe.slice(0, 5)) {
                let emoji = '';
                if (item.priorityLevel === 2) emoji = '👑 ';
                else if (item.priorityLevel === 1) emoji = '⭐ ';
                queueMessage += `${item.position}. ${emoji}${escapeHtml(item.userName)}\n`;
            }
            if (aheadOfMe.length > 5) {
                queueMessage += `<i>...${aheadOfMe.length - 5} lainnya</i>\n`;
            }
            queueMessage += `\n`;
        }

        queueMessage += `<b>📝 Aplikasi Anda:</b>\n`;
        queueMessage += `📱 ${escapeHtml(session.data.appName)}\n`;
        queueMessage += `🌐 <code>${session.data.url}</code>\n\n`;
        queueMessage += `✅ <i>Build otomatis dimulai saat giliran tiba!</i>`;

        await bot.editMessageText(queueMessage, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔄 Cek Status Antrian', callback_data: 'check_queue', style: "primary" }],
                    [{ text: '❌ Batalkan Antrian', callback_data: 'cancel_queue', style: "danger" }]
                ]
            }
        });

        return;
    }
}

async function startOwnerBuild(bot, chatId, messageId, session, buildData, userName) {
    const buildInfo = await buildManager.startBuild(chatId, buildData, 'url', userName);
    
    await sendBuildNotification(bot, 'start', {
        appName: session.data.appName,
        userName: userName,
        userId: chatId,
        buildId: buildInfo.buildId,
        isOwner: true
    });

    let currentProgress = 0;
    let buildResult = null;
    let buildSuccess = false;
    const startTime = Date.now();

    await bot.editMessageText(formatBuildStartMessage(escapeHtml(session.data.appName), session.data.url), {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: 'HTML'
    });

    try {
        buildResult = await buildApk(session.data, (status) => {
            buildManager.updateActivity(buildInfo.buildId);

            if (status.includes('Preparing')) currentProgress = 10;
            else if (status.includes('Generating')) currentProgress = 25;
            else if (status.includes('Copying')) currentProgress = 40;
            else if (status.includes('Configuring')) currentProgress = 55;
            else if (status.includes('Building') || status.includes('Gradle')) currentProgress = 70;
            else if (status.includes('Packaging')) currentProgress = 85;
            else if (status.includes('Complete') || status.includes('Success')) currentProgress = 100;
            else currentProgress = Math.min(currentProgress + 5, 95);

            bot.editMessageText(formatBuildProgress(currentProgress, status, escapeHtml(session.data.appName)), {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML'
            }).catch(() => { });
        });

        const duration = Math.round((Date.now() - startTime) / 1000);
        const durationStr = duration > 60 ? `${Math.floor(duration/60)}m ${duration%60}s` : `${duration}s`;

        if (buildResult.success) {
            const apkStats = await fs.stat(buildResult.apkPath);
            const fileSizeMB = (apkStats.size / (1024 * 1024)).toFixed(2);

            await sendBuildNotification(bot, 'success', {
                appName: session.data.appName,
                userName: userName,
                userId: chatId,
                size: `${fileSizeMB} MB`,
                duration: durationStr,
                buildId: buildInfo.buildId,
                isOwner: true
            });

            await bot.editMessageText(formatSuccessMessage(escapeHtml(session.data.appName), session.data.url), {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML'
            });

            await bot.sendDocument(chatId, buildResult.apkPath, {
                caption: `✅ <b>${escapeHtml(session.data.appName)}</b>\n\n🌐 <code>${session.data.url}</code>\n🆔 <code>${buildInfo.buildId}</code>\n👑 <i>Owner Build</i>\n\n<i>Generated by Web2APK Bot</i>`,
                parse_mode: 'HTML'
            });

            await bot.sendMessage(chatId, '🎉 APK berhasil dikirim!\n\nIngin membuat APK lagi?', {
                reply_markup: getMainKeyboard()
            });

            sendBuildReport(bot, {
                id: chatId,
                name: session.userName || 'Unknown',
                username: session.userUsername || null
            }, session.data);

            buildSuccess = true;

        } else {
            throw new Error(buildResult.error);
        }

    } catch (error) {
        console.error('Build error:', error);
        
        const duration = Math.round((Date.now() - startTime) / 1000);
        const durationStr = duration > 60 ? `${Math.floor(duration/60)}m ${duration%60}s` : `${duration}s`;

        await sendBuildNotification(bot, 'failed', {
            appName: session.data.appName,
            userName: userName,
            userId: chatId,
            duration: durationStr,
            error: error.message,
            buildId: buildInfo.buildId,
            isOwner: true
        });

        const errorSent = await sendErrorLog(bot, chatId, error, 'apk_build', {
            appName: session.data.appName,
            url: session.data.url,
            userId: chatId,
            userName: userName,
            buildId: buildInfo.buildId
        });

        if (errorSent) {
            await bot.editMessageText(`
❌ <b>Build Gagal!</b>
━━━━━━━━━━━━━━━━━━
🆔 <code>${buildInfo.buildId}</code>
👑 <i>Owner Build</i>

📄 <i>File error log telah dikirim di atas.</i>

💡 <i>Periksa project Anda dan coba lagi.</i>
            `.trim(), {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: getMainKeyboard()
            });
        } else {
            await bot.editMessageText(formatErrorMessage(error.message), {
                chat_id: chatId,
                message_id: messageId,
                parse_mode: 'HTML',
                reply_markup: getMainKeyboard()
            });
        }

        const logSent = await sendVpsErrorLog(bot, chatId, 'apk_build');
        
        if (!logSent) {
            await bot.sendMessage(chatId, `
⚠️ <b>Tidak ada error log ditemukan</b>
━━━━━━━━━━━━━━━━━━

Pastikan file .log.error ada di:
<code>/root/webapp/logs/*.log.error</code>
            `.trim(), {
                parse_mode: 'HTML'
            });
        }
    } finally {
        if (buildResult?.apkPath) {
            await fs.remove(buildResult.apkPath).catch(() => { });
            console.log(`🗑️ Cleaned APK: ${buildResult.apkPath}`);
        }

        if (buildResult?.buildDir) {
            await fs.remove(buildResult.buildDir).catch(() => { });
            console.log(`🗑️ Cleaned temp dir: ${buildResult.buildDir}`);
        }

        if (buildInfo?.buildDir) {
            await fs.remove(buildInfo.buildDir).catch(() => { });
            console.log(`🗑️ Cleaned build dir: ${buildInfo.buildDir}`);
        }

        if (session?.data?.iconPath) {
            await fs.remove(session.data.iconPath).catch(() => { });
        }

        buildManager.release(buildInfo.buildId, buildSuccess);
        global.sessions.delete(chatId);
    }
}

async function startBuildZip(bot, chatId, messageId) {
    const ownerManager = require('../utils/ownerManager');
    const licenseKeyService = require('../utils/licenseKeyService');
    const resellerService = require('../utils/resellerService');

    const isOwner = ownerManager.isOwner(chatId);
    const isResellerUser = resellerService.isReseller(chatId);
    const hasLicense = licenseKeyService.isUserAuthorized(chatId);

    console.log(`[BuildZIP] User ${chatId}: isOwner=${isOwner}, isReseller=${isResellerUser}, hasLicense=${hasLicense}`);

    if (!isOwner && !isResellerUser && !hasLicense) {
        await bot.deleteMessage(chatId, messageId).catch(() => {});
        await bot.sendMessage(chatId, `
🔒 <b>Fitur Khusus Member</b>
━━━━━━━━━━━━━━━━━━
Silahkan Beli Akses Bot Menggunakan Button di bawah
💡 Hubungi @AanzCuyxzzz Jika terjadi eror.
        `.trim(), {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🛒 Beli Akses', callback_data: 'buy_access' }],
                    [{ text: '◀️ Kembali ke Menu', callback_data: 'back_main' }]
                ]
            }
        });
        return;
    }

    await bot.deleteMessage(chatId, messageId).catch(() => { });

    const message = `
📦 <b>Build APK dari Project ZIP</b>
━━━━━━━━━━━━━━━━━━

Pilih jenis project yang akan di-build:

<b>🤖 Android Studio</b>
Project dengan <code>build.gradle</code>

<b>💙 Flutter</b>
Project dengan <code>pubspec.yaml</code>
    `.trim();

    await bot.sendMessage(chatId, message, {
        parse_mode: 'HTML',
        reply_markup: getZipTypeKeyboard()
    });
}

async function selectZipType(bot, chatId, messageId, projectType, userInfo = {}) {
    const fullName = [userInfo.firstName, userInfo.lastName].filter(Boolean).join(' ').trim() || 'User';

    const licenseUsername = licenseKeyService.getUsernameByTelegramId(chatId);

    let displayName = fullName;
    if (userInfo.username) {
        displayName += ` (@${userInfo.username})`;
    }
    if (licenseUsername) {
        displayName += ` [${licenseUsername}]`;
    }

    global.sessions.set(chatId, {
        step: 'zip_buildtype',
        userName: displayName,
        userUsername: userInfo.username || null,
        licenseUsername: licenseUsername,
        data: {
            projectType: projectType,
            buildType: null,
            zipPath: null
        }
    });

    await bot.deleteMessage(chatId, messageId).catch(() => { });

    const typeName = projectType === 'flutter' ? 'Flutter' : 'Android Studio';
    const message = `
📦 <b>Project: ${typeName}</b>
━━━━━━━━━━━━━━━━━━

Pilih tipe build:

<b>🐛 Debug</b> - Build cepat untuk testing
<b>🚀 Release</b> - Build untuk produksi
    `.trim();

    await bot.sendMessage(chatId, message, {
        parse_mode: 'HTML',
        reply_markup: getZipBuildTypeKeyboard()
    });
}

async function selectZipBuildType(bot, chatId, messageId, buildType, userInfo = {}) {
    const session = global.sessions.get(chatId);
    if (!session) return;

    if (!session.userName && userInfo.firstName) {
        session.userName = [userInfo.firstName, userInfo.lastName].filter(Boolean).join(' ').trim();
        session.userUsername = userInfo.username || null;
    }

    session.data.buildType = buildType;
    session.step = 'zip_upload';
    global.sessions.set(chatId, session);

    await bot.deleteMessage(chatId, messageId).catch(() => { });

    const typeName = session.data.projectType === 'flutter' ? 'Flutter' : 'Android';
    const message = `
📤 <b>Upload Project ZIP</b>
━━━━━━━━━━━━━━━━━━

<b>Project:</b> ${typeName}
<b>Build:</b> ${buildType === 'release' ? '🚀 Release' : '🐛 Debug'}

Silakan kirim file <b>.zip</b> project Anda.

<i>⚠️ Pastikan project sudah bisa di-build sebelumnya.</i>
    `.trim();

    await bot.sendMessage(chatId, message, {
        parse_mode: 'HTML',
        reply_markup: getCancelKeyboard()
    });
}

async function handleZipUpload(bot, chatId, filePath) {
    const session = global.sessions.get(chatId);
    if (!session || session.step !== 'zip_upload') return false;

    const { projectType, buildType } = session.data;
    const userName = session.userName || session.userUsername || 'User';
    const priorityLevel = getUserPriorityLevel(chatId);
    const isOwner = priorityLevel === 2;

    const existingBuild = buildManager.isUserBuilding(chatId);
    if (existingBuild) {
        await bot.sendMessage(chatId, `
⚠️ <b>ANDA SEDANG BUILD!</b>
━━━━━━━━━━━━━━━━━━

🔄 <b>Build ID:</b> <code>${existingBuild.buildId}</code>
📱 <b>Project:</b> ${escapeHtml(existingBuild.projectName)}
⏱️ <b>Berjalan:</b> ${Math.floor(existingBuild.duration/60)}m ${existingBuild.duration%60}s

💡 <i>Tunggu build selesai sebelum memulai yang baru.</i>
        `.trim(), { parse_mode: 'HTML' });
        await fs.remove(filePath).catch(() => {});
        return false;
    }

    const buildData = {
        projectType,
        buildType,
        filePath,
        appName: `${projectType}-${buildType}`,
        userName,
        userId: chatId
    };

    if (isOwner) {
        await startOwnerZipBuild(bot, chatId, session, buildData, userName, projectType, buildType, filePath);
        return true;
    }

    const queueResult = buildManager.addToQueue(chatId, buildData, 'zip', userName, priorityLevel);

    if (queueResult.queued) {
        const queueList = buildManager.getQueueList();
        const activeBuilds = buildManager.getActiveBuilds();

        let queueMessage = `📋 <b>Build ZIP Masuk Antrian</b>\n━━━━━━━━━━━━━━━━━━\n\n`;

        if (queueResult.isPriority) {
            queueMessage += `⭐ <b>PRIORITAS RESELLER!</b> (Antrian didahulukan)\n\n`;
        }

        queueMessage += `🎫 <b>Posisi Anda:</b> #${queueResult.position}\n`;
        queueMessage += `⏱ <b>Estimasi:</b> ~${queueResult.estimatedWait} menit\n\n`;

        queueMessage += `<b>📦 Project:</b> ${projectType === 'flutter' ? 'Flutter' : 'Android'}\n`;
        queueMessage += `<b>🏷️ Build:</b> ${buildType === 'release' ? '🚀 Release' : '🐛 Debug'}\n\n`;
        queueMessage += `✅ <i>Build otomatis dimulai saat giliran tiba!</i>`;

        await bot.sendMessage(chatId, queueMessage, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '🔄 Cek Status Antrian', callback_data: 'check_queue', style: "primary" }],
                    [{ text: '❌ Batalkan Antrian', callback_data: 'cancel_queue', style: "danger" }]
                ]
            }
        });

        session.data.filePath = filePath;
        global.sessions.set(chatId, session);
        return true;
    }
}

async function startOwnerZipBuild(bot, chatId, session, buildData, userName, projectType, buildType, filePath) {
    const buildInfo = await buildManager.startBuild(chatId, buildData, 'zip', userName);

    await sendBuildNotification(bot, 'start', {
        appName: `${projectType}-${buildType}`,
        userName: userName,
        userId: chatId,
        buildId: buildInfo.buildId,
        isOwner: true
    });

    let currentProgress = 0;
    let zipBuildSuccess = false;
    const startTime = Date.now();

    const statusMsg = await bot.sendMessage(chatId,
        formatZipBuildProgress(0, 'Memulai proses build...', projectType, buildType),
        { parse_mode: 'HTML' }
    );

    try {
        const result = await buildFromZip(
            filePath,
            projectType,
            buildType,
            (status) => {
                buildManager.updateActivity(buildInfo.buildId);

                if (status.includes('Extracting')) currentProgress = 10;
                else if (status.includes('Cleaning')) currentProgress = 20;
                else if (status.includes('dependencies') || status.includes('Getting')) currentProgress = 35;
                else if (status.includes('Building') || status.includes('Gradle')) currentProgress = 60;
                else if (status.includes('Locating') || status.includes('APK')) currentProgress = 90;
                else currentProgress = Math.min(currentProgress + 5, 95);

                bot.editMessageText(
                    formatZipBuildProgress(currentProgress, status, projectType, buildType), {
                    chat_id: chatId,
                    message_id: statusMsg.message_id,
                    parse_mode: 'HTML'
                }).catch(() => { });
            }
        );

        const duration = Math.round((Date.now() - startTime) / 1000);
        const durationStr = duration > 60 ? `${Math.floor(duration/60)}m ${duration%60}s` : `${duration}s`;

        if (result.success) {
            const typeName = projectType === 'flutter' ? 'Flutter' : 'Android';
            const buildName = buildType === 'release' ? 'Release' : 'Debug';

            const MAX_FILE_SIZE = process.env.LOCAL_API_URL
                ? 2 * 1024 * 1024 * 1024
                : 50 * 1024 * 1024;
            const apkStats = await fs.stat(result.apkPath);
            const fileSizeMB = (apkStats.size / (1024 * 1024)).toFixed(2);

            await sendBuildNotification(bot, 'success', {
                appName: `${typeName}-${buildName}`,
                userName: userName,
                userId: chatId,
                size: `${fileSizeMB} MB`,
                duration: durationStr,
                buildId: buildInfo.buildId,
                isOwner: true
            });

            if (apkStats.size > MAX_FILE_SIZE) {
                const WEB_URL = process.env.WEB_URL || `http://localhost:${process.env.WEB_PORT || 3000}`;
                const buildId = `tg-zip-${Date.now()}`;

                const { registerBuildForDownload } = require('../server');
                registerBuildForDownload(buildId, result.apkPath, result.buildDir, `${typeName}_${buildName}.apk`, 5 * 60 * 1000);

                const downloadUrl = `${WEB_URL}/api/download/${buildId}`;

                await bot.editMessageText(`
✅ <b>Build Berhasil!</b>
━━━━━━━━━━━━━━━━━━

📱 <b>Type:</b> ${typeName}
🏷️ <b>Build:</b> ${buildName}
📦 <b>Ukuran:</b> ${fileSizeMB} MB
🆔 <code>${buildInfo.buildId}</code>
👑 <i>Owner Build</i>

⚠️ <b>File terlalu besar untuk Telegram (>50MB)</b>

🔗 <b>Download via Link:</b>
<code>${downloadUrl}</code>

⏰ <i>Link berlaku 5 menit</i>
                `.trim(), {
                    chat_id: chatId,
                    message_id: statusMsg.message_id,
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📥 Download APK', url: downloadUrl, style: "primary" }],
                            [{ text: '◀️ Kembali ke Menu', callback_data: 'back_main', style: "danger" }]
                        ]
                    }
                });

                return true;
            }

            await bot.editMessageText(`
✅ <b>Build Berhasil!</b>
━━━━━━━━━━━━━━━━━━

📱 <b>Type:</b> ${typeName}
🏷️ <b>Build:</b> ${buildName}
📦 <b>Ukuran:</b> ${fileSizeMB} MB
🆔 <code>${buildInfo.buildId}</code>
👑 <i>Owner Build</i>

🎉 <i>Mengirim file APK...</i>
            `.trim(), {
                chat_id: chatId,
                message_id: statusMsg.message_id,
                parse_mode: 'HTML'
            });

            await bot.sendDocument(chatId, result.apkPath, {
                caption: `✅ <b>APK Build Success</b>\n\n📱 <b>Type:</b> ${typeName}\n🏷️ <b>Build:</b> ${buildName}\n📦 <b>Size:</b> ${fileSizeMB} MB\n🆔 <code>${buildInfo.buildId}</code>\n👑 <i>Owner Build</i>\n\n<i>Generated by Web2APK Bot</i>`,
                parse_mode: 'HTML'
            });

            await fs.remove(result.apkPath).catch(() => { });
            await fs.remove(result.buildDir).catch(() => { });

            await bot.sendMessage(chatId, '🎉 APK berhasil di-build!\n\nIngin build lagi?', {
                reply_markup: getMainKeyboard()
            });

            zipBuildSuccess = true;
        } else {
            throw new Error(result.error);
        }

    } catch (error) {
        console.error('ZIP Build error:', error);
        
        const duration = Math.round((Date.now() - startTime) / 1000);
        const durationStr = duration > 60 ? `${Math.floor(duration/60)}m ${duration%60}s` : `${duration}s`;

        const typeName = projectType === 'flutter' ? 'Flutter' : 'Android';
        const buildName = buildType === 'release' ? 'Release' : 'Debug';

        await sendBuildNotification(bot, 'failed', {
            appName: `${typeName}-${buildName}`,
            userName: userName,
            userId: chatId,
            duration: durationStr,
            error: error.message,
            buildId: buildInfo.buildId,
            isOwner: true
        });

        const errorSent = await sendErrorLog(bot, chatId, error, 'zip_build', {
            projectType: projectType,
            buildType: buildType,
            userId: chatId,
            userName: userName,
            buildId: buildInfo.buildId
        });

        if (errorSent) {
            await bot.editMessageText(`
❌ <b>Build Gagal!</b>
━━━━━━━━━━━━━━━━━━
🆔 <code>${buildInfo.buildId}</code>
👑 <i>Owner Build</i>

📄 <i>File error log telah dikirim di atas.</i>

💡 <i>Periksa project Anda dan coba lagi.</i>
            `.trim(), {
                chat_id: chatId,
                message_id: statusMsg.message_id,
                parse_mode: 'HTML',
                reply_markup: getMainKeyboard()
            });
        } else {
            await bot.editMessageText(formatErrorMessage(error.message), {
                chat_id: chatId,
                message_id: statusMsg.message_id,
                parse_mode: 'HTML',
                reply_markup: getMainKeyboard()
            });
        }
        
        const logSent = await sendVpsErrorLog(bot, chatId, 'zip_build');
        
        if (!logSent) {
            await bot.sendMessage(chatId, `
⚠️ <b>Tidak ada error log ditemukan</b>
━━━━━━━━━━━━━━━━━━

Pastikan file .log.error ada di:
<code>/root/webapp/logs/*.log.error</code>
            `.trim(), {
                parse_mode: 'HTML'
            });
        }
    } finally {
        if (filePath) {
            await fs.remove(filePath).catch(() => { });
        }
        if (buildInfo?.buildDir) {
            await fs.remove(buildInfo.buildDir).catch(() => { });
        }
        if (session?.data?.iconPath) {
            await fs.remove(session.data.iconPath).catch(() => { });
        }

        buildManager.release(buildInfo.buildId, zipBuildSuccess);
        global.sessions.delete(chatId);
    }
}

function initQueueCallback(bot) {
    buildManager.onBuildStart = async (chatId, buildData, type, userName) => {
        console.log(`[Queue Callback] 🚀 Auto-starting ${type} build for ${userName} (${chatId})`);

        try {
            await bot.sendMessage(chatId, `
🚀 <b>Giliran ${escapeHtml(userName) || 'Anda'} Tiba!</b>
━━━━━━━━━━━━━━━━━━

🎉 Antrian Anda telah tiba!
🔄 Memulai proses build...

📝 <b>Nama:</b> ${escapeHtml(buildData.appName) || 'Project'}
            `.trim(), { parse_mode: 'HTML' });

            if (type === 'url') {
                let session = global.sessions.get(chatId);
                if (!session) {
                    session = {
                        step: 'building',
                        data: buildData,
                        userName: buildData.userName,
                        userUsername: buildData.userUsername
                    };
                    global.sessions.set(chatId, session);
                }

                const startTime = Date.now();
                buildData.userId = chatId;

                await sendBuildNotification(bot, 'start', {
                    appName: buildData.appName,
                    userName: userName,
                    userId: chatId
                });

                const result = await buildApk(buildData, (status) => {
                    buildManager.updateActivity(chatId);
                });

                const duration = Math.round((Date.now() - startTime) / 1000);
                const durationStr = duration > 60 ? `${Math.floor(duration/60)}m ${duration%60}s` : `${duration}s`;

                if (result.success) {
                    const apkSizeMB = (await fs.stat(result.apkPath)).size / 1024 / 1024;

                    await sendBuildNotification(bot, 'success', {
                        appName: buildData.appName,
                        userName: userName,
                        userId: chatId,
                        size: `${apkSizeMB.toFixed(2)} MB`,
                        duration: durationStr
                    });

                    await bot.sendMessage(chatId, formatSuccessMessage(escapeHtml(buildData.appName), apkSizeMB.toFixed(1)), {
                        parse_mode: 'HTML'
                    });

                    await bot.sendDocument(chatId, result.apkPath, {
                        caption: `✅ <b>${escapeHtml(buildData.appName)}</b>\n\n🌐 <code>${buildData.url}</code>\n\n<i>Generated by Web2APK Bot</i>`,
                        parse_mode: 'HTML'
                    });

                    await bot.sendMessage(chatId, '🎉 APK berhasil dikirim!\n\nIngin membuat APK lagi?', {
                        reply_markup: getMainKeyboard()
                    });

                    sendBuildReport(bot, {
                        id: chatId,
                        name: buildData.userName || 'Unknown',
                        username: buildData.userUsername || null
                    }, buildData);

                    await fs.remove(result.apkPath).catch(() => { });
                    if (result.buildDir) await fs.remove(result.buildDir).catch(() => { });

                    buildManager.release(chatId, true);
                } else {
                    await sendBuildNotification(bot, 'failed', {
                        appName: buildData.appName,
                        userName: userName,
                        userId: chatId,
                        duration: durationStr,
                        error: result.error || 'Build failed'
                    });

                    const errorSent = await sendErrorLog(bot, chatId, new Error(result.error || 'Build failed'), 'queue_apk_build', {
                        appName: buildData.appName,
                        url: buildData.url,
                        userId: chatId,
                        userName: userName
                    });

                    if (!errorSent) {
                        await bot.sendMessage(chatId, formatErrorMessage(result.error || 'Build failed'), {
                            parse_mode: 'HTML',
                            reply_markup: getMainKeyboard()
                        });
                    }

                    buildManager.release(chatId, false);
                }

                if (buildData.iconPath) {
                    await fs.remove(buildData.iconPath).catch(() => { });
                }

            } else if (type === 'zip') {
                const { projectType, buildType, filePath } = buildData;
                const typeName = projectType === 'flutter' ? 'Flutter' : 'Android';
                const buildName = buildType === 'release' ? 'Release' : 'Debug';

                console.log(`[Queue Callback] 📦 Starting ZIP build: ${projectType} ${buildType}`);

                const statusMsg = await bot.sendMessage(chatId,
                    formatZipBuildProgress(0, 'Memulai proses build...', projectType, buildType),
                    { parse_mode: 'HTML' }
                );

                const startTime = Date.now();
                buildData.userId = chatId;

                await sendBuildNotification(bot, 'start', {
                    appName: `${typeName}-${buildName}`,
                    userName: userName,
                    userId: chatId
                });

                let currentProgress = 0;

                const result = await buildFromZip(filePath, projectType, buildType, (status) => {
                    buildManager.updateActivity(chatId);

                    if (status.includes('Extracting')) currentProgress = 10;
                    else if (status.includes('Cleaning')) currentProgress = 20;
                    else if (status.includes('dependencies') || status.includes('Getting')) currentProgress = 35;
                    else if (status.includes('Building') || status.includes('Gradle')) currentProgress = 60;
                    else if (status.includes('Locating') || status.includes('APK')) currentProgress = 90;
                    else currentProgress = Math.min(currentProgress + 5, 95);

                    bot.editMessageText(
                        formatZipBuildProgress(currentProgress, status, projectType, buildType), {
                        chat_id: chatId,
                        message_id: statusMsg.message_id,
                        parse_mode: 'HTML'
                    }).catch(() => { });
                });

                const duration = Math.round((Date.now() - startTime) / 1000);
                const durationStr = duration > 60 ? `${Math.floor(duration/60)}m ${duration%60}s` : `${duration}s`;

                if (result.success) {
                    const apkStats = await fs.stat(result.apkPath);
                    const fileSizeMB = (apkStats.size / (1024 * 1024)).toFixed(2);

                    await sendBuildNotification(bot, 'success', {
                        appName: `${typeName}-${buildName}`,
                        userName: userName,
                        userId: chatId,
                        size: `${fileSizeMB} MB`,
                        duration: durationStr
                    });

                    const MAX_FILE_SIZE = process.env.LOCAL_API_URL
                        ? 2 * 1024 * 1024 * 1024
                        : 50 * 1024 * 1024;

                    if (apkStats.size > MAX_FILE_SIZE) {
                        const WEB_URL = process.env.WEB_URL || `http://localhost:${process.env.WEB_PORT || 3000}`;
                        const buildId = `tg-zip-queue-${Date.now()}`;

                        const { registerBuildForDownload } = require('../server');
                        registerBuildForDownload(buildId, result.apkPath, result.buildDir, `${typeName}_${buildName}.apk`, 5 * 60 * 1000);

                        const downloadUrl = `${WEB_URL}/api/download/${buildId}`;

                        await bot.editMessageText(`
✅ <b>Build Berhasil!</b>
━━━━━━━━━━━━━━━━━━

📱 <b>Type:</b> ${typeName}
🏷️ <b>Build:</b> ${buildName}
📦 <b>Ukuran:</b> ${fileSizeMB} MB

⚠️ <b>File terlalu besar untuk Telegram (>50MB)</b>

🔗 <b>Download via Link:</b>
<code>${downloadUrl}</code>

⏰ <i>Link berlaku 5 menit</i>
                        `.trim(), {
                            chat_id: chatId,
                            message_id: statusMsg.message_id,
                            parse_mode: 'HTML',
                            reply_markup: {
                                inline_keyboard: [
                                    [{ text: '📥 Download APK', url: downloadUrl, style: "success" }],
                                    [{ text: '◀️ Kembali ke Menu', callback_data: 'back_main', style: "danger" }]
                                ]
                            }
                        });
                    } else {
                        await bot.editMessageText(`
✅ <b>Build Berhasil!</b>
━━━━━━━━━━━━━━━━━━

📱 <b>Type:</b> ${typeName}
🏷️ <b>Build:</b> ${buildName}
📦 <b>Ukuran:</b> ${fileSizeMB} MB

🎉 <i>Mengirim file APK...</i>
                        `.trim(), {
                            chat_id: chatId,
                            message_id: statusMsg.message_id,
                            parse_mode: 'HTML'
                        });

                        await bot.sendDocument(chatId, result.apkPath, {
                            caption: `✅ <b>APK Build Success</b>\n\n📱 <b>Type:</b> ${typeName}\n🏷️ <b>Build:</b> ${buildName}\n📦 <b>Size:</b> ${fileSizeMB} MB\n\n<i>Generated by Web2APK Bot</i>`,
                            parse_mode: 'HTML'
                        });

                        await fs.remove(result.apkPath).catch(() => { });
                        if (result.buildDir) await fs.remove(result.buildDir).catch(() => { });
                    }

                    await bot.sendMessage(chatId, '🎉 APK berhasil di-build!\n\nIngin build lagi?', {
                        reply_markup: getMainKeyboard()
                    });

                    buildManager.release(chatId, true);
                } else {
                    await sendBuildNotification(bot, 'failed', {
                        appName: `${typeName}-${buildName}`,
                        userName: userName,
                        userId: chatId,
                        duration: durationStr,
                        error: result.error || 'Build failed'
                    });

                    const errorSent = await sendErrorLog(bot, chatId, new Error(result.error || 'Build failed'), 'queue_zip_build', {
                        projectType: projectType,
                        buildType: buildType,
                        userId: chatId,
                        userName: userName
                    });

                    if (!errorSent) {
                        await bot.editMessageText(formatErrorMessage(result.error || 'Build failed'), {
                            chat_id: chatId,
                            message_id: statusMsg.message_id,
                            parse_mode: 'HTML',
                            reply_markup: getMainKeyboard()
                        });
                    }

                    buildManager.release(chatId, false);
                }

                if (filePath) {
                    await fs.remove(filePath).catch(() => { });
                }

            } else {
                console.error(`[Queue Callback] ❌ Unknown build type: ${type}`);
                await bot.sendMessage(chatId, `❌ Tipe build tidak dikenali: ${type}`, {
                    reply_markup: getMainKeyboard()
                });
                buildManager.release(chatId, false);
            }

            global.sessions.delete(chatId);

        } catch (error) {
            console.error('[Queue Callback] Build error:', error);
            
            const errorSent = await sendErrorLog(bot, chatId, error, `queue_${type}_build`, {
                userId: chatId,
                userName: userName || 'Unknown'
            });

            if (!errorSent) {
                await bot.sendMessage(chatId, formatErrorMessage(error.message), {
                    parse_mode: 'HTML',
                    reply_markup: getMainKeyboard()
                }).catch(() => {});
            }
            
            const logSent = await sendVpsErrorLog(bot, chatId, `queue_${type}_build`);
            
            if (!logSent) {
                await bot.sendMessage(chatId, `
⚠️ <b>Tidak ada error log ditemukan</b>
━━━━━━━━━━━━━━━━━━

Pastikan file .log.error ada di:
<code>/root/webapp/logs/*.log.error</code>
                `.trim(), { parse_mode: 'HTML' }).catch(() => {});
            }
            
            buildManager.release(chatId, false);
            global.sessions.delete(chatId);
        }
    };

    console.log('✅ Queue callback initialized');
}

module.exports = { handleCallback, handleZipUpload, initQueueCallback };